# Lightwell

**What a qubit is, starting from one atom and a laser.**

Theme: Quantum Unlocked · Runs on Qollab's free simulators · MIT licensed

This effort is supported by Qollab & IonQ.

---

## What it is

Three acts, in the order the ideas actually make sense.

**Act 1 — one ion.** A single ytterbium-171 ion held between electrodes, and
one laser. The two states are real hyperfine levels of that atom, split by
12.642812 GHz. Leave the laser on longer and the state turns further: a
quarter turn is an even superposition, a half turn flips it. You watch it
turn, because a gate is not a jump between two pictures — it is a pulse, and
which gate you get depends only on when you stop.

**Act 2 — two ions.** Two ions in one trap repel each other, so they cannot
move independently; their motion is a set of shared normal modes. An
entangling pulse drives both ions through that shared vibration, and the
motion acts as a bus carrying the coupling. Watch both Bloch arrows shrink to
nothing as it runs.

**Act 3 — circuits.** Once pulses make sense, drop the apparatus and build at
the gate level: Deutsch-Jozsa, Grover, and the Fourier transform behind Shor.

Act 2 also carries **Grover's search built out of eight real operations** —
four laser pulses, two free phase shifts and two entangling gates — landing on
the marked pair with probability exactly 1. It is the same algorithm Act 3
draws as tidy gates, shown as the pulses a machine would actually fire.

Acts 1 and 2 open on a step-by-step tutorial that fires each sequence for you
and says what to look for. Each step declares which panel it is talking
about, and its card is **moved into that panel** with a ring drawn round it,
so the words and the thing they describe are never far apart. Nothing is
locked while a tutorial runs — the sliders and the sequence stay live — and
leaving it drops you straight into free experimenting.

Everything is a real Qiskit circuit underneath, and Run sends it to whichever
backend you chose in Qollab's Select QPU dialog.

## The idea it is built on

Two panels sit side by side in the lab, and the gap between them is the point.

**The trap shows what you could actually see.** An ion in |0⟩, an ion in |1⟩
and an ion in superposition look *identical* in there. You cannot see a
superposition. The apparatus never pretends otherwise, and the caption says so
outright.

**The energy levels show what the qubit is.** Two hyperfine levels of the
ground state with a population bar on each, the 355 nm drive going up to a
virtual level and straight back down (no single photon fits a 12.6 GHz gap),
and the 369.5 nm detection cycle running out of F = 1 only. The vertical
scale is broken on purpose — the optical gap is about 64,000× the qubit gap —
and the diagram says so rather than pretending.

**The sphere shows what the maths says**, which no camera can show you. Its
poles are named for the same two levels, its height is read off a ruler
marked *chance of reading bright*, and the way it points around is the phase:
invisible to any measurement, and the thing that decides whether two pulses
add up or cancel. The axis the laser is turning it around is drawn, along
with the arc it has swept so far.

Only the detection laser closes the gap. Shine 369.5 nm light and an ion in
F = 1 scatters it and looks bright, while an ion in F = 0 sits 12.6 GHz off
resonance and stays dark. So measurement is not an abstraction here: it is a
strip of simulated camera exposures, lit dots and empty ones, which is exactly
what a trapped-ion measurement produces.

Then in Act 2 the entangling pulse runs and **both arrows vanish**. Not dimmed
— gone, with the spheres labelled "no state of its own". There is no longer
any such thing as ion 0's state; the pair has one state between them. The
interface gives up a way of seeing because the physics took it away.

That withdrawal is **computed, not scripted**: after every step the engine
takes the reduced density matrix of each ion and each pair and finds the
finest grouping for which the state still factorises, then rebuilds the full
state from those groups to check. A half-strength entangling pulse correctly
shows arrows that are shortened but still present.

## What the two sliders can reach

The pulse has two controls, and between them they reach **every state the ion
can be in**. The length sets how far down from the top the arrow lands, and
the phase sets which way round. From |0⟩ a single pulse can put the arrow on
any point of the sphere, because the pole lies on every circle the drive can
trace.

Within one pulse, though, the arrow is confined to a plane: it circles the
drive axis at a fixed angle to it, so its component along that axis never
changes. Changing the phase is what tilts that plane somewhere new. Both
claims are checked numerically, the second to 1e-16.

The one thing these pulses cannot do on their own is rotate about the vertical
axis. Real machines get that for free: rather than firing a laser they shift
the phase reference of every later pulse, which costs no time at all.

## Why Grover needs two ions

Grover's search cannot run on a single qubit, and that is structural rather
than a limitation here. With one qubit the search space is two items, the
diffuser collapses to a plain X gate, and the marked state is an *eigenstate*
of the Grover operator — so iterating changes nothing but a global phase and
the success rate sits at 50% for ever.

The rotation picture says the same thing: each pass turns the state by 2θ
where sin θ = √(1/N). At N = 2 that is a 90° turn starting 45° from the
target, so it overshoots to 135° and swings back, never landing. Two qubits
(N = 4, θ = 30°) is the first case that works, and the only size where a
single pass is *exact*. The lab's Grover tutorial therefore lives in act 2,
and says so.

## What the two sliders can reach

The lab does not use abstract gates. Its two controls are the operations an
IonQ machine actually has, and the tests pin them to IonQ's own published
definitions:

| In the lab | What it is | Exactly |
|---|---|---|
| Pulse, length θ at phase φ | Resonant drive: turn by θ about the equatorial axis the laser phase picks out | `R(π/2, 2πf)` is IonQ's `GPi2(f)`; `R(π, 2πf)` is their `GPi(f)` |
| Entangle, θ turns | Mølmer–Sørensen through the shared motional mode | `MS(0, 0, θ)`, and `MS(0,0,0.25)` is `RXX(π/2)` |
| Phase shift, α | A rotation about the vertical axis, done in software with no laser | `rz(α)` — the "virtual Z" real machines get for free |

The phase shift earns its place: drive pulses only ever rotate about
equatorial axes, so they cannot turn the state about the vertical one. Real
hardware does it by relabelling the phase of every later pulse, which is exact
and instantaneous, and a test asserts that no single drive pulse can
reproduce it.

Qollab's pre-created backend uses the **standard** gate set, so native GPi2 and
MS cannot be submitted to it. Both have exact standard-gate forms, so nothing
is approximated: a drive pulse goes as `rz(−φ)·rx(θ)·rz(φ)`, which rotates
about the same axis, and the entangling gate as `rxx(2πθ)`. A test asserts the
submitted circuit equals the product of the pulse matrices up to global phase,
so what you watch and what the backend runs cannot drift apart.

## What you can build

Nine parts, named for what they do to the light rather than for their gates,
with the gate shown beside each one:

| Part | Gate | What it does |
|---|---|---|
| Splitter | H | Sends the lane down both paths at once |
| Flipper | X | Swaps a lane's two paths |
| Phase dial | P(θ) | Turns the arrow on the 1 path; invisible until paths meet |
| Tilt | RY(θ) | Leans the lane across, for an uneven split |
| Linker | CX | Ties two lanes together. This is the one that entangles |
| Phase linker | CP(θ) | Turns the arrow only where both lanes are 1 |
| Exchange | SWAP | Trades two lanes over |
| Detector | measure | Reads a lane, and any interference it was awaiting is gone |
| Noise tile | depolarising | Kicks a lane at random, the way real hardware does |

Up to 5 lanes and 24 rows. The bottom edge always reads every lane, which is
what makes a run produce a histogram.

## The guided builds

Four, in the picker at the top. Each loads circuits onto the same sandbox;
nothing is locked, no part is withheld, and leaving at any point just leaves
the circuit as it stands.

1. **Start here: one lane.** Superposition, phase, interference, and what a
   detector costs you — each one visible in the shape and colour of the trace.
2. **Build Deutsch-Jozsa.** A hidden rule either ignores your question or
   follows it. Classically you must ask twice. You build a circuit that
   answers in one shot, then see where the answer came from.
3. **Build Grover's search.** Four possibilities, mark one, turn the mark into
   a certainty. Then add a noise tile and watch the certainty leak.
4. **Build the engine inside Shor.** The Fourier staircase doing real period
   finding on three lanes, with an honest account of the distance between this
   and factoring anything.

The last is the point of the sequence. Shor's algorithm is mostly ordinary
arithmetic; the only quantum part is finding a period by interference, and
that part fits on a three-lane circuit. The guide ends by saying plainly what
a real run would need and why nobody has done it.

## How to run it

**On Qollab.** Open the project and press **Run Project**, then pick any free
simulator in the Select QPU dialog. The circuit appears above the console.

**Locally**, for development:

```bash
pip install qiskit pytest
python3 dev/server.py 8000      # then open http://127.0.0.1:8000
python3 -m pytest tests/ -q     # 92 tests
```

In **VS Code**, press F5 instead: that starts the dev server and opens the
circuit in a browser. Ctrl+Shift+B runs the tests. Opening `index.html`
directly does not work — the page uses ES modules and `fetch`, so it has to be
served.

`dev/` and `.vscode/` are not part of the Qollab project. The dev harness
exists because the interface takes its connection to the engine as an argument
rather than importing it, so the same UI runs against Pyodide on Qollab and
against an HTTP server locally. Editing anything under `quantum/` needs a
server restart, since Python caches imported modules.

## How it works

```
index.html, main.css      the page
main.js                   Qollab entry: wraps the Python API for the UI
ui/lab.js                 acts 1 and 2: the trap, the sequence, the camera
ui/bloch.js               the animated Bloch sphere
ui/store.js               act 3's circuit, and every way it can change
ui/board.js               the circuit as SVG: traces, braids, keyboard handling
ui/panels.js              the circuit readout and phasor constellation
ui/guides.js              the four guided builds
ui/app.js                 wiring, acts, legend, intro, theme
quantum/lab.py            pulses, Molmer-Sorensen, detection, camera sampling
quantum/parts.py          every circuit part: matrix, Qiskit call, copy
quantum/board.py          the circuit model and its validation
quantum/engine.py         simulation, entanglement detection, circuit building
quantum/api.py            the JSON surface JavaScript calls
dev/                      local dev server, not part of the Qollab project
tests/                    92 tests
```

Three things in the engine are worth knowing about.

**It evolves a density matrix, not a statevector.** At five lanes that is a
32×32 matrix, which costs nothing, and it buys exactness where a statevector
would have to approximate: a mid-circuit detector produces a genuine mixture
and a noise tile a genuine channel. "Put a detector between the splitters and
watch the interference die" is a claim the engine can make honestly only
because of this.

**The entanglement partition is computed and then verified.** The finest
factorising grouping is found from pairwise reduced density matrices, then the
full state is rebuilt from those groups and compared; a higher-order
correlation that pairwise checks would miss is reported rather than drawn
wrong.

**Noise tiles are planned, not sampled.** A noise tile is a channel, so it
cannot go into a circuit as it stands. Sampling a few random error patterns is
unbiased but very coarse: eight draws of a 10% tile reproduced that 10% only
to within a factor of two, which showed as a visibly wrong histogram. Instead
the engine enumerates error patterns, keeps the most probable up to the job
budget, and divides shots in proportion to their exact probabilities. On one
tile that is exact to four decimal places with four jobs; where the tail is
pruned, the interface states what fraction of the probability it covered
rather than hiding it.

## Beyond the tutorial bar

Against the three routes in the rules:

- **An original educational contribution.** Two things. A visualisation whose
  *failure* is the lesson: the per-qubit picture is withdrawn, by a computed
  test, at the moment it stops being true. And a deliberate split between what
  the apparatus could show you and what the maths says, so that "you cannot
  see a superposition" is something the interface demonstrates rather than
  asserts.
- **A technical extension.** The density-matrix engine with exact mid-circuit
  measurement, entanglement partitions verified by reconstruction, the
  weighted error-pattern noise planner, and continuous trajectories through
  each pulse so the animation plays real intermediate states rather than a
  crossfade.
- Verified rather than asserted: all nineteen lab tutorial steps and every
  circuit in the guided builds are checked against the engine, so each number
  quoted in the copy is one the player will see. Grover's compiled sequence is
  checked stage by stage, including the fact that the odds stay flat after the
  marking gate. Several early copy claims were wrong and were corrected against the
  engine's output rather than the other way round.

## Accessibility

A submission requirement, and treated as one.

- Zero axe-core violations (WCAG 2.1 A and AA, plus best practice) across the
  intro, all three acts and the camera readout, in both themes — ten states.
- Every colour pair carrying text clears 4.5:1 in both themes, checked by
  computation. Several part colours were lightened from the shade that looked
  best in order to pass, and the circuit panel keeps its own ink tokens
  because it stays dark in both themes.
- **Nothing depends on colour.** Phase is a hue, a hand angle and a number in
  degrees. Entanglement is a braid, a border and a sentence. Exact probability
  is a dashed outline and measured frequency a solid fill, so the two are
  distinguishable in greyscale. The noise tile carries hazard stripes.
- Fully keyboard operable: arrow keys move between slots, Enter places,
  Backspace removes, brackets change a dial. You can build and entangle a
  circuit without a mouse.
- The circuit publishes a text equivalent — a table of every part, its row,
  its lanes and its dial — because arrowing across thirty slots to find four
  parts is not a reasonable way to read a circuit. The histogram has one too.
- A live region announces placements, removals, dial changes, cursor position
  and the result of each run, written to be read aloud: dial settings say
  "90 degrees, the S gate" rather than "pi/2".
- Reduced motion is respected: the playhead sweep is skipped, not shortened.

## Honest limitations

- Five lanes and 24 rows in act 3; one or two ions in the lab. The engine is
  exact and that costs 4ⁿ, which is fine here and would not be at twenty
  qubits. The ceiling is deliberate: this is a teaching tool, not a simulator.
- The lab models the ideal operations. Real ions have heating, spontaneous
  emission and gate infidelity; act 3's noise tiles are where imperfection
  lives, and the lab stays clean so the mechanism is legible.
- Qollab's sandbox has no storage, so nothing is saved between sessions. That
  is also why there is no level system: it is a sandbox with optional guides.
- The traces and the readout's amplitudes are computed exactly rather than
  taken from the backend, because the built-in simulator returns counts only.
  The histogram's measured bars *do* come from the backend. The tests compare
  the two, and on screen you can watch the sampled bars converge on the exact
  outline as you raise the shot count.
- A circuit with many noise tiles falls back to sampled error patterns, which
  is coarser. The interface says which method it used.
- Phase is drawn through cos(φ), so +90° and −90° share a colour. The hand
  angle and the printed degrees disambiguate them.

## Attribution and disclosure

Built during the hackathon window, 9–11 October 2026, from an empty directory.

- No template, tutorial or existing repository was used as a starting point.
  The engine, the interface and the guided builds were written for this
  project.
- Built with substantial assistance from Claude (Anthropic), used for
  architecture, implementation, test design and copy throughout.
- Qiskit 2.x is the only runtime dependency. Archivo is loaded from Google
  Fonts, with a system font fallback if it does not load.
- The physics is standard: Deutsch-Jozsa, Grover's algorithm and the quantum
  Fourier transform are textbook, and the circuits here were built from the
  standard constructions and verified against the engine.
- The project began as an attempt to do for quantum computing what the marble
  computer Turing Tumble does for classical computing. Nothing of that toy
  remains in the result — no code, assets, visual language or part names — but
  the initial spark is worth naming.

This effort is supported by Qollab & IonQ.

Released under the MIT License. See `LICENSE`.
