/**
 * The board, and every way it can change.
 *
 * One object holds the whole editable state; everything else in the UI reads
 * from here and re-renders when it changes. Placement rules are enforced here
 * as well as in Python, so a disallowed drop is refused before it ever
 * becomes a round trip.
 */

export const MAX_LANES = 5;
export const MIN_LANES = 1;
export const MAX_ROWS = 24;
export const MIN_ROWS = 4;

function emptyRows(count) {
  return Array.from({ length: count }, () => []);
}

export function createStore(initial) {
  let board = initial
    ? clone(initial)
    : { lanes: 2, rows: emptyRows(8), initial: null };
  if (board.rows.length < MIN_ROWS) {
    board.rows = board.rows.concat(emptyRows(MIN_ROWS - board.rows.length));
  }

  const history = [];
  const listeners = new Set();
  let lastChange = { type: "init" };

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function snapshot() {
    history.push(clone(board));
    if (history.length > 100) history.shift();
  }

  function emit(change) {
    lastChange = change || { type: "change" };
    for (const fn of listeners) fn(board, lastChange);
  }

  /** Which part, if any, occupies a given cell. */
  function at(rowIndex, lane) {
    const row = board.rows[rowIndex];
    if (!row) return null;
    return row.find((p) => p.lanes.includes(lane)) || null;
  }

  /** Whether a part of this footprint could be placed here. */
  function canPlace(rowIndex, lanes) {
    if (rowIndex < 0 || rowIndex >= board.rows.length) return false;
    if (lanes.some((l) => l < 0 || l >= board.lanes)) return false;
    if (new Set(lanes).size !== lanes.length) return false;
    return lanes.every((l) => at(rowIndex, l) === null);
  }

  return {
    subscribe(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },

    get() {
      return board;
    },

    /** The board as the Python side wants it: no empty trailing rows. */
    forEngine() {
      let last = board.rows.length;
      while (last > 0 && board.rows[last - 1].length === 0) last -= 1;
      const payload = { lanes: board.lanes, rows: board.rows.slice(0, last) };
      if (board.initial && board.initial.some((v) => v === 1)) {
        payload.initial = board.initial.slice(0, board.lanes);
      }
      return payload;
    },

    at,
    canPlace,

    place(rowIndex, kind, lanes, angle) {
      if (!canPlace(rowIndex, lanes)) return false;
      snapshot();
      const placement = { kind, lanes: lanes.slice() };
      if (angle !== undefined && angle !== null) placement.angle = angle;
      board.rows[rowIndex].push(placement);
      emit({ type: "place", rowIndex, kind, lanes });
      return true;
    },

    remove(rowIndex, lane) {
      const existing = at(rowIndex, lane);
      if (!existing) return false;
      snapshot();
      board.rows[rowIndex] = board.rows[rowIndex].filter((p) => p !== existing);
      emit({ type: "remove", rowIndex, kind: existing.kind });
      return true;
    },

    setAngle(rowIndex, lane, angle) {
      const existing = at(rowIndex, lane);
      if (!existing) return false;
      snapshot();
      existing.angle = angle;
      emit({ type: "angle", rowIndex, kind: existing.kind, angle });
      return true;
    },

    toggleInitial(lane) {
      snapshot();
      if (!board.initial) board.initial = new Array(MAX_LANES).fill(0);
      board.initial[lane] = board.initial[lane] ? 0 : 1;
      emit({ type: "initial", lane, value: board.initial[lane] });
      return board.initial[lane];
    },

    initialBit(lane) {
      return board.initial ? board.initial[lane] || 0 : 0;
    },

    setLanes(count) {
      const next = Math.max(MIN_LANES, Math.min(MAX_LANES, count));
      if (next === board.lanes) return false;
      snapshot();
      if (next < board.lanes) {
        // Drop anything that reached into the lanes being removed.
        board.rows = board.rows.map((row) =>
          row.filter((p) => p.lanes.every((l) => l < next))
        );
      }
      board.lanes = next;
      emit({ type: "lanes", lanes: next });
      return true;
    },

    addRow() {
      if (board.rows.length >= MAX_ROWS) return false;
      snapshot();
      board.rows.push([]);
      emit({ type: "rows", rows: board.rows.length });
      return true;
    },

    removeRow() {
      if (board.rows.length <= MIN_ROWS) return false;
      snapshot();
      board.rows.pop();
      emit({ type: "rows", rows: board.rows.length });
      return true;
    },

    clear() {
      snapshot();
      board.rows = emptyRows(board.rows.length);
      board.initial = null;
      emit({ type: "clear" });
    },

    load(next) {
      snapshot();
      board = clone(next);
      if (!board.rows) board.rows = [];
      if (board.rows.length < MIN_ROWS) {
        board.rows = board.rows.concat(emptyRows(MIN_ROWS - board.rows.length));
      }
      if (board.initial === undefined) board.initial = null;
      emit({ type: "load" });
    },

    undo() {
      const previous = history.pop();
      if (!previous) return false;
      board = previous;
      emit({ type: "undo" });
      return true;
    },

    canUndo() {
      return history.length > 0;
    },

    isEmpty() {
      return board.rows.every((row) => row.length === 0);
    },
  };
}
