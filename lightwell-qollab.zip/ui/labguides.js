/**
 * Tutorials for the lab.
 *
 * Nothing is locked while one is running: the sliders and the sequence stay
 * live, so a step is a suggestion and a question rather than a cage. Each
 * step loads a pulse sequence and fires it, and every claim in the copy has
 * been checked against the engine.
 *
 * Each step declares which part of the screen it is talking about, and the
 * text is moved there rather than sitting in a bar at the bottom, so the
 * words and the thing they describe are never far apart.
 *
 * The arc of the one-ion tutorial is deliberate. It establishes that the
 * pulse *length* is the only thing choosing the gate, then that the pulse
 * *phase* chooses an axis the camera cannot see, then uses those two facts to
 * produce interference, and only then breaks it with a detection.
 */

const PI = Math.PI;

const pulse = (theta, phi = 0, ion = 0) => ({ kind: "pulse", ion, theta, phi });
const detect = () => ({ kind: "detect" });
const ms = (theta = 0.25) => ({ kind: "ms", theta });
const shift = (alpha, ion = 0) => ({ kind: "shift", ion, alpha });

/**
 * Grover's search for two ions, compiled to operations the hardware has.
 *
 * Four pulses, two free phase shifts and two entangling gates. Every stage of
 * it is checked in the test suite against what the copy below claims, and the
 * whole thing lands on the marked pair with probability one.
 *
 * It needs two ions. On a single qubit the search space is two items, the
 * diffuser collapses to an X gate, and the marked state is an eigenstate of
 * the Grover operator -- so it sits at 50% for ever. Two qubits is the first
 * case that works, and it is the only size where one pass is exact.
 */
const GROVER = [
  pulse(PI / 2, PI, 0),
  pulse(PI / 2, PI, 1),
  ms(0.25),
  pulse((3 * PI) / 2, 0, 0),
  shift((3 * PI) / 2, 0),
  pulse((3 * PI) / 2, 0, 1),
  shift((3 * PI) / 2, 1),
  ms(0.25),
];

export const LAB_GUIDES = [
  {
    id: "one-ion",
    act: 1,
    title: "One ion, step by step",
    steps: [
      {
        title: "This is the whole computer",
        focus: "trap",
        spec: { ions: 1, ops: [] },
        play: false,
        body:
          "<p>One ytterbium atom, missing an electron so the electrodes can hold " +
          "it still in a vacuum. The qubit is not the atom; it is a choice of " +
          "two of its energy levels, listed under the trap.</p>" +
          "<p>It starts in <b>0</b>. Press <b>Expose</b> to photograph it a " +
          "hundred times: every frame comes back dark, because the detection " +
          "laser has nothing to make it glow.</p>",
      },
      {
        title: "Leave the laser on and it turns over",
        focus: "state",
        spec: { ions: 1, ops: [pulse(PI)] },
        play: true,
        body:
          "<p>A pulse of the drive laser turns the state. This one is on long " +
          "enough for <b>half a turn</b>, which takes it all the way from 0 to " +
          "1. Watch the arrow swing from the top of the sphere to the bottom.</p>" +
          "<p><b>Expose</b> now and every frame is bright. This is a bit flip, " +
          "and it is nothing more exotic than a laser left on for about five " +
          "millionths of a second.</p>",
      },
      {
        title: "Stop halfway and you get superposition",
        focus: "state",
        spec: { ions: 1, ops: [pulse(PI / 2)] },
        play: true,
        body:
          "<p>The same laser, on for half as long. The arrow stops on the " +
          "equator, and <b>that is all a superposition is</b>: the pulse was " +
          "interrupted part way round.</p>" +
          "<p><b>Expose</b>. Now the frames are a random mix, about half bright. " +
          "Not because the ion is secretly one or the other, but because the " +
          "question the camera asks only has two possible answers and the " +
          "arrow is pointing between them.</p>" +
          "<p>Look at the trap while you do it. It is identical to the last " +
          "step. There is nothing to see.</p>",
      },
      {
        title: "Keep going and it comes back",
        focus: "sequence",
        spec: { ions: 1, ops: [pulse(2 * PI)] },
        play: true,
        body:
          "<p>A <b>full turn</b> carries the arrow right around and back to the " +
          "top. Expose it: every frame dark again, exactly as if you had done " +
          "nothing.</p>" +
          "<p>Drag the top slider slowly and watch the percentages. Nothing " +
          "about the laser changed except how long it stayed on, and that " +
          "single number chose every gate so far.</p>",
      },
      {
        title: "The phase chooses an axis, and the camera cannot see it",
        focus: "state",
        spec: { ions: 1, ops: [pulse(PI / 2, PI / 2)] },
        play: true,
        body:
          "<p>Same quarter turn, but the laser's <b>phase</b> is now 90°. The " +
          "dashed line is the axis the state is turning around, and it has " +
          "swung round with the phase, so the arrow lands somewhere different " +
          "on the equator.</p>" +
          "<p>Expose it anyway: still about half bright. A measurement only " +
          "ever asks the up-down question, so it cannot tell these two " +
          "superpositions apart. The difference is real, and invisible.</p>",
      },
      {
        title: "Two pulses that agree",
        focus: "camera",
        spec: { ions: 1, ops: [pulse(PI / 2), pulse(PI / 2)] },
        play: true,
        body:
          "<p>Two quarter turns at the same phase, one after the other. They " +
          "turn the same way about the same axis, so they add up to a half " +
          "turn and the ion ends up <b>bright every time</b>.</p>" +
          "<p>Nothing surprising yet. Hold on to it though, because the next " +
          "step changes only one number.</p>",
      },
      {
        title: "Two pulses that cancel",
        focus: "state",
        spec: { ions: 1, ops: [pulse(PI / 2), pulse(PI / 2, PI)] },
        play: true,
        body:
          "<p>The second pulse now has phase 180°, so it turns about the " +
          "opposite axis and unwinds the first. The ion ends up <b>dark every " +
          "time</b> — the two pulses cancelled exactly.</p>" +
          "<p>That is interference, and it is the whole engine of quantum " +
          "computing. The invisible difference from two steps ago is what " +
          "decided the outcome here, which is why phase is worth caring " +
          "about even though no camera can photograph it.</p>",
      },
      {
        title: "Watch it in the middle and you break it",
        focus: "state",
        spec: { ions: 1, ops: [pulse(PI / 2), detect(), pulse(PI / 2, PI)] },
        play: true,
        body:
          "<p>The same cancelling pair, with a detection slipped between them. " +
          "The certainty is gone: expose it and you get about half and half.</p>" +
          "<p>Reading the ion forced it to pick, so by the time the second " +
          "pulse arrived there was nothing left to unwind. Notice the arrow " +
          "after the detection is <b>short</b> — that is the sphere's way of " +
          "saying this is now a plain coin toss, not a superposition.</p>",
      },
      {
        title: "Anywhere on the sphere",
        focus: "sequence",
        spec: { ions: 1, ops: [pulse(1.1, 2.4)] },
        play: true,
        body:
          "<p>Those two sliders reach <b>every state this ion can be in</b>. " +
          "The length sets how far down from the top, the phase sets which " +
          "way round. One pulse from 0 can land the arrow on any point.</p>" +
          "<p>Within a single pulse the arrow is stuck in a plane — it circles " +
          "the dashed axis and never leaves it. Changing the phase is what " +
          "tilts that plane somewhere new.</p>" +
          "<p>One thing these pulses cannot do on their own is spin the arrow " +
          "about the vertical axis. Real machines get that for free: instead " +
          "of firing a laser they just shift the phase of every later pulse, " +
          "which costs no time at all.</p>" +
          "<p>Go and build something. Then try two ions.</p>",
      },
    ],
  },

  {
    id: "two-ions",
    act: 2,
    title: "Two ions, step by step",
    steps: [
      {
        title: "Two ions cannot move independently",
        focus: "trap",
        spec: { ions: 2, ops: [] },
        play: false,
        body:
          "<p>Two ions in one trap, both positively charged, so they push each " +
          "other apart until the trap balances them. Push one and the other " +
          "feels it. Their motion is not two separate wobbles but a set of " +
          "shared patterns.</p>" +
          "<p>Each still has its own arrow for now. Expose them: both dark, " +
          "every frame.</p>",
      },
      {
        title: "Pulse one and the other does not care",
        focus: "state",
        spec: { ions: 2, ops: [pulse(PI, 0, 0)] },
        play: true,
        body:
          "<p>Aim a half turn at ion 0 only. It flips to bright; ion 1 stays " +
          "dark. Two arrows, two independent stories, nothing shared.</p>" +
          "<p>Expose it and every frame is the same: one lit dot, one empty. " +
          "No randomness at all.</p>",
      },
      {
        title: "Drive both through the motion they share",
        focus: "trap",
        spec: { ions: 2, ops: [ms(0.12)] },
        play: true,
        body:
          "<p>The entangling pulse is different. It is tuned so that changing " +
          "an ion's internal state also nudges the shared vibration, which " +
          "means each ion's state becomes tied to a motion the other one is " +
          "part of. Watch them rock against each other while it runs.</p>" +
          "<p>This is only run part way. Both arrows have <b>shrunk</b> but " +
          "neither has vanished: the ions are partly entangled, and each one " +
          "still has a little of a state of its own.</p>",
      },
      {
        title: "Run it all the way",
        focus: "state",
        spec: { ions: 2, ops: [ms(0.25)] },
        play: true,
        body:
          "<p>At a quarter turn the interaction is complete, and <b>both arrows " +
          "are gone</b>. Not faint. Gone.</p>" +
          "<p>There is no longer any such thing as ion 0's state. The pair has " +
          "a single state between them, and the panel can only list what the " +
          "two together might do. Nothing has been hidden from you; there is " +
          "nothing about either ion on its own left to draw.</p>",
      },
      {
        title: "The ions agree, and neither decided",
        focus: "camera",
        spec: { ions: 2, ops: [ms(0.25), detect()] },
        play: true,
        body:
          "<p>Expose it. Every frame shows <b>both bright or both dark</b>, " +
          "about half and half, and never one of each.</p>" +
          "<p>Before the exposure neither ion was bright or dark. Both " +
          "outcomes were equally likely and the two always match anyway. That " +
          "agreement, with no answer existing beforehand, is the thing with " +
          "no classical picture — and the reason the shared motion was worth " +
          "all that trouble.</p>" +
          "<p>Act 3 builds on this at the gate level.</p>",
      },
    ],
  },

  {
    id: "grover",
    act: 2,
    title: "Grover's search, in eight pulses",
    steps: [
      {
        title: "Four possibilities, no favourites",
        focus: "camera",
        spec: { ions: 2, ops: GROVER.slice(0, 2) },
        play: true,
        body:
          "<p>One quarter-turn pulse on each ion. Two ions give four " +
          "combinations, and right now each is equally likely. Expose it: " +
          "roughly a quarter each.</p>" +
          "<p>One of those four is the answer we are hunting. Checking by hand " +
          "takes up to four looks. This sequence takes <b>one pass</b>.</p>" +
          "<p>Two ions is the smallest search that works at all. With a single " +
          "ion there are only two possibilities, and the method stalls at a " +
          "coin toss no matter how many times you repeat it.</p>",
      },
      {
        title: "Mark the answer, and see nothing happen",
        focus: "camera",
        spec: { ions: 2, ops: GROVER.slice(0, 3) },
        play: true,
        body:
          "<p>The first entangling gate marks the pair we are looking for. " +
          "Watch the arrows vanish as it runs: the ions are now fully " +
          "entangled.</p>" +
          "<p>Now expose it. <b>Still a flat quarter each.</b> The answer has " +
          "been marked and the camera cannot tell. Exactly like the laser " +
          "phase on one ion, the marking lives somewhere a measurement does " +
          "not reach.</p>",
      },
      {
        title: "Turn the mark into an answer",
        focus: "camera",
        spec: { ions: 2, ops: GROVER },
        play: true,
        body:
          "<p>Four more operations: a pulse and a free phase shift on each " +
          "ion, then a second entangling gate. Expose it now and you get " +
          "<b>both bright, every single time</b>. The other three " +
          "possibilities are at exactly zero.</p>" +
          "<p>Nothing was searched. The wrong answers cancelled and the right " +
          "one added up, which is the only trick quantum computing has.</p>",
      },
      {
        title: "It borrows the entanglement and gives it back",
        focus: "state",
        spec: { ions: 2, ops: GROVER },
        play: false,
        body:
          "<p>Step the readout back with the sequence chips. After the first " +
          "entangling gate neither ion had a state of its own. At the end " +
          "<b>both have one again</b> \u2014 the answer is a plain, ordinary pair " +
          "of bright ions.</p>" +
          "<p>The entanglement was not the output. It was scaffolding, put up " +
          "to let the four possibilities interfere with each other and taken " +
          "down once they had.</p>",
      },
      {
        title: "Break it",
        focus: "sequence",
        spec: { ions: 2, ops: GROVER },
        play: false,
        body:
          "<p>Nudge any one of the sliders \u2014 shorten a pulse, turn a phase " +
          "shift \u2014 and expose it again. The certainty falls apart " +
          "immediately and the wrong answers come back.</p>" +
          "<p>That fragility is the honest headline. Every one of those eight " +
          "operations has to be right to within a fraction of a percent, on " +
          "real hardware, with the ions warm and the lasers drifting. It is " +
          "why error correction is the whole field's central problem, and why " +
          "a working machine is hard rather than merely expensive.</p>" +
          "<p>Act 3 builds the same algorithm out of tidy gates instead.</p>",
      },
    ],
  },
];
