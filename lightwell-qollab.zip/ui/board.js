/**
 * The circuit, drawn as the state itself rather than as a diagram of it.
 *
 * Lanes run left to right and rows descend, so a run reads downward. What is
 * drawn in each lane is not a wire but a *trace*: a luminous ribbon whose
 * width is how deep in superposition that lane is, whose colour is its phase,
 * and whose brightness falls as it decoheres. The trace is recomputed from
 * the exact state after every row, so editing the circuit reshapes the light.
 *
 * The important thing the drawing does is stop. A lane's trace exists only
 * while that lane has a state of its own. Where lanes entangle, the separate
 * ribbons end and a single braided channel takes over, because there is
 * nothing per-lane left to draw. That discontinuity is the whole point: the
 * picture is withdrawn by the physics, not by the interface being coy.
 *
 * Encodings, each of which is also published as text elsewhere so none of the
 * meaning rests on seeing colour:
 *
 *   ribbon width   2*sqrt(p0*p1) -- nothing at a settled lane, widest at an
 *                  even split
 *   ribbon drift   leans towards the side the lane is likely to land on
 *   ribbon colour  phase, amber where in step and teal where opposed, via
 *                  cos(phase) so the two interfering extremes are the two
 *                  ends of the scale
 *   phasor tick    the exact phase angle, drawn only where phase can matter
 *   brightness     coherence; a noise tile visibly thins and dims the trace
 *   braid          lanes with no individual state left
 */

const NS = "http://www.w3.org/2000/svg";

export const GEOM = {
  pad: 18,
  rowNumWidth: 26,
  headHeight: 48,
  footHeight: 54,
  cellW: 84,
  cellH: 58,
  tileW: 46,
  tileH: 36,
};

const PART_FILL = {
  splitter: "var(--p-splitter)",
  flipper: "var(--p-flipper)",
  phase: "var(--p-phase)",
  tilt: "var(--p-tilt)",
  linker: "var(--p-linker)",
  phaselinker: "var(--p-phaselinker)",
  exchange: "var(--p-exchange)",
  detector: "var(--p-detector)",
  noise: "var(--p-noise)",
};

// The two ends of the phase scale. Amber reads as "in step", teal as
// "opposed" -- the two cases that actually matter when paths recombine.
const PHASE_IN = [232, 199, 122];
const PHASE_OUT = [95, 200, 186];
// Where a lane is settled there is no phase to speak of, so the trace fades
// to neutral rather than asserting a colour that means nothing.
const PHASE_NONE = [122, 138, 142];

function el(name, attrs = {}, children = []) {
  const node = document.createElementNS(NS, name);
  for (const [key, value] of Object.entries(attrs)) {
    if (value === undefined || value === null) continue;
    node.setAttribute(key, String(value));
  }
  for (const child of [].concat(children)) if (child) node.appendChild(child);
  return node;
}

function degrees(radians) {
  return (((radians * 180) / Math.PI) % 360 + 360) % 360;
}

export function angleLabel(kind, angle) {
  if (kind === "noise") return `${Math.round(angle * 100)}%`;
  return `${Math.round(degrees(angle))}°`;
}

/** Phase to colour, through cos so 0 and 180 degrees are the two extremes. */
export function phaseColour(phi, alpha = 1, meaning = 1) {
  const t = (1 - Math.cos(phi)) / 2;
  const hue = PHASE_IN.map((v, i) => v + (PHASE_OUT[i] - v) * t);
  const m = Math.max(0, Math.min(1, meaning));
  const c = hue.map((v, i) => Math.round(PHASE_NONE[i] + (v - PHASE_NONE[i]) * m));
  return `rgba(${c[0]}, ${c[1]}, ${c[2]}, ${alpha})`;
}

function glyph(kind, cx, cy, angle, role, ink) {
  const stroke = ink;
  switch (kind) {
    case "splitter":
      return [
        el("path", {
          d: `M ${cx} ${cy - 9} L ${cx} ${cy - 2} M ${cx} ${cy - 2} L ${cx - 7} ${cy + 9} M ${cx} ${cy - 2} L ${cx + 7} ${cy + 9}`,
          stroke, "stroke-width": 2, fill: "none", "stroke-linecap": "round",
        }),
      ];
    case "flipper":
      return [
        el("path", {
          d: `M ${cx - 5} ${cy + 8} V ${cy - 8} m 0 0 l -3 4 m 3 -4 l 3 4`,
          stroke, "stroke-width": 2, fill: "none",
          "stroke-linecap": "round", "stroke-linejoin": "round",
        }),
        el("path", {
          d: `M ${cx + 5} ${cy - 8} V ${cy + 8} m 0 0 l -3 -4 m 3 4 l 3 -4`,
          stroke, "stroke-width": 2, fill: "none",
          "stroke-linecap": "round", "stroke-linejoin": "round",
        }),
      ];
    case "phase":
    case "phaselinker": {
      const r = 9;
      const theta = -angle;
      return [
        el("circle", { cx, cy, r, fill: "none", stroke, "stroke-width": 1.5 }),
        el("line", {
          x1: cx, y1: cy,
          x2: cx + r * Math.cos(theta), y2: cy + r * Math.sin(theta),
          stroke, "stroke-width": 2.5, "stroke-linecap": "round",
        }),
        el("circle", { cx, cy, r: 1.6, fill: stroke }),
      ];
    }
    case "tilt": {
      const r = 9;
      return [
        el("path", {
          d: `M ${cx - r} ${cy + r * 0.6} A ${r} ${r} 0 0 1 ${cx + r} ${cy + r * 0.6}`,
          fill: "none", stroke, "stroke-width": 1.5,
        }),
        el("line", {
          x1: cx, y1: cy + r * 0.6,
          x2: cx + r * Math.sin(angle), y2: cy + r * 0.6 - r * Math.cos(angle),
          stroke, "stroke-width": 2.5, "stroke-linecap": "round",
        }),
      ];
    }
    case "linker":
      if (role === "control") return [el("circle", { cx, cy, r: 5, fill: stroke })];
      return [
        el("circle", { cx, cy, r: 8, fill: "none", stroke, "stroke-width": 2 }),
        el("path", { d: `M ${cx - 8} ${cy} h 16 M ${cx} ${cy - 8} v 16`, stroke, "stroke-width": 2 }),
      ];
    case "exchange":
      return [
        el("path", {
          d: `M ${cx - 7} ${cy - 7} l 14 14 M ${cx + 7} ${cy - 7} l -14 14`,
          stroke, "stroke-width": 2.5, "stroke-linecap": "round",
        }),
      ];
    case "detector":
      return [
        el("path", {
          d: `M ${cx - 8} ${cy + 5} A 8 8 0 0 1 ${cx + 8} ${cy + 5}`,
          fill: "none", stroke, "stroke-width": 1.8,
        }),
        el("line", { x1: cx, y1: cy + 5, x2: cx + 6, y2: cy - 2, stroke, "stroke-width": 2.2, "stroke-linecap": "round" }),
        el("line", { x1: cx - 9, y1: cy + 8, x2: cx + 9, y2: cy + 8, stroke, "stroke-width": 1.8 }),
      ];
    case "noise":
      return [
        el("path", {
          d: `M ${cx - 9} ${cy + 5} l 6 -10 M ${cx - 3} ${cy + 5} l 6 -10 M ${cx + 3} ${cy + 5} l 6 -10`,
          stroke, "stroke-width": 2.2, "stroke-linecap": "round",
        }),
      ];
    default:
      return [];
  }
}

export function createBoardView(svg, store, catalogue, options = {}) {
  const view = {
    cursor: { row: 0, lane: 0 },
    pending: null,
    showRow: null,
    analysis: null,
    reveal: 1, // 0..1 during a playhead sweep
    playing: false,
    highlight: null,
  };

  const onSelectCell = options.onSelectCell || (() => {});
  const onPlaced = options.onPlaced || (() => {});
  const announce = options.announce || (() => {});
  const partMeta = (kind) => catalogue.find((p) => p.kind === kind);

  function geometry(board) {
    const { pad, rowNumWidth, headHeight, footHeight, cellW, cellH } = GEOM;
    return {
      width: pad * 2 + rowNumWidth + board.lanes * cellW,
      height: pad * 2 + headHeight + board.rows.length * cellH + footHeight,
      originX: pad + rowNumWidth,
      originY: pad + headHeight,
    };
  }

  // how far down a row the previous state holds before the part acts
  const HOLD = 0.5;

  const laneX = (g, lane) => g.originX + lane * GEOM.cellW + GEOM.cellW / 2;
  const rowY = (g, index) => g.originY + index * GEOM.cellH;

  function cellCentre(board, row, lane) {
    const g = geometry(board);
    return { x: laneX(g, lane), y: rowY(g, row) + GEOM.cellH / 2 };
  }

  // ------------------------------------------------------------ interaction

  function activate(row, lane) {
    const existing = store.at(row, lane);
    const selected = options.getSelectedKind ? options.getSelectedKind() : null;

    if (view.pending && view.pending.row === row) {
      if (lane === view.pending.firstLane) {
        view.pending = null;
        announce("Cancelled that part.");
        render();
        return;
      }
      const lanes = [view.pending.firstLane, lane];
      const { kind, angle } = view.pending;
      if (store.place(row, kind, lanes, angle)) {
        announce(`${partMeta(kind).label} placed in row ${row + 1}, from lane ${lanes[0]} to lane ${lanes[1]}.`);
        view.pending = null;
        onPlaced(kind);
        return;
      }
      announce("That slot is taken.");
      return;
    }

    if (existing) {
      view.cursor = { row, lane };
      onSelectCell(row, lane, existing);
      render();
      return;
    }
    if (!selected) {
      view.cursor = { row, lane };
      announce("Pick a part from the parts list first.");
      render();
      return;
    }

    const meta = partMeta(selected);
    const angle = options.getSelectedAngle ? options.getSelectedAngle() : undefined;
    if (meta.arity === 2) {
      view.pending = { kind: selected, row, firstLane: lane, angle };
      view.cursor = { row, lane };
      announce(`${meta.label} started on lane ${lane}. Choose a second lane in row ${row + 1}.`);
      render();
      return;
    }
    if (store.place(row, selected, [lane], angle)) {
      view.cursor = { row, lane };
      announce(`${meta.label} placed in row ${row + 1}, lane ${lane}.`);
      onPlaced(selected);
      return;
    }
    announce("That slot is taken.");
  }

  function removeAt(row, lane) {
    const existing = store.at(row, lane);
    if (!existing) {
      announce("Nothing there to take off.");
      return;
    }
    const meta = partMeta(existing.kind);
    store.remove(row, lane);
    announce(`${meta.label} taken out of row ${row + 1}.`);
  }

  function cycleAngle(row, lane, direction) {
    const existing = store.at(row, lane);
    if (!existing) return;
    const meta = partMeta(existing.kind);
    if (!meta.takesAngle || !meta.anglePresets.length) {
      announce(`${meta.label} has no dial.`);
      return;
    }
    const current = existing.angle === undefined ? meta.defaultAngle : existing.angle;
    let index = meta.anglePresets.findIndex((p) => Math.abs(p.value - current) < 1e-9);
    if (index < 0) index = 0;
    index = (index + direction + meta.anglePresets.length) % meta.anglePresets.length;
    const next = meta.anglePresets[index];
    store.setAngle(row, lane, next.value);
    announce(`${meta.label} set to ${next.label}.`);
  }

  // ---------------------------------------------------------------- drawing

  /** Per-boundary geometry for one lane's trace, or null where it has no state. */
  function snapshotAt(index) {
    const snapshots = view.analysis ? view.analysis.snapshots : null;
    if (!snapshots || !snapshots.length) return null;
    return snapshots[Math.min(index, snapshots.length - 1)];
  }

  function sampleAt(g, snap, lane, y, atRow) {
    const info = snap && snap.lanes[lane];
    if (!info || !info.own_state) return null;
    const spread = 2 * Math.sqrt(Math.max(0, info.p0 * info.p1));
    return {
      y,
      atRow,
      half: 2.2 + spread * (GEOM.cellW * 0.2),
      drift: (info.p1 - info.p0) * GEOM.cellW * 0.12,
      colour: phaseColour(info.phi, 0.4 + 0.3 * info.arrowLength, spread),
      edge: phaseColour(info.phi, 0.9, spread),
      phi: info.phi,
      spread,
      coherence: info.arrowLength,
    };
  }

  /**
   * Two samples per row, so the trace changes shape where the part is rather
   * than drifting across the whole row. A splitter should visibly be the thing
   * that opens the lane up, not a label on a gradual widening.
   */
  function traceSamples(g, lane, rows) {
    if (!view.analysis) return [];
    const out = [];
    for (let r = 0; r <= rows; r += 1) {
      const snap = snapshotAt(r);
      out.push(sampleAt(g, snap, lane, rowY(g, r), true));
      if (r < rows) out.push(sampleAt(g, snap, lane, rowY(g, r) + GEOM.cellH * HOLD, false));
    }
    return out;
  }

  /** One ribbon per unbroken run of boundaries where the lane has its own state. */
  function drawTraces(root, board, g) {
    for (let lane = 0; lane < board.lanes; lane += 1) {
      const samples = traceSamples(g, lane, board.rows.length);
      const cx = laneX(g, lane);
      let run = [];
      const flush = () => {
        if (run.length >= 2) drawRibbon(root, cx, run);
        else if (run.length === 1) drawStub(root, cx, run[0]);
        run = [];
      };
      for (const sample of samples) {
        if (sample) run.push(sample);
        else flush();
      }
      flush();
    }
  }

  function drawRibbon(root, cx, run) {
    const right = run.map((s) => [cx + s.drift + s.half, s.y]);
    const left = run.map((s) => [cx + s.drift - s.half, s.y]).reverse();
    const points = right.concat(left);
    const d =
      `M ${points[0][0].toFixed(2)} ${points[0][1].toFixed(2)} ` +
      points.slice(1).map(([x, y]) => `L ${x.toFixed(2)} ${y.toFixed(2)}`).join(" ") +
      " Z";

    const id = `grad-${cx.toFixed(0)}-${run[0].y.toFixed(0)}-${run.length}`;
    const span = run[run.length - 1].y - run[0].y || 1;
    const gradient = el("linearGradient", {
      id, x1: 0, y1: run[0].y, x2: 0, y2: run[run.length - 1].y,
      gradientUnits: "userSpaceOnUse",
    });
    for (const s of run) {
      gradient.appendChild(
        el("stop", { offset: ((s.y - run[0].y) / span).toFixed(4), "stop-color": s.colour })
      );
    }
    root.appendChild(el("defs", {}, [gradient]));
    root.appendChild(el("path", { d, fill: `url(#${id})`, stroke: "none" }));
    root.appendChild(
      el("path", {
        d: `M ${run[0].y === undefined ? 0 : cx + run[0].drift} ${run[0].y} ` +
           run.slice(1).map((s) => `L ${cx + s.drift} ${s.y}`).join(" "),
        fill: "none", stroke: run[run.length - 1].edge, "stroke-width": 1.2, opacity: 0.85,
      })
    );
    for (const s of run) {
      if (s.atRow && s.spread > 0.06) {
        drawPhasor(root, cx + s.drift, s.y, s.phi, s.coherence, s.edge);
      }
    }
  }

  function drawStub(root, cx, s) {
    root.appendChild(el("circle", { cx: cx + s.drift, cy: s.y, r: 2.4, fill: s.edge }));
  }

  /**
   * The exact phase, as a hand on a small dial. Colour alone is a coarse read
   * of a cyclic quantity, so the angle is always drawn as well.
   */
  function drawPhasor(root, x, y, phi, coherence, colour) {
    const r = 6 * Math.max(0.35, coherence);
    root.appendChild(el("circle", { cx: x, cy: y, r, fill: "var(--board-deep)", opacity: 0.6 }));
    root.appendChild(
      el("line", {
        x1: x, y1: y,
        x2: x + r * Math.cos(-phi), y2: y + r * Math.sin(-phi),
        stroke: colour, "stroke-width": 1.8, "stroke-linecap": "round",
      })
    );
  }

  /**
   * Lanes with no state of their own, drawn as one braided channel.
   *
   * The braid is the point: two strands crossing cannot be read as two
   * independent things, which is exactly the situation. It is drawn per row
   * interval so it begins and ends at the rows that actually fuse and release
   * the lanes.
   */
  function drawFusedChannels(root, board, g) {
    if (!view.analysis) return;
    for (let i = 0; i < board.rows.length; i += 1) {
      const snap = snapshotAt(i + 1);
      const clusters = ((snap && snap.clusters) || []).filter((c) => c.length > 1);
      const bottom = rowY(g, board.rows.length);
      const y1 = rowY(g, i) + GEOM.cellH * HOLD;
      const y2 = Math.min(bottom, rowY(g, i + 1) + GEOM.cellH * HOLD);
      if (y2 <= y1) continue;
      for (const cluster of clusters) {
        const first = Math.min(...cluster);
        const last = Math.max(...cluster);
        if (last >= board.lanes) continue;
        const x1 = laneX(g, first) - GEOM.cellW * 0.26;
        const x2 = laneX(g, last) + GEOM.cellW * 0.26;
        root.appendChild(
          el("rect", {
            x: x1, y: y1, width: x2 - x1, height: y2 - y1,
            fill: "var(--fused-fill)",
          })
        );
        const mid = (y1 + y2) / 2;
        const inset = (x2 - x1) * 0.18;
        for (const [a, b] of [[x1 + inset, x2 - inset], [x2 - inset, x1 + inset]]) {
          root.appendChild(
            el("path", {
              d: `M ${a} ${y1} C ${a} ${mid}, ${b} ${mid}, ${b} ${y2}`,
              fill: "none", stroke: "var(--fused-strand)", "stroke-width": 2.2,
              "stroke-linecap": "round", opacity: 0.9,
            })
          );
        }
      }
    }
  }

  function drawPlacement(root, board, row, placement) {
    const meta = partMeta(placement.kind);
    const angle = placement.angle === undefined ? meta.defaultAngle : placement.angle;
    const fill = PART_FILL[placement.kind] || "var(--p-exchange)";
    const ink = "var(--part-ink)";

    if (placement.lanes.length === 2) {
      const a = cellCentre(board, row, placement.lanes[0]);
      const b = cellCentre(board, row, placement.lanes[1]);
      root.appendChild(el("line", { x1: a.x, y1: a.y, x2: b.x, y2: b.y, stroke: "var(--board-deep)", "stroke-width": 9, "stroke-linecap": "round" }));
      root.appendChild(el("line", { x1: a.x, y1: a.y, x2: b.x, y2: b.y, stroke: fill, "stroke-width": 5, "stroke-linecap": "round" }));
    }

    placement.lanes.forEach((lane, index) => {
      const c = cellCentre(board, row, lane);
      const role = index === 0 ? "control" : "target";
      const isDot = placement.kind === "linker" && role === "control";
      const w = isDot ? 22 : GEOM.tileW;
      const h = isDot ? 22 : GEOM.tileH;
      const group = el("g", { class: "part-tile" });
      // a solid backing plate so the trace does not read through the part
      group.appendChild(el("rect", { x: c.x - w / 2 - 2, y: c.y - h / 2 - 2, width: w + 4, height: h + 4, rx: 7, fill: "var(--board)" }));
      group.appendChild(el("rect", { x: c.x - w / 2, y: c.y - h / 2, width: w, height: h, rx: 5, fill, stroke: "var(--part-edge)", "stroke-width": 1 }));
      for (const piece of glyph(placement.kind, c.x, c.y - (meta.takesAngle && !isDot ? 2 : 0), angle, role, ink)) {
        group.appendChild(piece);
      }
      if (meta.takesAngle && !isDot) {
        group.appendChild(
          el("text", { x: c.x, y: c.y + h / 2 - 3, class: "part-angle" }, [
            document.createTextNode(angleLabel(placement.kind, angle)),
          ])
        );
      }
      group.appendChild(
        el("title", {}, [
          document.createTextNode(
            `${meta.label}${meta.takesAngle ? `, dial ${angleLabel(placement.kind, angle)}` : ""}` +
            `, row ${row + 1}, lane ${lane}` +
            (placement.lanes.length === 2 ? `, ${role}` : "")
          ),
        ])
      );
      root.appendChild(group);
    });
  }

  function describeBoard(board) {
    const placed = [];
    for (let row = 0; row < board.rows.length; row += 1) {
      for (const placement of board.rows[row]) {
        const meta = partMeta(placement.kind);
        const angle = placement.angle === undefined ? meta.defaultAngle : placement.angle;
        placed.push({
          row: row + 1, lanes: placement.lanes, label: meta.label,
          arity: meta.arity,
          dial: meta.takesAngle ? angleLabel(placement.kind, angle) : null,
        });
      }
    }
    svg.setAttribute(
      "aria-label",
      `Circuit: ${board.lanes} lanes, ${board.rows.length} rows, ` +
        `${placed.length} part${placed.length === 1 ? "" : "s"} placed.`
    );

    const table = options.descriptionTable;
    if (!table) return;
    table.textContent = "";
    const caption = document.createElement("caption");
    caption.textContent = "Parts in the circuit, in the order they are carried out";
    table.appendChild(caption);
    const head = document.createElement("tr");
    for (const title of ["Row", "Lanes", "Part", "Dial"]) {
      const th = document.createElement("th");
      th.textContent = title;
      head.appendChild(th);
    }
    table.appendChild(head);
    if (!placed.length) {
      const tr = document.createElement("tr");
      const td = document.createElement("td");
      td.colSpan = 4;
      td.textContent = "The circuit is empty.";
      tr.appendChild(td);
      table.appendChild(tr);
      return;
    }
    for (const entry of placed) {
      const tr = document.createElement("tr");
      for (const value of [
        String(entry.row),
        entry.arity === 2 ? `${entry.lanes[0]} to ${entry.lanes[1]}` : String(entry.lanes[0]),
        entry.label,
        entry.dial || "none",
      ]) {
        const td = document.createElement("td");
        td.textContent = value;
        tr.appendChild(td);
      }
      table.appendChild(tr);
    }
  }

  // ----------------------------------------------------------------- render

  function render() {
    const board = store.get();
    const g = geometry(board);
    svg.setAttribute("viewBox", `0 0 ${g.width} ${g.height}`);
    svg.setAttribute("preserveAspectRatio", "xMidYMid meet");
    while (svg.firstChild) svg.removeChild(svg.firstChild);

    const bottom = rowY(g, board.rows.length);

    svg.appendChild(el("rect", { x: 1, y: 1, width: g.width - 2, height: g.height - 2, rx: 10, fill: "var(--board)", stroke: "var(--board-edge)", "stroke-width": 1.5 }));

    // lane headings, each with the value the lane starts from
    for (let lane = 0; lane < board.lanes; lane += 1) {
      const x = laneX(g, lane);
      svg.appendChild(el("text", { x, y: GEOM.pad + 15, "text-anchor": "middle", class: "lane-head" }, [document.createTextNode(`lane ${lane}`)]));
      const bit = store.initialBit(lane);
      const toggle = el("g", { class: "lane-toggle", role: "button", tabindex: "-1", "aria-label": `Lane ${lane} starts at ${bit}. Activate to change it.` });
      toggle.appendChild(el("rect", { x: x - 24, y: GEOM.pad + 22, width: 48, height: 17, rx: 8, fill: bit ? "var(--p-splitter)" : "var(--board-deep)", stroke: "var(--board-edge)", "stroke-width": 1 }));
      toggle.appendChild(el("text", { x, y: GEOM.pad + 34, "text-anchor": "middle", class: bit ? "lane-start-on" : "lane-start-off" }, [document.createTextNode(`starts ${bit}`)]));
      toggle.addEventListener("click", (event) => {
        event.stopPropagation();
        announce(`Lane ${lane} now starts at ${store.toggleInitial(lane)}.`);
      });
      svg.appendChild(toggle);
    }

    // row numbers, and the guide's highlight
    for (let row = 0; row < board.rows.length; row += 1) {
      const y = rowY(g, row);
      svg.appendChild(el("text", { x: GEOM.pad + 16, y: y + GEOM.cellH / 2 + 4, "text-anchor": "end", class: "row-num" }, [document.createTextNode(String(row + 1))]));
      if (view.highlight && view.highlight.rows.includes(row)) {
        svg.appendChild(el("rect", { x: g.originX - 4, y: y + 1, width: board.lanes * GEOM.cellW + 8, height: GEOM.cellH - 2, rx: 5, fill: "var(--highlight-fill)", stroke: "var(--p-splitter)", "stroke-width": 1.5, "stroke-dasharray": "5 4" }));
      }
    }

    // the lane tracks the light runs along
    for (let lane = 0; lane < board.lanes; lane += 1) {
      const x = laneX(g, lane);
      svg.appendChild(el("line", { x1: x, y1: g.originY, x2: x, y2: bottom, class: "lane-track" }));
    }

    // everything that depends on the state, revealed by the playhead
    const clip = el("clipPath", { id: "reveal-clip" }, [
      el("rect", { x: 0, y: 0, width: g.width, height: g.originY + (bottom - g.originY) * view.reveal + 1 }),
    ]);
    svg.appendChild(el("defs", {}, [clip]));
    const field = el("g", { "clip-path": "url(#reveal-clip)" });
    drawFusedChannels(field, board, g);
    drawTraces(field, board, g);
    svg.appendChild(field);

    // the parts sit above the light they act on
    for (let row = 0; row < board.rows.length; row += 1) {
      for (const placement of board.rows[row]) drawPlacement(svg, board, row, placement);
    }

    // where the other half of a two-lane part may go
    if (view.pending) {
      for (let lane = 0; lane < board.lanes; lane += 1) {
        if (lane === view.pending.firstLane) continue;
        if (!store.canPlace(view.pending.row, [view.pending.firstLane, lane])) continue;
        const c = cellCentre(board, view.pending.row, lane);
        svg.appendChild(el("rect", { x: c.x - GEOM.tileW / 2, y: c.y - GEOM.tileH / 2, width: GEOM.tileW, height: GEOM.tileH, rx: 5, class: "cell-pending" }));
      }
    }

    // the read-out edge
    svg.appendChild(el("path", { d: `M ${g.originX - 8} ${bottom + 10} H ${g.originX + board.lanes * GEOM.cellW + 4}`, class: "read-edge" }));
    svg.appendChild(el("text", { x: g.originX - 8, y: bottom + 26, class: "foot-note" }, [document.createTextNode("every lane is read here")]));

    const shown = view.showRow === null ? null : snapshotAt(view.showRow);
    const fusedNow = shown ? shown.clusters.filter((c) => c.length > 1) : [];
    if (fusedNow.length) {
      svg.appendChild(
        el("text", { x: g.originX + (board.lanes * GEOM.cellW) / 2, y: bottom + 42, "text-anchor": "middle", class: "fused-note" }, [
          document.createTextNode(
            fusedNow.length === 1 && fusedNow[0].length === board.lanes
              ? "all lanes braided: no lane has a state of its own"
              : fusedNow.map((c) => `lanes ${c.join(" + ")} braided`).join(", ")
          ),
        ])
      );
    }

    // the playhead, while a run is sweeping
    if (view.playing) {
      const y = g.originY + (bottom - g.originY) * view.reveal;
      svg.appendChild(el("line", { x1: g.originX - 10, y1: y, x2: g.originX + board.lanes * GEOM.cellW + 6, y2: y, class: "playhead" }));
    }

    describeBoard(board);

    // click targets above the artwork
    for (let row = 0; row < board.rows.length; row += 1) {
      for (let lane = 0; lane < board.lanes; lane += 1) {
        const hit = el("rect", {
          x: g.originX + lane * GEOM.cellW, y: rowY(g, row),
          width: GEOM.cellW, height: GEOM.cellH, class: "cell-hit",
        });
        hit.addEventListener("click", () => { svg.focus(); activate(row, lane); });
        hit.addEventListener("contextmenu", (event) => {
          event.preventDefault();
          view.cursor = { row, lane };
          removeAt(row, lane);
        });
        svg.appendChild(hit);
      }
    }

    const cur = cellCentre(board, view.cursor.row, view.cursor.lane);
    svg.appendChild(el("rect", {
      x: cur.x - GEOM.cellW / 2 + 3, y: cur.y - GEOM.cellH / 2 + 2,
      width: GEOM.cellW - 6, height: GEOM.cellH - 4, rx: 6, class: "cell-cursor",
    }));
  }

  // --------------------------------------------------------------- keyboard

  svg.addEventListener("keydown", (event) => {
    const board = store.get();
    const { row, lane } = view.cursor;
    let handled = true;
    switch (event.key) {
      case "ArrowLeft": view.cursor = { row, lane: Math.max(0, lane - 1) }; break;
      case "ArrowRight": view.cursor = { row, lane: Math.min(board.lanes - 1, lane + 1) }; break;
      case "ArrowUp": view.cursor = { row: Math.max(0, row - 1), lane }; break;
      case "ArrowDown": view.cursor = { row: Math.min(board.rows.length - 1, row + 1), lane }; break;
      case "Enter": case " ": activate(row, lane); return;
      case "Backspace": case "Delete": removeAt(row, lane); return;
      case "[": cycleAngle(row, lane, -1); return;
      case "]": cycleAngle(row, lane, 1); return;
      case "Escape":
        if (view.pending) { view.pending = null; announce("Cancelled that part."); render(); }
        return;
      default: handled = false;
    }
    if (handled) {
      event.preventDefault();
      const occupant = store.at(view.cursor.row, view.cursor.lane);
      const where = `Row ${view.cursor.row + 1}, lane ${view.cursor.lane}`;
      announce(occupant ? `${where}, holding a ${partMeta(occupant.kind).label}.` : `${where}, empty.`);
      onSelectCell(view.cursor.row, view.cursor.lane, occupant);
      render();
    }
  });

  // -------------------------------------------------------- playhead sweep

  /** Sweep the playhead down, revealing the trace as the run descends. */
  function play(onDone) {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      view.playing = false;
      view.reveal = 1;
      render();
      onDone();
      return;
    }
    const rows = Math.max(1, store.get().rows.length);
    const duration = Math.min(1600, 220 * rows);
    const start = performance.now();
    view.playing = true;
    view.reveal = 0;
    const step = (now) => {
      const t = Math.min(1, (now - start) / duration);
      view.reveal = t;
      render();
      if (t < 1) {
        window.requestAnimationFrame(step);
      } else {
        view.playing = false;
        view.reveal = 1;
        render();
        onDone();
      }
    };
    window.requestAnimationFrame(step);
  }

  return {
    view,
    render,
    play,
    setAnalysis(analysis, row) {
      view.analysis = analysis;
      view.showRow = row;
    },
    setHighlight(highlight) { view.highlight = highlight; },
    cursor() { return view.cursor; },
    setCursor(row, lane) { view.cursor = { row, lane }; },
    cancelPending() { view.pending = null; },
  };
}
