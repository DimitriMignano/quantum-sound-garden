/**
 * The readout: the exact state, in numbers.
 *
 * This panel carries the idea the whole project is built around. While the
 * state factorises, every lane gets a dial of its own and you can read a lane
 * the way you would read a switch. The moment a linker entangles lanes, those
 * dials cannot be drawn at all -- not because the interface is being coy, but
 * because there is no such thing as lane 0's state any more -- so they are
 * replaced by a single joint panel showing one phasor per outcome.
 *
 * Losing k dials and gaining 2^k phasors is the exponential blow-up made
 * visible, and it is why simulating this on a classical machine gets
 * expensive.
 */

import { phaseColour } from "./board.js";

const NS = "http://www.w3.org/2000/svg";

function svgEl(name, attrs = {}, children = []) {
  const node = document.createElementNS(NS, name);
  for (const [k, v] of Object.entries(attrs)) {
    if (v !== undefined && v !== null) node.setAttribute(k, String(v));
  }
  for (const child of [].concat(children)) if (child) node.appendChild(child);
  return node;
}

function elem(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function pct(value) {
  // Tiny negative residues from the linear algebra would otherwise print as
  // "-0.0%", which looks like a bug to anyone reading the panel.
  const safe = Math.abs(value) < 5e-5 ? 0 : value;
  return `${(safe * 100).toFixed(1)}%`;
}

function deg(radians) {
  let d = (radians * 180) / Math.PI;
  d = ((d % 360) + 360) % 360;
  return `${d.toFixed(0)}°`;
}

/**
 * One lane's dial: a Bloch sphere drawn side-on.
 *
 * Vertical is the 0/1 axis, the needle's tilt is how far into superposition
 * the lane has gone, the bead on the equator is which way the phase points,
 * and a needle shorter than the radius means the lane has decohered. Every one
 * of those is also printed as a number beside it, so none of it depends on
 * seeing the picture.
 */
function laneDial(lane) {
  const size = 56;
  const r = 21;
  const cx = size / 2;
  const cy = size / 2;
  const [x, y] = lane.bloch;
  const length = Math.min(1, lane.arrowLength);
  const equatorial = Math.sqrt(x * x + y * y);
  // The needle is drawn in the plane of the screen: tilted by theta, with its
  // length set by |r| so decoherence visibly shortens it.
  const needleX = cx + r * length * Math.sin(lane.theta);
  const needleY = cy - r * length * Math.cos(lane.theta);

  const svg = svgEl("svg", {
    width: size,
    height: size,
    viewBox: `0 0 ${size} ${size}`,
    "aria-hidden": "true",
    focusable: "false",
  });
  svg.appendChild(
    svgEl("circle", {
      cx,
      cy,
      r,
      fill: "var(--paper)",
      stroke: "var(--rule-strong)",
      "stroke-width": 1,
    })
  );
  svg.appendChild(
    svgEl("ellipse", {
      cx,
      cy,
      rx: r,
      ry: r * 0.3,
      fill: "none",
      stroke: "var(--rule)",
      "stroke-width": 1,
    })
  );
  svg.appendChild(
    svgEl("line", {
      x1: cx,
      y1: cy - r,
      x2: cx,
      y2: cy + r,
      stroke: "var(--rule)",
      "stroke-width": 1,
      "stroke-dasharray": "2 2",
    })
  );
  // the bead showing which way the phase points
  if (equatorial > 0.02) {
    svg.appendChild(
      svgEl("circle", {
        cx: cx + r * Math.cos(lane.phi),
        cy: cy + r * 0.3 * Math.sin(lane.phi),
        r: 2.6,
        fill: "var(--p-phase)",
        stroke: "var(--ink)",
        "stroke-width": 0.6,
      })
    );
  }
  svg.appendChild(
    svgEl("line", {
      x1: cx,
      y1: cy,
      x2: needleX,
      y2: needleY,
      stroke: "var(--ink)",
      "stroke-width": 2.4,
      "stroke-linecap": "round",
    })
  );
  svg.appendChild(svgEl("circle", { cx, cy, r: 1.8, fill: "var(--ink)" }));
  return svg;
}

export function createPanels(dom, options = {}) {
  const formatBasis = (basis) => basis.split("").join(" ");

  function renderLaneStates(snapshot, lanes) {
    const host = dom.laneStates;
    host.textContent = "";

    const own = snapshot.lanes.filter((l) => l.own_state);
    if (!own.length) {
      host.appendChild(
        elem(
          "p",
          "bin-hint",
          "No lane has a state of its own right now. The joint panel below is the whole story."
        )
      );
      return;
    }

    for (const lane of own) {
      const card = elem("div", "lane-card");
      card.appendChild(laneDial(lane));

      const numbers = elem("div", "numbers");
      numbers.appendChild(elem("span", "lane-name", `Lane ${lane.lane}`));

      const weights = elem("div");
      weights.innerHTML =
        `lands on 0 <b>${pct(lane.p0)}</b>, on 1 <b>${pct(lane.p1)}</b>`;
      numbers.appendChild(weights);

      const phase = elem("div");
      if (Math.abs(lane.p0 - 1) < 1e-9 || Math.abs(lane.p1 - 1) < 1e-9) {
        phase.innerHTML = `settled, no phase to speak of`;
      } else {
        phase.innerHTML = `phase <b>${deg(lane.phi)}</b>`;
      }
      numbers.appendChild(phase);

      if (lane.arrowLength < 0.999) {
        const decohered = elem("div", "decohered");
        decohered.innerHTML =
          `needle at <b>${(lane.arrowLength * 100).toFixed(0)}%</b> length, so this lane is part noise`;
        numbers.appendChild(decohered);
      }

      card.appendChild(numbers);
      host.appendChild(card);
    }
  }

  function renderJoint(snapshot) {
    const host = dom.jointState;
    const fused = snapshot.clusters.filter((c) => c.length > 1);
    if (!fused.length) {
      host.hidden = true;
      host.textContent = "";
      return;
    }
    host.hidden = false;
    host.textContent = "";

    const names = fused
      .map((c) => `lane${c.length > 1 ? "s" : ""} ${c.join(" and ")}`)
      .join(", ");
    host.appendChild(elem("div", "joint-head", `Fused: ${names}`));
    host.appendChild(
      elem(
        "p",
        "joint-why",
        "These lanes no longer have states of their own, so there are no dials " +
          "left to draw for them. Only the combinations below exist, and that is " +
          "not a simplification: nothing about a single lane is left to show."
      )
    );

    // One clock hand per outcome: length is how likely, angle is its phase.
    // Two hands pointing opposite ways are two paths that will cancel, which
    // is the thing a bar chart of probabilities cannot show at all.
    if (snapshot.amplitudes && snapshot.amplitudes.length <= 16) {
      const field = elem("div", "constellation");
      for (const entry of snapshot.amplitudes.slice().sort((a, b) => a.basis.localeCompare(b.basis))) {
        const cell = elem("div", "phasor-cell");
        const size = 46;
        const r = (size / 2 - 3) * Math.sqrt(entry.prob);
        const svg = svgEl("svg", {
          width: size, height: size, viewBox: `0 0 ${size} ${size}`,
          "aria-hidden": "true", focusable: "false",
        });
        svg.appendChild(svgEl("circle", {
          cx: size / 2, cy: size / 2, r: size / 2 - 3,
          fill: "none", stroke: "var(--rule)", "stroke-width": 1,
        }));
        const phi = (entry.phaseDeg * Math.PI) / 180;
        svg.appendChild(svgEl("circle", {
          cx: size / 2, cy: size / 2, r: Math.max(1.5, r),
          fill: phaseColour(phi, 0.3), stroke: "none",
        }));
        svg.appendChild(svgEl("line", {
          x1: size / 2, y1: size / 2,
          x2: size / 2 + r * Math.cos(-phi), y2: size / 2 + r * Math.sin(-phi),
          stroke: phaseColour(phi, 1), "stroke-width": 2, "stroke-linecap": "round",
        }));
        cell.appendChild(svg);
        const label = elem("span", "basis", formatBasis(entry.basis));
        cell.appendChild(label);
        cell.appendChild(document.createTextNode(`${entry.phaseDeg.toFixed(0)}\u00b0`));
        field.appendChild(cell);
      }
      host.appendChild(field);
    }

    const rows = elem("div", "joint-rows");
    const source = snapshot.amplitudes || snapshot.probabilities;
    const sorted = source
      .slice()
      .sort((a, b) => b.prob - a.prob)
      .slice(0, 16);
    for (const entry of sorted) {
      const row = elem("div", "joint-row");
      row.appendChild(elem("span", "basis", formatBasis(entry.basis)));
      const bar = elem("span", "bar");
      const fill = elem("span");
      fill.style.width = `${Math.max(1, entry.prob * 100)}%`;
      bar.appendChild(fill);
      row.appendChild(bar);
      row.appendChild(elem("span", "pct", pct(entry.prob)));
      row.appendChild(
        elem(
          "span",
          "deg",
          entry.phaseDeg === undefined ? "—" : `${entry.phaseDeg.toFixed(0)}°`
        )
      );
      rows.appendChild(row);
    }
    host.appendChild(rows);

    if (snapshot.mixed) {
      host.appendChild(
        elem(
          "p",
          "joint-why",
          "A detector or a noise tile has already acted, so these are the odds of " +
            "each combination rather than amplitudes with phases to interfere."
        )
      );
    }
  }

  /**
   * The histogram shows exact probability as an outline and what a run actually
   * saw as a fill, so sampling error is visible as the gap between the two
   * rather than hidden behind a single bar.
   */
  function renderHistogram(exact, observed, note) {
    const host = dom.histogram;
    host.textContent = "";
    dom.histogramNote.textContent = note || "";

    const labels = new Set([
      ...Object.keys(exact || {}),
      ...Object.keys(observed || {}),
    ]);
    const ordered = [...labels].sort();
    // Bars are measured against certainty, not against the tallest bar. Scaling
    // to the peak made two 50% outcomes both draw as full-width bars, which
    // reads as "always this" when it means "half the time".
    const peak = 1;

    for (const label of ordered) {
      const exactValue = (exact && exact[label]) || 0;
      const seenValue = observed ? observed[label] || 0 : null;
      const bar = elem("div", "hbar");
      bar.appendChild(elem("span", "basis", formatBasis(label)));

      const track = elem("span", "track");
      if (seenValue !== null) {
        const seen = elem("span", "seen");
        seen.style.width = `${(seenValue / peak) * 100}%`;
        track.appendChild(seen);
      }
      const outline = elem("span", "exact");
      outline.style.width = `${(exactValue / peak) * 100}%`;
      track.appendChild(outline);
      bar.appendChild(track);

      bar.appendChild(
        elem("span", "pct", seenValue === null ? pct(exactValue) : pct(seenValue))
      );
      host.appendChild(bar);
    }

    // the same numbers as a table, for anyone not reading the bars
    const table = dom.histogramTable;
    table.textContent = "";
    const caption = elem("caption", null, "Where the board lands");
    table.appendChild(caption);
    const head = document.createElement("tr");
    for (const title of ["Outcome", "Exact", "Measured"]) {
      head.appendChild(elem("th", null, title));
    }
    table.appendChild(head);
    for (const label of ordered) {
      const tr = document.createElement("tr");
      tr.appendChild(elem("th", null, formatBasis(label)));
      tr.appendChild(elem("td", null, pct((exact && exact[label]) || 0)));
      tr.appendChild(
        elem("td", null, observed ? pct(observed[label] || 0) : "not run yet")
      );
      table.appendChild(tr);
    }
  }

  function renderCode(source) {
    dom.codeOut.textContent = source;
  }

  function renderDiagram(diagram) {
    dom.diagramOut.textContent = diagram;
  }

  /** A sentence describing the state, for the live region and for screen readers. */
  function describe(snapshot, rowLabel) {
    const fused = snapshot.clusters.filter((c) => c.length > 1);
    const parts = [];
    if (fused.length) {
      parts.push(
        fused
          .map((c) => `lanes ${c.join(" and ")} are entangled and share one state`)
          .join("; ")
      );
    } else {
      parts.push("every lane still has a state of its own");
    }
    if (snapshot.mixed) parts.push("the state is no longer a pure superposition");
    const top = (snapshot.probabilities || [])
      .slice()
      .sort((a, b) => b.prob - a.prob)
      .slice(0, 3)
      .map((p) => `${formatBasis(p.basis)} at ${pct(p.prob)}`)
      .join(", ");
    if (top) parts.push(`most likely outcomes: ${top}`);
    return `${rowLabel}: ${parts.join(". ")}.`;
  }

  return { renderLaneStates, renderJoint, renderHistogram, renderCode, renderDiagram, describe };
}
