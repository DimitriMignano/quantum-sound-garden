/**
 * The ion's energy levels, drawn the way atomic physics draws them.
 *
 * The trap beside this shows where the ion sits; this shows what the qubit
 * actually *is*. Two hyperfine levels of the ground state, 12.642812 GHz
 * apart, and a third level far above them that exists only so the ion can be
 * read out.
 *
 * Three things it makes concrete that nothing else here does:
 *
 *   The qubit is a pair of levels, not the atom. The population bars beside
 *   each ground level are the odds of finding the ion there, which is the
 *   same number as the height of the arrow on the Bloch sphere.
 *
 *   The drive is a two-photon Raman transition. A 355 nm laser cannot bridge
 *   a 12.6 GHz gap directly, so it goes up to a virtual level and straight
 *   back down. That is why the drive wavelength has nothing to do with the
 *   qubit splitting.
 *
 *   Detection is a cycle, not a single photon. The 369.5 nm laser drives
 *   F = 1 up to the excited state, which falls back to F = 1, which is
 *   driven up again -- thousands of times, which is why it looks bright.
 *   F = 0 is 12.6 GHz off resonance and never joins in.
 *
 * The vertical scale is badly broken on purpose: the real ratio between the
 * optical transition and the hyperfine splitting is about 64,000 to 1, and
 * the diagram says so rather than pretending.
 */

const NS = "http://www.w3.org/2000/svg";

const W = 330;
const H = 262;
const LEFT = 96;
const RIGHT = 248;
const Y_EXCITED = 30;
const Y_VIRTUAL = 100;
const Y_ONE = 148;
const Y_ZERO = 190;

function el(name, attrs = {}, children = []) {
  const node = document.createElementNS(NS, name);
  for (const [k, v] of Object.entries(attrs)) {
    if (v !== undefined && v !== null) node.setAttribute(k, String(v));
  }
  for (const child of [].concat(children)) if (child) node.appendChild(child);
  return node;
}

/** A wavy arrow, for spontaneously emitted light. */
function squiggle(x1, y1, x2, y2, amplitude = 4, waves = 5) {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const len = Math.hypot(dx, dy) || 1;
  const nx = -dy / len;
  const ny = dx / len;
  let d = `M ${x1} ${y1}`;
  const steps = waves * 2;
  for (let i = 1; i <= steps; i += 1) {
    const t = i / steps;
    const sign = i % 2 ? 1 : -1;
    const px = x1 + dx * t + nx * amplitude * sign;
    const py = y1 + dy * t + ny * amplitude * sign;
    d += ` Q ${px} ${py} ${x1 + dx * t} ${y1 + dy * t}`;
  }
  return d;
}

export function createLevels(host) {
  const svg = el("svg", {
    viewBox: `0 0 ${W} ${H}`,
    class: "levels",
    "aria-hidden": "true",
    focusable: "false",
  });
  host.appendChild(svg);

  /**
   * @param ions  per-ion {pBright} for the population bars
   * @param mode  "idle" | "drive" | "detect", which lasers are firing
   */
  function draw(ions, mode) {
    while (svg.firstChild) svg.removeChild(svg.firstChild);
    const driving = mode === "drive";
    const detecting = mode === "detect";

    const level = (y, label, sub, strong) => {
      svg.appendChild(
        el("line", {
          x1: LEFT, y1: y, x2: RIGHT, y2: y,
          stroke: strong ? "var(--level-strong)" : "var(--level)",
          "stroke-width": strong ? 2.5 : 2,
        })
      );
      svg.appendChild(
        el("text", { x: LEFT - 9, y: y + 3, "text-anchor": "end", class: "level-label" },
          [document.createTextNode(label)])
      );
      if (sub) {
        svg.appendChild(
          el("text", { x: LEFT - 9, y: y + 14, "text-anchor": "end", class: "level-sub" },
            [document.createTextNode(sub)])
        );
      }
    };

    level(Y_EXCITED, "\u00b2P\u2081\u141f\u2082", "not part of the qubit", false);

    svg.appendChild(
      el("line", {
        x1: LEFT + 6, y1: Y_VIRTUAL, x2: RIGHT - 60, y2: Y_VIRTUAL,
        stroke: "var(--ink-faint)", "stroke-width": 1.3, "stroke-dasharray": "5 5",
      })
    );
    svg.appendChild(
      el("text", { x: LEFT - 9, y: Y_VIRTUAL + 3, "text-anchor": "end", class: "level-sub" },
        [document.createTextNode("virtual")])
    );

    level(Y_ONE, "F = 1", "reads bright", true);
    level(Y_ZERO, "F = 0", "reads dark", true);

    // the gap that is the qubit
    const sx = RIGHT + 9;
    svg.appendChild(
      el("path", {
        d: `M ${sx} ${Y_ONE} V ${Y_ZERO} M ${sx - 3} ${Y_ONE + 4} l 3 -4 l 3 4 ` +
           `M ${sx - 3} ${Y_ZERO - 4} l 3 4 l 3 -4`,
        stroke: "var(--ink-soft)", "stroke-width": 1.2, fill: "none",
      })
    );
    svg.appendChild(
      el("text", { x: sx + 6, y: (Y_ONE + Y_ZERO) / 2 + 3, class: "level-sub" },
        [document.createTextNode("12.6 GHz")])
    );

    // the drive: up to the virtual level and straight back down, on the left
    const up = LEFT + 22;
    const down = LEFT + 40;
    svg.appendChild(
      el("path", {
        d: `M ${up} ${Y_ZERO} L ${down - 4} ${Y_VIRTUAL + 2}`,
        stroke: "var(--drive)", "stroke-width": driving ? 2.6 : 1.5,
        opacity: driving ? 1 : 0.42, fill: "none",
      })
    );
    svg.appendChild(
      el("path", {
        d: `M ${down} ${Y_VIRTUAL + 2} L ${down + 14} ${Y_ONE - 2} m -4.5 -5 l 4.5 5 l -6 0.5`,
        stroke: "var(--drive)", "stroke-width": driving ? 2.6 : 1.5,
        opacity: driving ? 1 : 0.42, fill: "none",
      })
    );
    svg.appendChild(
      el("text", { x: 3, y: Y_ZERO + 30, class: "beam-tag", opacity: driving ? 1 : 0.55 },
        [document.createTextNode("355 nm drive")])
    );
    svg.appendChild(
      el("text", { x: 3, y: Y_ZERO + 40, class: "level-sub", opacity: driving ? 1 : 0.55 },
        [document.createTextNode("two photons: no single one fits the gap")])
    );

    // detection: a cycle out of F = 1 only, on the right
    const dx = LEFT + 118;
    svg.appendChild(
      el("path", {
        d: `M ${dx} ${Y_ONE} V ${Y_EXCITED + 3} m -3.5 6 l 3.5 -6 l 3.5 6`,
        stroke: "var(--detect)", "stroke-width": detecting ? 2.6 : 1.5,
        fill: "none", opacity: detecting ? 1 : 0.42,
      })
    );
    svg.appendChild(
      el("path", {
        d: squiggle(dx + 24, Y_EXCITED + 5, dx + 24, Y_ONE - 3, 3.5, 5),
        stroke: "var(--detect)", "stroke-width": detecting ? 2 : 1.2,
        fill: "none", opacity: detecting ? 1 : 0.38,
      })
    );
    svg.appendChild(
      el("text", { x: dx - 6, y: Y_EXCITED - 8, class: "beam-tag", opacity: detecting ? 1 : 0.55 },
        [document.createTextNode("369.5 nm")])
    );
    svg.appendChild(
      el("text", { x: dx - 6, y: Y_EXCITED - 18, class: "level-sub", opacity: detecting ? 1 : 0.55 },
        [document.createTextNode("absorb, re-emit, repeat")])
    );

    // how much of the ion is in each level, below the line it belongs to
    const list = ions && ions.length ? ions : [{ pBright: 0 }];
    list.forEach((ion, index) => {
      const dy = 5 + index * 7;
      for (const [y, p, fill] of [
        [Y_ONE, ion.pBright, "var(--detect)"],
        [Y_ZERO, 1 - ion.pBright, "var(--ink-soft)"],
      ]) {
        svg.appendChild(
          el("rect", {
            x: LEFT + 1, y: y + dy, width: Math.max(0, p) * (RIGHT - LEFT - 2),
            height: 5, rx: 2, fill, opacity: 0.6,
          })
        );
      }
    });
    svg.appendChild(
      el("text", { x: 3, y: Y_ZERO + 52, class: "level-sub" },
        [document.createTextNode(
          list.length > 1
            ? "bars: how much of each ion is in that level (ion 0 above ion 1)"
            : "bar: how much of the ion is in that level")])
    );

    svg.appendChild(
      el("text", { x: 3, y: H - 3, class: "level-sub" },
        [document.createTextNode("vertical scale broken: the optical gap is ~64,000\u00d7 the qubit gap")])
    );
  }

  draw([{ pBright: 0 }], "idle");
  return { draw, svg };
}
