/**
 * Wiring: the bin, the board, the readout and the run buttons.
 *
 * ``bridge`` is the only way this module reaches the quantum engine, and it is
 * injected rather than imported. On Qollab it is backed by the Python modules
 * in ``quantum/``; the local dev server backs it with HTTP calls to the same
 * Python. The UI cannot tell the difference, which is what makes it possible
 * to develop and test this outside Qollab at all.
 */

import { createStore, MAX_LANES, MIN_LANES, MAX_ROWS, MIN_ROWS } from "./store.js";
import { createBoardView, phaseColour } from "./board.js";
import { createPanels } from "./panels.js";
import { GUIDES } from "./guides.js";
import { createLab } from "./lab.js";
import { LAB_GUIDES } from "./labguides.js";

/** Short marks for the parts-bin chips, which are too small for full names. */
const SHORT_GATE = {
  splitter: "H",
  flipper: "X",
  phase: "P",
  tilt: "RY",
  linker: "CX",
  phaselinker: "CP",
  exchange: "SW",
  detector: "M",
  noise: "N",
};

/**
 * The board the player arrives to: half an interferometer.
 *
 * Deliberately unfinished. A splitter and a turned phase dial leave lane 0 in
 * superposition, which keeps both of the board's discoveries one part away: a
 * second splitter turns the phase into a certainty, and a linker fuses the two
 * lanes. Finishing the interferometer here would have been the better first
 * impression but it collapses lane 0 to a definite value, so a linker dropped
 * underneath it does nothing visible -- which teaches the opposite of the
 * lesson, since the player's obvious next move would look like a dud part.
 */
const OPENING_BOARD = {
  lanes: 2,
  rows: [
    [{ kind: "splitter", lanes: [0] }],
    [{ kind: "phase", lanes: [0], angle: Math.PI }],
    [],
    [],
    [],
    [],
  ],
  initial: null,
};

export async function start(bridge) {
  const dom = {
    board: document.getElementById("board"),
    binList: document.getElementById("bin-list"),
    binDetail: document.getElementById("bin-detail"),
    laneStates: document.getElementById("lane-states"),
    jointState: document.getElementById("joint-state"),
    histogram: document.getElementById("histogram"),
    histogramNote: document.getElementById("histogram-note"),
    histogramTable: document.getElementById("histogram-table"),
    codeOut: document.getElementById("code-out"),
    diagramOut: document.getElementById("diagram-out"),
    live: document.getElementById("live"),
    dropReport: document.getElementById("drop-report"),
    rowSlider: document.getElementById("row-slider"),
    rowSliderValue: document.getElementById("row-slider-value"),
    lanesCount: document.getElementById("lanes-count"),
    rowsCount: document.getElementById("rows-count"),
    guide: document.getElementById("guide"),
    guideTitle: document.getElementById("guide-title"),
    guideStep: document.getElementById("guide-step"),
    guideText: document.getElementById("guide-text"),
    guidePicker: document.getElementById("guide-picker"),
    bootError: document.getElementById("boot-error"),
    boardDescription: document.getElementById("board-description"),
    legend: document.getElementById("legend"),
    intro: document.getElementById("intro"),
  };

  let announceTimer = null;
  function announce(message) {
    window.clearTimeout(announceTimer);
    announceTimer = window.setTimeout(() => {
      dom.live.textContent = message;
    }, 60);
  }

  const catalogueResult = await bridge.catalogue();
  if (!catalogueResult.ok) {
    showBootError(dom, catalogueResult);
    return;
  }
  const catalogue = catalogueResult.parts;

  const factsResult = await bridge.ion_facts();
  const ionFacts = factsResult.ok ? factsResult.ion : {};

  const store = createStore(OPENING_BOARD);
  const panels = createPanels(dom);

  let selectedKind = "splitter";
  let selectedAngles = {};
  for (const part of catalogue) {
    if (part.takesAngle) selectedAngles[part.kind] = part.defaultAngle;
  }

  let latestAnalysis = null;
  let shownRow = null; // null means "the last row"
  let lastRun = null;

  const boardView = createBoardView(dom.board, store, catalogue, {
    announce,
    getSelectedKind: () => selectedKind,
    getSelectedAngle: () =>
      catalogue.find((p) => p.kind === selectedKind)?.takesAngle
        ? selectedAngles[selectedKind]
        : undefined,
    onSelectCell: (row, lane, occupant) => renderBinDetail(occupant, row, lane),
    onPlaced: () => {},
    descriptionTable: dom.boardDescription,
  });

  // ------------------------------------------------------------- parts bin

  function renderBin() {
    dom.binList.textContent = "";
    for (const part of catalogue) {
      const item = document.createElement("button");
      item.type = "button";
      item.className = "bin-item";
      item.dataset.kind = part.kind;
      item.setAttribute("role", "radio");
      item.setAttribute("aria-checked", String(part.kind === selectedKind));
      // Spell the name out rather than letting it be read off the visible
      // text, which would say the gate name and a middle dot out loud.
      item.setAttribute(
        "aria-label",
        `${part.label}, the ${part.gate} gate, ${
          part.arity === 2 ? "uses two lanes" : "uses one lane"
        }`
      );

      const chip = document.createElement("span");
      chip.className = "chip";
      chip.style.background = `var(--p-${part.kind})`;
      // The chip is 34px square, so it carries a short mark rather than the
      // full gate name, which overflowed for "measure" and "depolarising".
      chip.textContent = SHORT_GATE[part.kind] || part.gate;
      chip.setAttribute("aria-hidden", "true");

      const text = document.createElement("span");
      const name = document.createElement("span");
      name.className = "name";
      name.textContent = part.label;
      const gate = document.createElement("span");
      gate.className = "gate";
      gate.textContent =
        part.arity === 2 ? `${part.gate} · two lanes` : part.gate;
      text.appendChild(name);
      text.appendChild(gate);

      item.appendChild(chip);
      item.appendChild(text);
      item.addEventListener("click", () => {
        selectedKind = part.kind;
        boardView.cancelPending();
        renderBin();
        renderBinDetail(null);
        announce(
          `${part.label} selected. ${
            part.arity === 2
              ? "Choose two slots in the same row."
              : "Choose a slot on the board."
          }`
        );
        boardView.render();
      });
      dom.binList.appendChild(item);
    }
  }

  /**
   * The detail area does double duty: it explains the selected part, and when
   * the cursor is on a placed part it becomes that part's dial.
   */
  function renderBinDetail(occupant, row, lane) {
    const kind = occupant ? occupant.kind : selectedKind;
    const part = catalogue.find((p) => p.kind === kind);
    dom.binDetail.textContent = "";
    if (!part) return;

    const heading = document.createElement("p");
    heading.innerHTML = occupant
      ? `<strong>${part.label}</strong> on row ${row + 1}, lane ${lane}`
      : `<strong>${part.label}</strong>`;
    dom.binDetail.appendChild(heading);

    const blurb = document.createElement("p");
    blurb.textContent = part.blurb;
    dom.binDetail.appendChild(blurb);

    if (part.takesAngle && part.anglePresets.length) {
      const current = occupant
        ? occupant.angle === undefined
          ? part.defaultAngle
          : occupant.angle
        : selectedAngles[kind];
      const dial = document.createElement("div");
      dial.className = "dial";
      const label = document.createElement("span");
      label.textContent = part.angleIsProbability ? "Chance of a kick: " : "Dial: ";
      label.id = `dial-label-${kind}`;
      dial.setAttribute("role", "group");
      dial.setAttribute("aria-labelledby", label.id);
      dial.appendChild(label);
      for (const preset of part.anglePresets) {
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = preset.label;
        button.setAttribute(
          "aria-pressed",
          String(Math.abs(preset.value - current) < 1e-9)
        );
        button.addEventListener("click", () => {
          if (occupant) {
            store.setAngle(row, lane, preset.value);
            announce(`${part.label} set to ${preset.label}.`);
          } else {
            selectedAngles[kind] = preset.value;
            renderBinDetail(null);
            announce(`${part.label} set to ${preset.label} for the next one.`);
          }
        });
        dial.appendChild(button);
      }
      dom.binDetail.appendChild(dial);
    }

    if (occupant) {
      const hint = document.createElement("p");
      hint.textContent = "Backspace takes it off the board.";
      dom.binDetail.appendChild(hint);
    }
  }

  // -------------------------------------------------------------- analysis

  let analyseTimer = null;
  function scheduleAnalyse() {
    window.clearTimeout(analyseTimer);
    analyseTimer = window.setTimeout(analyse, 60);
  }

  async function analyse() {
    const payload = store.forEngine();
    const [analysis, code] = await Promise.all([
      bridge.analyze(payload),
      bridge.code(payload),
    ]);

    if (!analysis.ok) {
      dom.dropReport.innerHTML = `<strong>That board will not run.</strong> ${analysis.error}`;
      return;
    }
    latestAnalysis = analysis;
    if (code.ok) panels.renderCode(code.source);

    const maxRow = store.get().rows.length;
    dom.rowSlider.max = String(maxRow);
    if (shownRow === null || shownRow > maxRow) {
      dom.rowSlider.value = String(maxRow);
    } else {
      dom.rowSlider.value = String(shownRow);
    }
    renderReadout();

    bridge.circuit_text(payload).then((result) => {
      if (result.ok) panels.renderDiagram(result.diagram);
    });
  }

  function renderReadout() {
    if (!latestAnalysis) return;
    const index = Number(dom.rowSlider.value);
    // Rows below the last part do not change the state, so they share its
    // snapshot rather than being missing from the readout.
    const snapshot =
      latestAnalysis.snapshots[Math.min(index, latestAnalysis.snapshots.length - 1)];
    const isLast = index >= Number(dom.rowSlider.max);
    dom.rowSliderValue.textContent = isLast
      ? index === 0
        ? "the start, before any parts"
        : `row ${index} — the last one`
      : index === 0
      ? "the start, before any parts"
      : `row ${index}`;

    panels.renderLaneStates(snapshot, latestAnalysis.lanes);
    panels.renderJoint(snapshot);

    const exact = {};
    for (const entry of snapshot.probabilities) exact[entry.basis] = entry.prob;
    const observed = isLast && lastRun ? lastRun.frequencies : null;
    panels.renderHistogram(
      exact,
      observed,
      observed
        ? `${lastRun.shots.toLocaleString()} shots on ${lastRun.backend}`
        : isLast
        ? "exact, before any run"
        : `exact, part way down the board`
    );

    boardView.setAnalysis(latestAnalysis, index);
    boardView.render();

    if (latestAnalysis.warnings.length) {
      dom.dropReport.innerHTML = latestAnalysis.warnings
        .map((w) => `<strong>Note.</strong> ${w}`)
        .join("<br />");
    }
  }

  // ------------------------------------------------------------------ runs

  async function doDrop() {
    const payload = store.forEngine();
    const button = document.getElementById("drop");
    button.disabled = true;
    const result = await bridge.drop(payload, Math.floor(Math.random() * 1e9));
    if (!result.ok) {
      dom.dropReport.innerHTML = `<strong>Could not drop.</strong> ${result.error}`;
      button.disabled = false;
      return;
    }
    boardView.play(() => {
      button.disabled = false;
      const detectorEvents = result.events.filter((e) => e.kind === "detector");
      const noiseEvents = result.events.filter((e) => e.kind === "noise" && e.fired);
      const pieces = [
        `Landed on <strong>${result.landed.split("").join(" ")}</strong>.`,
      ];
      for (const event of detectorEvents) {
        pieces.push(
          `Detector on lane ${event.lane} read <strong>${event.outcome}</strong>.`
        );
      }
      for (const event of noiseEvents) {
        pieces.push(`Noise kicked lane ${event.lane} with a ${event.pauli}.`);
      }
      if (!detectorEvents.length && !noiseEvents.length) {
        pieces.push("Nothing was read on the way down.");
      }
      dom.dropReport.innerHTML = pieces.join(" ");
      announce(dom.dropReport.textContent);
    });
  }

  async function doRun() {
    const payload = store.forEngine();
    const button = document.getElementById("run");
    const shots = Number(document.getElementById("shots").value);
    button.disabled = true;
    const previous = button.textContent;
    button.textContent = "Running…";
    dom.dropReport.innerHTML = "Submitting the board to the backend…";

    const result = await bridge.run(payload, shots, 32, -1);
    button.disabled = false;
    button.textContent = previous;

    if (!result.ok) {
      dom.dropReport.innerHTML = `<strong>The run did not finish.</strong> ${result.error}`;
      announce(`The run did not finish. ${result.error}`);
      return;
    }
    lastRun = result;
    shownRow = null;
    dom.rowSlider.value = dom.rowSlider.max;
    boardView.play(() => {});

    const notes = [
      `<strong>${result.shots.toLocaleString()}</strong> shots on ${result.backend}, circuit depth ${result.circuitDepth}.`,
    ];
    if (result.noiseMethod === "exact") {
      notes.push(
        `Noise tiles were split into ${result.jobs} exact error patterns covering ${(
          result.noiseMassCovered * 100
        ).toFixed(1)}% of the probability.`
      );
    } else if (result.noiseMethod === "sampled") {
      notes.push(`Noise was sampled over ${result.jobs} random error patterns.`);
    }
    dom.dropReport.innerHTML = notes.join(" ");
    renderReadout();
    announce(`Run finished. ${result.shots} shots on ${result.backend}.`);
  }

  // ------------------------------------------------------------------ acts

  /**
   * Three acts, in the order the ideas make sense.
   *
   * The circuit builder is last on purpose: gates only mean anything once you
   * have seen that a gate is a laser left on for a certain length of time.
   */
  const lab = createLab(document.getElementById("lab"), bridge, { announce });
  lab.setFacts(ionFacts);

  const ACTS = {
    1: { ions: 1, ops: [{ kind: "pulse", ion: 0, theta: Math.PI / 2, phi: 0 }] },
    2: { ions: 2, ops: [{ kind: "ms", theta: 0.25 }] },
  };
  let currentAct = 0;

  function setAct(act) {
    if (act === currentAct) return;
    currentAct = act;
    const inLab = act !== 3;
    document.getElementById("lab").hidden = !inLab;
    document.getElementById("circuit").hidden = inLab;
    for (const id of ["lanes-group", "circuit-run"]) {
      document.getElementById(id).hidden = inLab;
    }
    document.getElementById("guide-label").textContent = inLab ? "Tutorial" : "Guided build";
    document.getElementById("guide-exit").textContent =
      inLab ? "Leave the tutorial" : "Leave the guide";
    populateGuidePicker(act);
    if (inLab) {
      // The lab opens on its tutorial, because "what is a qubit" is the
      // question these acts exist to answer and a blank sandbox does not ask
      // it. Leaving the tutorial drops straight into free experimenting.
      const first = guidesForAct(act)[0];
      dom.guidePicker.value = first ? first.id : "";
      guideState.id = first ? first.id : null;
      guideState.step = 0;
      if (first) renderGuide();
      else { dom.guide.hidden = true; lab.load(ACTS[act]); }
    } else {
      dom.guidePicker.value = "";
      guideState.id = null;
      guideState.step = 0;
      dom.guide.hidden = true;
      boardView.render();
      analyse();
    }
    for (const n of [1, 2, 3]) {
      document.getElementById(`act-${n}`).setAttribute("aria-selected", String(n === act));
    }
    announce(
      act === 1
        ? "One ion. A single ion and one laser."
        : act === 2
        ? "Two ions, coupled by their shared motion."
        : "Circuits. The gate-level builder."
    );
  }

  for (const n of [1, 2, 3]) {
    document.getElementById(`act-${n}`).addEventListener("click", () => setAct(n));
  }

  // --------------------------------------------------------------- legend

  /**
   * The key to the circuit, beside the circuit.
   *
   * Each entry draws the real mark rather than describing it, because the
   * point is to let someone match what they are seeing to what it means.
   */
  function renderLegend() {
    const NS = "http://www.w3.org/2000/svg";
    const swatch = (build, label, meaning) => {
      const item = document.createElement("span");
      item.className = "legend-item";
      const svg = document.createElementNS(NS, "svg");
      svg.setAttribute("width", "34");
      svg.setAttribute("height", "18");
      svg.setAttribute("viewBox", "0 0 34 18");
      svg.setAttribute("aria-hidden", "true");
      build(svg, NS);
      item.appendChild(svg);
      const text = document.createElement("span");
      text.innerHTML = `<b>${label}</b> ${meaning}`;
      item.appendChild(text);
      return item;
    };
    const path = (svg, NS, d, attrs) => {
      const node = document.createElementNS(NS, "path");
      node.setAttribute("d", d);
      for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
      svg.appendChild(node);
    };

    dom.legend.textContent = "";
    dom.legend.appendChild(
      swatch(
        (svg, NS) => path(svg, NS, "M15 1 L19 1 L21 9 L19 17 L15 17 L13 9 Z",
          { fill: phaseColour(0, 0.75) }),
        "Ribbon width",
        "how deep that lane is in superposition"
      )
    );
    dom.legend.appendChild(
      swatch((svg, NS) => {
        path(svg, NS, "M2 4 h13 v10 h-13 Z", { fill: phaseColour(0, 0.85) });
        path(svg, NS, "M19 4 h13 v10 h-13 Z", { fill: phaseColour(Math.PI, 0.85) });
      }, "Amber to teal", "phase: in step, through to opposed")
    );
    dom.legend.appendChild(
      swatch((svg, NS) => {
        path(svg, NS, "M6 1 C6 9, 28 9, 28 17", { fill: "none", stroke: "var(--fused-strand)", "stroke-width": "2.2" });
        path(svg, NS, "M28 1 C28 9, 6 9, 6 17", { fill: "none", stroke: "var(--fused-strand)", "stroke-width": "2.2" });
      }, "Braid", "entangled: no lane has a state of its own")
    );
    dom.legend.appendChild(
      swatch((svg, NS) => {
        path(svg, NS, "M17 9 m-6 0 a6 6 0 1 0 12 0 a6 6 0 1 0 -12 0", { fill: "none", stroke: "var(--ink-soft)", "stroke-width": "1.2" });
        path(svg, NS, "M17 9 L22 5", { stroke: "var(--ink)", "stroke-width": "1.8", "stroke-linecap": "round" });
      }, "Dial hand", "the exact phase angle")
    );
  }

  // ---------------------------------------------------------------- intro

  function openIntro() {
    dom.intro.hidden = false;
    document.getElementById("intro-close").focus();
  }
  function closeIntro() {
    dom.intro.hidden = true;
    document.getElementById("help").focus();
  }

  document.getElementById("help").addEventListener("click", openIntro);
  document.getElementById("intro-close").addEventListener("click", closeIntro);
  document.getElementById("intro-guide").addEventListener("click", () => {
    closeIntro();
    setAct(3);
    dom.guidePicker.value = GUIDES[0].id;
    startGuide(GUIDES[0].id);
  });
  dom.intro.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeIntro();
  });
  dom.intro.addEventListener("click", (event) => {
    if (event.target === dom.intro) closeIntro();
  });

  // ---------------------------------------------------------------- theme

  const themeButton = document.getElementById("theme");
  function setTheme(next) {
    document.documentElement.setAttribute("data-theme", next);
    themeButton.textContent = next === "dark" ? "Light theme" : "Dark theme";
    themeButton.setAttribute("aria-pressed", String(next === "light"));
    boardView.render();
    renderLegend();
    announce(`${next === "dark" ? "Dark" : "Light"} theme.`);
  }
  themeButton.addEventListener("click", () => {
    const current = document.documentElement.getAttribute("data-theme");
    setTheme(current === "dark" ? "light" : "dark");
  });

  // --------------------------------------------------------------- guides

  const guideState = { id: null, step: 0 };

  /** Which guides belong to the act on screen. */
  function guidesForAct(act) {
    return act === 3 ? GUIDES : LAB_GUIDES.filter((g) => g.act === act);
  }

  function populateGuidePicker(act) {
    dom.guidePicker.textContent = "";
    const free = document.createElement("option");
    free.value = "";
    free.textContent = act === 3 ? "Free build" : "Free experiment";
    dom.guidePicker.appendChild(free);
    for (const guide of guidesForAct(act)) {
      const option = document.createElement("option");
      option.value = guide.id;
      option.textContent = guide.title;
      dom.guidePicker.appendChild(option);
    }
  }

  function currentGuide() {
    return guidesForAct(currentAct).find((g) => g.id === guideState.id) || null;
  }

  async function renderGuide() {
    const guide = currentGuide();
    if (!guide) {
      dom.guide.hidden = true;
      placeGuide(null);
      boardView.setHighlight(null);
      if (currentAct === 3) boardView.render();
      return;
    }
    const step = guide.steps[guideState.step];
    dom.guide.hidden = false;
    dom.guideStep.textContent =
      `${guide.title} \u00b7 step ${guideState.step + 1} of ${guide.steps.length}`;
    dom.guideTitle.textContent = step.title;
    dom.guideText.innerHTML = step.body;
    document.getElementById("guide-back").disabled = guideState.step === 0;
    document.getElementById("guide-next").textContent =
      guideState.step === guide.steps.length - 1 ? "Finish" : "Next";

    placeGuide(step);

    if (currentAct === 3) {
      if (step.board) {
        store.load(step.board);
        shownRow = null;
      }
      boardView.setHighlight(step.highlight || null);
      boardView.render();
    } else if (step.spec) {
      await lab.load(step.spec);
      if (step.play) lab.play();
    }
    announce(`${step.title}. ${dom.guideText.textContent}`);
  }

  /**
   * Put the step's words next to the thing they are about.
   *
   * A tutorial bar pinned to the bottom of the window makes you read a
   * sentence, look away to find what it means, and look back. Moving the card
   * into the panel it is describing removes that hop entirely, and the ring
   * around the panel says where to look before you have read anything.
   */
  function placeGuide(step) {
    for (const region of Object.values(lab.regions)) region.classList.remove("focused");
    const target = step && step.focus ? lab.regions[step.focus] : null;
    if (target && currentAct !== 3) {
      target.appendChild(dom.guide);
      target.classList.add("focused");
      dom.guide.classList.add("callout");
      // the card has just moved somewhere else on the page, so take the
      // reader with it rather than leaving them looking at an empty panel
      const smooth = !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      target.scrollIntoView({
        behavior: smooth ? "smooth" : "auto",
        block: "nearest",
        inline: "nearest",
      });
    } else {
      document.body.appendChild(dom.guide);
      dom.guide.classList.remove("callout");
    }
  }

  function startGuide(id) {
    guideState.id = id;
    guideState.step = 0;
    renderGuide();
  }

  // --------------------------------------------------------------- controls

  function syncCounts() {
    const board = store.get();
    dom.lanesCount.textContent = String(board.lanes);
    dom.rowsCount.textContent = String(board.rows.length);
    document.getElementById("lanes-down").disabled = board.lanes <= MIN_LANES;
    document.getElementById("lanes-up").disabled = board.lanes >= MAX_LANES;
    document.getElementById("rows-down").disabled = board.rows.length <= MIN_ROWS;
    document.getElementById("rows-up").disabled = board.rows.length >= MAX_ROWS;
    document.getElementById("undo").disabled = !store.canUndo();
  }

  document.getElementById("lanes-up").addEventListener("click", () => {
    if (store.setLanes(store.get().lanes + 1)) announce(`${store.get().lanes} lanes.`);
  });
  document.getElementById("lanes-down").addEventListener("click", () => {
    if (store.setLanes(store.get().lanes - 1)) announce(`${store.get().lanes} lanes.`);
  });
  document.getElementById("rows-up").addEventListener("click", () => {
    if (store.addRow()) announce(`${store.get().rows.length} rows.`);
  });
  document.getElementById("rows-down").addEventListener("click", () => {
    if (store.removeRow()) announce(`${store.get().rows.length} rows.`);
  });
  document.getElementById("undo").addEventListener("click", () => {
    if (store.undo()) announce("Undone.");
  });
  document.getElementById("clear").addEventListener("click", () => {
    store.clear();
    lastRun = null;
    announce("Board cleared.");
  });
  document.getElementById("drop").addEventListener("click", doDrop);
  document.getElementById("run").addEventListener("click", doRun);
  document.getElementById("copy-code").addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(dom.codeOut.textContent);
      announce("Code copied.");
    } catch {
      announce("Could not reach the clipboard. Select the code and copy it.");
    }
  });
  dom.rowSlider.addEventListener("input", () => {
    shownRow = Number(dom.rowSlider.value);
    renderReadout();
    if (latestAnalysis) {
      announce(
        panels.describe(
          latestAnalysis.snapshots[shownRow],
          dom.rowSliderValue.textContent
        )
      );
    }
  });
  dom.guidePicker.addEventListener("change", (event) => {
    const id = event.target.value || null;
    if (!id && currentAct !== 3) {
      guideState.id = null;
      dom.guide.hidden = true;
      announce("Tutorial closed. The trap is yours.");
      return;
    }
    startGuide(id);
  });
  document.getElementById("guide-next").addEventListener("click", () => {
    const guide = currentGuide();
    if (!guide) return;
    if (guideState.step >= guide.steps.length - 1) {
      dom.guidePicker.value = "";
      guideState.id = null;
      dom.guide.hidden = true;
      announce(
        currentAct === 3
          ? "Guide finished. The circuit is yours."
          : "Tutorial finished. The trap is yours."
      );
      return;
    }
    guideState.step += 1;
    renderGuide();
  });
  document.getElementById("guide-back").addEventListener("click", () => {
    if (guideState.step > 0) {
      guideState.step -= 1;
      renderGuide();
    }
  });
  document.getElementById("guide-exit").addEventListener("click", () => {
    dom.guidePicker.value = "";
    guideState.id = null;
    dom.guide.hidden = true;
    boardView.setHighlight(null);
    if (currentAct === 3) boardView.render();
    announce("Left the tutorial.");
  });

  store.subscribe((_board, change) => {
    if (change.type !== "undo") lastRun = null;
    // Both the drop report and a run's histogram describe a board that no
    // longer exists, so they are cleared rather than left to look current.
    if (change.type !== "angle") dom.dropReport.innerHTML = "";
    // Scrubbing back through the rows pins the readout to one row. An edit has
    // to release that pin, or the part the player just placed sits below the
    // row being shown and looks as though it did nothing.
    shownRow = null;
    syncCounts();
    scheduleAnalyse();
  });

  renderLegend();
  renderBin();
  renderBinDetail(null);
  syncCounts();
  boardView.render();
  await analyse();
  setAct(1);
  openIntro();
}

function showBootError(dom, result) {
  dom.bootError.hidden = false;
  dom.bootError.innerHTML =
    `<h2>The quantum engine did not load</h2>` +
    `<p>${result.error || "Unknown problem."}</p>` +
    (result.detail ? `<pre class="code">${result.detail}</pre>` : "");
}
