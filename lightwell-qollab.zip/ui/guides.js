/**
 * The guided builds.
 *
 * Each step loads a circuit and explains it, but nothing is locked, no part is
 * withheld, and leaving a guide at any point just leaves the circuit as it
 * stands. The sandbox is the product; the guides are a way in.
 *
 * Every circuit here has been checked against the engine, so each claim in the
 * copy is a claim about what the player will actually see on screen.
 */

const PI = Math.PI;

function rows(list, pad = 6) {
  const out = list.map((row) => row.slice());
  while (out.length < pad) out.push([]);
  return out;
}

const SPLIT = (lane) => ({ kind: "splitter", lanes: [lane] });
const PHASE = (lane, angle) => ({ kind: "phase", lanes: [lane], angle });
const FLIP = (lane) => ({ kind: "flipper", lanes: [lane] });
const LINK = (a, b) => ({ kind: "linker", lanes: [a, b] });
const CPHASE = (a, b, angle) => ({ kind: "phaselinker", lanes: [a, b], angle });
const SWAP = (a, b) => ({ kind: "exchange", lanes: [a, b] });
const DETECT = (lane) => ({ kind: "detector", lanes: [lane] });

/** The Fourier staircase on three lanes, verified to do period finding. */
const QFT3 = [
  [SPLIT(0)],
  [CPHASE(1, 0, PI / 2)],
  [CPHASE(2, 0, PI / 4)],
  [SPLIT(1)],
  [CPHASE(2, 1, PI / 2)],
  [SPLIT(2)],
  [SWAP(0, 2)],
];

export const GUIDES = [
  {
    id: "interference",
    title: "Start here: one lane",
    steps: [
      {
        title: "A splitter sends the lane both ways",
        board: { lanes: 1, rows: rows([[SPLIT(0)]]), initial: null },
        highlight: { rows: [0] },
        body:
          "<p>One lane, one splitter. Watch the ribbon: above the splitter it " +
          "is a thin thread, because the lane is simply 0. Below it the ribbon " +
          "swells to its full width, because the lane is now evenly spread " +
          "between 0 and 1.</p>" +
          "<p>Press <b>Run once</b> a few times. You get a 0 or a 1 and you " +
          "cannot predict which. Then press <b>Run on the simulator</b>: a " +
          "thousand shots, half and half.</p>",
      },
      {
        title: "A phase dial changes nothing you can measure",
        board: { lanes: 1, rows: rows([[SPLIT(0)], [PHASE(0, PI)]]), initial: null },
        highlight: { rows: [1] },
        body:
          "<p>The phase dial turns the arrow on the 1 path. The ribbon below " +
          "it changes colour, from amber to teal, and the little hands along " +
          "it swing round. The width does not change at all.</p>" +
          "<p>That is the whole lesson: the odds are still half and half. Try " +
          "the dial at 90 and 45 degrees and the outcome never budges. Phase " +
          "is real, it is visibly there in the trace, and it is doing nothing " +
          "yet, because nothing has brought the two paths back together.</p>",
      },
      {
        title: "Bring the branches back together",
        board: {
          lanes: 1,
          rows: rows([[SPLIT(0)], [PHASE(0, PI)], [SPLIT(0)]]),
          initial: null,
        },
        highlight: { rows: [2] },
        body:
          "<p>A second splitter recombines the paths, and now the phase has " +
          "something to act on. Watch the ribbon collapse back to a thin " +
          "thread below row 3, pinned hard to one side. The result is no " +
          "longer a coin toss: it is <b>1 every single time</b>.</p>" +
          "<p>Set the dial to 0 degrees and it becomes 0 every time instead. " +
          "Nothing was blocked. One path cancelled the other. This is " +
          "interference, and it is the whole engine of quantum computing.</p>",
      },
      {
        title: "Watching it breaks it",
        board: {
          lanes: 1,
          rows: rows([[SPLIT(0)], [DETECT(0)], [SPLIT(0)]]),
          initial: null,
        },
        highlight: { rows: [1] },
        body:
          "<p>The same circuit, with a detector between the splitters. The " +
          "certainty is gone and you are back to half and half.</p>" +
          "<p>Look at the ribbon below the detector: it is still wide, but the " +
          "phase hands have gone. Reading the lane forced it to pick a path, " +
          "so there were never two paths at the end to cancel. Keeping the " +
          "paths unread is not a technicality; it is the resource being " +
          "spent.</p>",
      },
    ],
  },

  {
    id: "deutsch-jozsa",
    title: "Build Deutsch-Jozsa",
    steps: [
      {
        title: "A question with a hidden rule",
        board: {
          lanes: 2,
          rows: rows([[FLIP(1)], [SPLIT(0), SPLIT(1)], [], [SPLIT(0)]]),
          initial: null,
        },
        highlight: { rows: [2] },
        body:
          "<p>Here is a machine with a gap in it. Lane 0 asks a question, lane " +
          "1 carries the answer, and the empty row 3 is where a hidden rule " +
          "goes.</p>" +
          "<p>The rule is one of two kinds. It either <b>ignores</b> the " +
          "question and always gives the same answer, or it <b>follows</b> the " +
          "question. Your job is to find out which kind it is.</p>" +
          "<p>Classically you must ask twice: put in 0, put in 1, compare. " +
          "One question is never enough. Watch what this board does.</p>",
      },
      {
        title: "The rule that ignores the question",
        board: {
          lanes: 2,
          rows: rows([[FLIP(1)], [SPLIT(0), SPLIT(1)], [], [SPLIT(0)]]),
          initial: null,
        },
        highlight: { rows: [3] },
        body:
          "<p>An empty slot is a rule that ignores the question: whatever you " +
          "ask, the answer lane is untouched.</p>" +
          "<p>Run it. You will see two bars, 00 and 01, at half each. Read only " +
          "the first digit: <b>lane 0 is 0 in both</b>. Lane 1 comes out " +
          "scrambled and carries nothing, which is why it is the answer lane " +
          "and not the one you read.</p>" +
          "<p>So lane 0 reads 0. Not usually. Every time.</p>",
      },
      {
        title: "The rule that follows the question",
        board: {
          lanes: 2,
          rows: rows([[FLIP(1)], [SPLIT(0), SPLIT(1)], [LINK(0, 1)], [SPLIT(0)]]),
          initial: null,
        },
        highlight: { rows: [2] },
        body:
          "<p>Now put a linker in the slot. That is a rule that follows the " +
          "question: ask 1 and the answer flips.</p>" +
          "<p>Run it. The bars have moved to 10 and 11, so again read only the " +
          "first digit: <b>lane 0 is now 1 in both</b>.</p>" +
          "<p>One drop. One question. And lane 0 told you which kind of rule " +
          "is hidden in the box, which is something no single classical " +
          "question can do.</p>",
      },
      {
        title: "Where the answer came from",
        board: {
          lanes: 2,
          rows: rows([[FLIP(1)], [SPLIT(0), SPLIT(1)], [LINK(0, 1)], [SPLIT(0)]]),
          initial: null,
        },
        body:
          "<p>Look at row 3 in the circuit. The two ribbons stop dead and a " +
          "braid takes over, then they re-emerge below the last splitter. For " +
          "those rows neither lane had a state of its own, so there was " +
          "nothing per-lane left to draw.</p>" +
          "<p>The rule could not change the odds on lane 0, so it did the only " +
          "other thing available: it changed lane 0's <b>phase</b>. Invisible, " +
          "until the last splitter turned that phase into a certain answer.</p>" +
          "<p>Hide information in phases, then interfere to read it out. Every " +
          "algorithm on the next two guides is a variation on that one move.</p>",
      },
    ],
  },

  {
    id: "grover",
    title: "Build Grover's search",
    steps: [
      {
        title: "Four possibilities, no favourites",
        board: {
          lanes: 2,
          rows: rows([[SPLIT(0), SPLIT(1)]]),
          initial: null,
        },
        highlight: { rows: [0] },
        body:
          "<p>Two lanes, two splitters, and now four combinations at once: " +
          "00, 01, 10, 11. Both ribbons run at full width. Run it and the " +
          "histogram is flat, a quarter each.</p>" +
          "<p>One of these is the answer we are hunting. Searching a list of " +
          "four by hand takes up to four looks. This board will do it in one.</p>",
      },
      {
        title: "Mark the one you want",
        board: {
          lanes: 2,
          rows: rows([[SPLIT(0), SPLIT(1)], [CPHASE(0, 1, PI)]]),
          initial: null,
        },
        highlight: { rows: [1] },
        body:
          "<p>A phase linker set to 180 degrees marks the combination 11: it " +
          "turns that one arrow around and leaves the other three alone. The " +
          "lanes braid, and in the readout you can see four clock hands, one " +
          "per combination, with a single one pointing the opposite way.</p>" +
          "<p>Run it. The histogram is <b>still flat</b>. Marking the answer " +
          "did not make it any more likely, exactly as the phase dial on one " +
          "lane changed nothing on its own.</p>",
      },
      {
        title: "Turn the mark into an answer",
        board: {
          lanes: 2,
          rows: rows([
            [SPLIT(0), SPLIT(1)],
            [CPHASE(0, 1, PI)],
            [SPLIT(0), SPLIT(1)],
            [FLIP(0), FLIP(1)],
            [CPHASE(0, 1, PI)],
            [FLIP(0), FLIP(1)],
            [SPLIT(0), SPLIT(1)],
          ]),
          initial: null,
        },
        highlight: { rows: [2, 3, 4, 5, 6] },
        body:
          "<p>Rows 3 to 7 are a mirror. They reflect every arrow about the " +
          "average, which leaves the three unmarked combinations small and " +
          "swings the marked one wide. Watch the clock hands in the readout " +
          "as you step the slider through those rows.</p>" +
          "<p>Run it. <b>11 comes up every time</b>, with the other three at " +
          "exactly zero. On four possibilities one pass is enough to be " +
          "certain.</p>" +
          "<p>Change the mark to a different combination by putting flippers " +
          "around the phase linker in row 2, and the board will find that one " +
          "instead.</p>",
      },
      {
        title: "Why it stops being free",
        board: {
          lanes: 2,
          rows: rows([
            [SPLIT(0), SPLIT(1)],
            [CPHASE(0, 1, PI)],
            [SPLIT(0), SPLIT(1)],
            [FLIP(0), FLIP(1)],
            [CPHASE(0, 1, PI)],
            [FLIP(0), FLIP(1)],
            [SPLIT(0), SPLIT(1)],
            [{ kind: "noise", lanes: [0], angle: 0.05 }],
          ]),
          initial: null,
        },
        highlight: { rows: [7] },
        body:
          "<p>One noise tile at 5 percent, and the certainty starts leaking. " +
          "Run it: a wrong answer, 01, now turns up in about three runs in a " +
          "hundred. The tile sits on lane 0, so lane 0 is the digit that " +
          "flips.</p>" +
          "<p>Grover's advantage is a quadratic one, so it needs many passes " +
          "on a real problem, and every pass is more board for noise to chew " +
          "on. That gap between the clean board and the noisy one is the whole " +
          "reason error correction is the field's central problem.</p>",
      },
    ],
  },

  {
    id: "fourier",
    title: "Build the engine inside Shor",
    steps: [
      {
        title: "A pattern that repeats",
        board: {
          lanes: 3,
          rows: rows([[SPLIT(0), SPLIT(1)]], 10),
          initial: null,
        },
        highlight: { rows: [0] },
        body:
          "<p>Three lanes count from 0 to 7. Read the outcomes as numbers with " +
          "lane 0 as the highest digit, and this circuit holds 0, 2, 4 and 6 " +
          "at once: a pattern that <b>repeats every 2 steps</b>.</p>" +
          "<p>Shor's algorithm reduces factoring a number to exactly this " +
          "question. Not \"what are the factors\" but \"how often does this " +
          "pattern repeat\". Find the repeat and simple arithmetic finishes " +
          "the job.</p>",
      },
      {
        title: "The Fourier staircase",
        board: {
          lanes: 3,
          rows: rows([[SPLIT(0), SPLIT(1)], ...QFT3], 10),
          initial: null,
        },
        highlight: { rows: [1, 2, 3, 4, 5, 6, 7] },
        body:
          "<p>Rows 2 to 8 are the quantum Fourier transform: splitters with a " +
          "staircase of phase linkers between them, each turning its arrow half " +
          "as far as the one before, and a crossover to put the lanes back in " +
          "order.</p>" +
          "<p>Run it. Out of eight possible outcomes, only <b>0 and 4</b> " +
          "survive. <b>Two peaks</b>, for a pattern that repeats every 2.</p>",
      },
      {
        title: "Count the peaks, read the period",
        board: {
          lanes: 3,
          rows: rows([[SPLIT(0)], ...QFT3], 10),
          initial: null,
        },
        highlight: { rows: [0] },
        body:
          "<p>Now the input is only 0 and 4, a pattern that repeats every 4 " +
          "steps. Run it: <b>four peaks</b>, at 0, 2, 4 and 6.</p>" +
          "<p>Put a splitter on lane 2 as well, so every number is in play, " +
          "and you get a <b>single peak</b> at 0.</p>" +
          "<p>The rule is exact: the staircase turns a pattern repeating every " +
          "d steps into exactly d peaks. Count the peaks and you have the " +
          "period, from one run.</p>",
      },
      {
        title: "What this is and is not",
        board: {
          lanes: 3,
          rows: rows([[SPLIT(0), SPLIT(1)], ...QFT3], 10),
          initial: null,
        },
        body:
          "<p>You have built the quantum half of Shor's algorithm. The part " +
          "that finds a period by interference is the part you just ran, and " +
          "it is the only part of Shor that is quantum at all. Everything " +
          "else, the arithmetic that turns a period into factors, is ordinary " +
          "classical maths.</p>" +
          "<p>What is missing is the hard part. A real Shor run has to build " +
          "the repeating pattern from the number being factored, which takes " +
          "thousands of lanes and far deeper boards than anything here. That " +
          "is why no one has factored a useful number this way.</p>" +
          "<p>Add a noise tile and run it again. The peaks blur, and you can " +
          "see the problem the whole industry is working on.</p>",
      },
    ],
  },
];
