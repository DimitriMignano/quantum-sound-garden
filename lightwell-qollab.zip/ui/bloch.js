/**
 * A Bloch sphere you can watch move.
 *
 * The point of this view is that a gate is not a jump between two pictures.
 * A laser pulse drives the state continuously around an axis, and which gate
 * you get depends only on when you stop: half a turn is a bit flip, a quarter
 * turn is an even superposition. So the sphere draws three things at once --
 * where the state is, the axis it is being driven around, and the arc it has
 * swept so far -- and the interface plays the real intermediate states through
 * it rather than crossfading between endpoints.
 *
 * The projection is a plain orthographic one from a fixed viewpoint. Anything
 * on the far side of the sphere is drawn faint, which is what makes it read as
 * a ball rather than a circle with lines in it.
 */

const NS = "http://www.w3.org/2000/svg";

const AZIMUTH = -0.62;
const ELEVATION = 0.32;

function el(name, attrs = {}, children = []) {
  const node = document.createElementNS(NS, name);
  for (const [k, v] of Object.entries(attrs)) {
    if (v !== undefined && v !== null) node.setAttribute(k, String(v));
  }
  for (const child of [].concat(children)) if (child) node.appendChild(child);
  return node;
}

/** Orthographic projection, plus a depth so the far side can be dimmed. */
export function project([x, y, z], radius, cx, cy) {
  const sa = Math.sin(AZIMUTH);
  const ca = Math.cos(AZIMUTH);
  const se = Math.sin(ELEVATION);
  const ce = Math.cos(ELEVATION);
  const right = [-sa, ca, 0];
  const up = [-ca * se, -sa * se, ce];
  const fwd = [ca * ce, sa * ce, se];
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const v = [x, y, z];
  return {
    x: cx + radius * dot(v, right),
    y: cy - radius * dot(v, up),
    depth: dot(v, fwd),
  };
}

/** A great circle, split into the half nearest the viewer and the half behind. */
function circlePath(normalAxis, radius, cx, cy, samples = 72) {
  const basis =
    normalAxis === "z"
      ? [[1, 0, 0], [0, 1, 0]]
      : normalAxis === "x"
      ? [[0, 1, 0], [0, 0, 1]]
      : [[1, 0, 0], [0, 0, 1]];
  const front = [];
  const back = [];
  for (let i = 0; i <= samples; i += 1) {
    const t = (i / samples) * Math.PI * 2;
    const point = [0, 1, 2].map(
      (k) => basis[0][k] * Math.cos(t) + basis[1][k] * Math.sin(t)
    );
    const p = project(point, radius, cx, cy);
    (p.depth >= 0 ? front : back).push(p);
  }
  const toPath = (pts) =>
    pts.length < 2
      ? ""
      : `M ${pts.map((p) => `${p.x.toFixed(2)} ${p.y.toFixed(2)}`).join(" L ")}`;
  return { front: toPath(front), back: toPath(back) };
}

export function createBloch(host, options = {}) {
  const size = options.size || 230;
  const width = size * 1.32;
  const radius = size * 0.30;
  const cx = size * 0.46;
  const cy = size * 0.52;
  const rulerX = size * 1.12;

  const svg = el("svg", {
    width: "100%",
    viewBox: `0 0 ${width} ${size}`,
    class: "bloch",
    "aria-hidden": "true",
    focusable: "false",
  });
  host.appendChild(svg);

  function draw(state) {
    while (svg.firstChild) svg.removeChild(svg.firstChild);
    const {
      bloch = [0, 0, 1],
      axis = null,
      arc = null,
      dim = false,
      mixed = false,
    } = state || {};

    // the ball: outline, equator, and the meridian facing the viewer
    svg.appendChild(
      el("circle", { cx, cy, r: radius, fill: "var(--bloch-fill)", stroke: "none" })
    );
    for (const plane of ["z", "y"]) {
      const { front, back } = circlePath(plane, radius, cx, cy);
      if (back) {
        svg.appendChild(
          el("path", { d: back, fill: "none", stroke: "var(--bloch-grid)", "stroke-width": 1, opacity: 0.35 })
        );
      }
      if (front) {
        svg.appendChild(
          el("path", { d: front, fill: "none", stroke: "var(--bloch-grid)", "stroke-width": 1, opacity: 0.9 })
        );
      }
    }
    svg.appendChild(
      el("circle", { cx, cy, r: radius, fill: "none", stroke: "var(--bloch-rim)", "stroke-width": 1.3 })
    );

    // the 0/1 axis, which is the only axis a measurement can ask about
    const top = project([0, 0, 1], radius, cx, cy);
    const bottom = project([0, 0, -1], radius, cx, cy);
    svg.appendChild(
      el("line", {
        x1: top.x, y1: top.y, x2: bottom.x, y2: bottom.y,
        stroke: "var(--bloch-grid)", "stroke-width": 1, "stroke-dasharray": "3 3",
      })
    );
    // The poles are the two energy levels next door, named the same way, so
    // the ball and the level diagram are visibly the same two states.
    svg.appendChild(
      el("text", { x: top.x, y: top.y - 15, "text-anchor": "middle", class: "bloch-pole" },
        [document.createTextNode("entirely F = 0")])
    );
    svg.appendChild(
      el("text", { x: top.x, y: top.y - 6, "text-anchor": "middle", class: "bloch-pole-sub" },
        [document.createTextNode("always reads dark")])
    );
    svg.appendChild(
      el("text", { x: bottom.x, y: bottom.y + 13, "text-anchor": "middle", class: "bloch-pole" },
        [document.createTextNode("entirely F = 1")])
    );
    svg.appendChild(
      el("text", { x: bottom.x, y: bottom.y + 22, "text-anchor": "middle", class: "bloch-pole-sub" },
        [document.createTextNode("always reads bright")])
    );

    // the axis the drive is turning the state around
    if (axis) {
      const a = project(axis.map((v) => v * 1.15), radius, cx, cy);
      const b = project(axis.map((v) => -v * 1.15), radius, cx, cy);
      svg.appendChild(
        el("line", {
          x1: a.x, y1: a.y, x2: b.x, y2: b.y,
          stroke: "var(--drive)", "stroke-width": 1.6, "stroke-dasharray": "5 4", opacity: 0.95,
        })
      );
      svg.appendChild(el("circle", { cx: a.x, cy: a.y, r: 2.6, fill: "var(--drive)" }));
    }

    // where it has been since the pulse started
    if (arc && arc.length > 1) {
      const pts = arc.map((p) => project(p, radius, cx, cy));
      svg.appendChild(
        el("path", {
          d: `M ${pts.map((p) => `${p.x.toFixed(2)} ${p.y.toFixed(2)}`).join(" L ")}`,
          fill: "none", stroke: "var(--drive)", "stroke-width": 2, opacity: 0.55,
          "stroke-linecap": "round",
        })
      );
    }

    // the state itself
    const length = Math.hypot(bloch[0], bloch[1], bloch[2]);
    const tip = project(bloch, radius, cx, cy);
    const foot = project([bloch[0], bloch[1], 0], radius, cx, cy);
    const colour = dim ? "var(--ink-faint)" : "var(--bloch-arrow)";

    if (length > 0.02) {
      svg.appendChild(
        el("line", {
          x1: tip.x, y1: tip.y, x2: foot.x, y2: foot.y,
          stroke: colour, "stroke-width": 1, "stroke-dasharray": "2 3", opacity: 0.45,
        })
      );
      svg.appendChild(
        el("line", {
          x1: cx, y1: cy, x2: tip.x, y2: tip.y,
          stroke: colour, "stroke-width": 2.6, "stroke-linecap": "round",
        })
      );
      const angle = Math.atan2(tip.y - cy, tip.x - cx);
      const head = 7;
      svg.appendChild(
        el("path", {
          d:
            `M ${tip.x} ${tip.y} ` +
            `L ${tip.x - head * Math.cos(angle - 0.4)} ${tip.y - head * Math.sin(angle - 0.4)} ` +
            `L ${tip.x - head * Math.cos(angle + 0.4)} ${tip.y - head * Math.sin(angle + 0.4)} Z`,
          fill: colour,
        })
      );
    }

    // a state that is part noise has a short arrow, so say so rather than
    // letting it look like a state pointing somewhere odd
    if (mixed) {
      svg.appendChild(
        el("circle", {
          cx, cy, r: Math.max(3, radius * length),
          fill: "var(--bloch-arrow)", opacity: 0.1, stroke: "var(--bloch-arrow)",
          "stroke-width": 0.8, "stroke-dasharray": "2 3",
        })
      );
    }
    svg.appendChild(el("circle", { cx, cy, r: 2, fill: colour }));

    // The arrow's height is the only thing a measurement can ask about, so it
    // gets a ruler: the chance of reading bright, read straight off the
    // vertical position. Everything else about the arrow is phase.
    const pBright = (1 - bloch[2]) / 2;
    const rulerTop = cy - radius;
    const rulerBottom = cy + radius;
    svg.appendChild(
      el("line", {
        x1: rulerX, y1: rulerTop, x2: rulerX, y2: rulerBottom,
        stroke: "var(--bloch-rim)", "stroke-width": 1.2,
      })
    );
    for (const [frac, label] of [[0, "0%"], [0.5, "50%"], [1, "100%"]]) {
      const y = rulerTop + frac * (rulerBottom - rulerTop);
      svg.appendChild(
        el("line", { x1: rulerX - 3, y1: y, x2: rulerX + 3, y2: y,
          stroke: "var(--bloch-rim)", "stroke-width": 1.2 })
      );
      svg.appendChild(
        el("text", { x: rulerX + 7, y: y + 3, class: "bloch-tick" },
          [document.createTextNode(label)])
      );
    }
    const markY = rulerTop + pBright * (rulerBottom - rulerTop);
    svg.appendChild(
      el("line", {
        x1: tip.x, y1: tip.y, x2: rulerX - 4, y2: markY,
        stroke: "var(--detect)", "stroke-width": 1, "stroke-dasharray": "2 3", opacity: 0.75,
      })
    );
    svg.appendChild(
      el("path", {
        d: `M ${rulerX - 4} ${markY} l -5 -3.5 l 0 7 Z`,
        fill: "var(--detect)",
      })
    );
    svg.appendChild(
      el("text", { x: rulerX - 2, y: rulerTop - 20, "text-anchor": "middle", class: "bloch-tick" },
        [document.createTextNode("chance of")])
    );
    svg.appendChild(
      el("text", { x: rulerX - 2, y: rulerTop - 11, "text-anchor": "middle", class: "bloch-tick" },
        [document.createTextNode("bright")])
    );

    // the way it points around the vertical, which the ruler cannot see
    const equatorial = Math.hypot(bloch[0], bloch[1]);
    if (equatorial > 0.03) {
      const phase = Math.atan2(bloch[1], bloch[0]);
      const ring = [];
      for (let t = 0; t <= 1; t += 1 / 24) {
        const a = phase * t;
        ring.push(project([Math.cos(a) * 0.42, Math.sin(a) * 0.42, 0], radius, cx, cy));
      }
      if (ring.length > 1) {
        svg.appendChild(
          el("path", {
            d: `M ${ring.map((p) => `${p.x.toFixed(2)} ${p.y.toFixed(2)}`).join(" L ")}`,
            fill: "none", stroke: "var(--drive)", "stroke-width": 1.6, opacity: 0.8,
          })
        );
      }
    }
  }

  draw({ bloch: [0, 0, 1] });
  return { draw, svg };
}
