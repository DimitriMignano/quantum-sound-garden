/**
 * The lab: one or two ytterbium ions in a trap, and the lasers that drive them.
 *
 * This is the part of the project that tries to answer "what is a qubit"
 * before any circuit appears. Two panels sit side by side and the gap between
 * them is the lesson:
 *
 *   The trap shows what you could actually see. An ion in |0>, an ion in |1>
 *   and an ion in superposition all look identical in there -- you cannot see
 *   a superposition, and the apparatus never pretends otherwise. Only the
 *   detection laser makes an ion bright or dark.
 *
 *   The sphere shows what the maths says is going on, which no camera can
 *   show you. A pulse drives the state continuously around an axis set by the
 *   laser's phase, and the animation plays the real intermediate states.
 *
 * Readout is a strip of simulated camera exposures, because that is literally
 * what a trapped-ion measurement is: shine 369.5 nm light and photograph which
 * ions scattered it.
 */

import { createBloch } from "./bloch.js";
import { createLevels } from "./levels.js";

const NS = "http://www.w3.org/2000/svg";
const TAU = Math.PI * 2;

function el(name, attrs = {}, children = []) {
  const node = document.createElementNS(NS, name);
  for (const [k, v] of Object.entries(attrs)) {
    if (v !== undefined && v !== null) node.setAttribute(k, String(v));
  }
  for (const child of [].concat(children)) if (child) node.appendChild(child);
  return node;
}

function tag(name, className, text) {
  const node = document.createElement(name);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

const turnsLabel = (theta) => {
  const t = theta / TAU;
  if (Math.abs(t - 0.25) < 1e-6) return "quarter turn";
  if (Math.abs(t - 0.5) < 1e-6) return "half turn";
  if (Math.abs(t - 1) < 1e-6) return "full turn";
  if (Math.abs(t) < 1e-6) return "no turn";
  return `${t.toFixed(2)} turn`;
};
const degLabel = (phi) => `${Math.round((((phi / TAU) * 360) % 360 + 360) % 360)}°`;

export function createLab(host, bridge, options = {}) {
  const announce = options.announce || (() => {});
  const state = {
    ions: 1,
    ops: [{ kind: "pulse", ion: 0, theta: Math.PI / 2, phi: 0 }],
    selected: 0,
    trajectory: null,
    frame: 0,
    playing: false,
    camera: null,
    facts: options.facts || {},
  };

  // ---------------------------------------------------------------- layout

  host.textContent = "";
  const grid = tag("div", "lab-grid");

  const apparatus = tag("section", "lab-panel apparatus");
  apparatus.appendChild(tag("h2", null, "The trap"));
  const apparatusNote = tag("p", "panel-note");
  apparatus.appendChild(apparatusNote);
  const trapHost = tag("div", "trap-host");
  apparatus.appendChild(trapHost);
  const trapSvg = el("svg", { viewBox: "0 0 580 246", class: "trap", "aria-hidden": "true" });
  trapHost.appendChild(trapSvg);
  const apparatusCaption = tag("p", "apparatus-caption");
  apparatus.appendChild(apparatusCaption);
  const levelPanel = tag("section", "lab-panel levelpanel");
  levelPanel.appendChild(tag("h2", null, "The energy levels"));
  const levelNote = tag("p", "panel-note");
  levelPanel.appendChild(levelNote);
  const levelsHost = tag("div", "levels-host");
  levelPanel.appendChild(levelsHost);
  const levels = createLevels(levelsHost);
  const levelsCaption = tag("p", "apparatus-caption");
  levelPanel.appendChild(levelsCaption);
  const factList = tag("dl", "facts");
  levelPanel.appendChild(factList);

  const statePanel = tag("section", "lab-panel statepanel");
  statePanel.appendChild(tag("h2", null, "The state"));
  const stateNote = tag("p", "panel-note");
  statePanel.appendChild(stateNote);
  const spheres = tag("div", "spheres");
  statePanel.appendChild(spheres);
  const sphereKey = tag("p", "apparatus-caption");
  sphereKey.innerHTML =
    "<b>What the ball is.</b> Every state this ion can be in is one point on " +
    "it. <b>Height</b> is the only thing a measurement can ask about \u2014 read " +
    "it off the ruler. <b>Which way it points around</b> is the phase: no " +
    "camera can see it, and it decides whether two pulses add up or cancel.";
  statePanel.appendChild(sphereKey);
  const stateNumbers = tag("div", "state-numbers");
  statePanel.appendChild(stateNumbers);

  grid.appendChild(apparatus);
  grid.appendChild(levelPanel);
  grid.appendChild(statePanel);
  host.appendChild(grid);

  const sequence = tag("section", "lab-panel sequence");
  const seqHead = tag("div", "seq-head");
  seqHead.appendChild(tag("h2", null, "Pulse sequence"));
  const seqTools = tag("div", "seq-tools");
  seqHead.appendChild(seqTools);
  sequence.appendChild(seqHead);
  const timeline = tag("div", "timeline");
  sequence.appendChild(timeline);
  const controls = tag("div", "step-controls");
  sequence.appendChild(controls);
  host.appendChild(sequence);

  const cameraPanel = tag("section", "lab-panel camera");
  const camHead = tag("div", "seq-head");
  camHead.appendChild(tag("h2", null, "The camera"));
  const camTools = tag("div", "seq-tools");
  camHead.appendChild(camTools);
  cameraPanel.appendChild(camHead);
  const camNote = tag("p", "panel-note");
  cameraPanel.appendChild(camNote);
  const camStrip = tag("div", "cam-strip");
  cameraPanel.appendChild(camStrip);
  const camSummary = tag("div", "cam-summary");
  cameraPanel.appendChild(camSummary);
  const camTable = tag("table", "sr-only");
  cameraPanel.appendChild(camTable);
  host.appendChild(cameraPanel);

  const blochViews = [];

  // --------------------------------------------------------------- buttons

  function button(label, className, onClick) {
    const b = tag("button", className || "btn btn-quiet", label);
    b.type = "button";
    b.addEventListener("click", onClick);
    return b;
  }

  const playButton = button("Fire the sequence", "btn btn-primary", () => play());
  seqTools.appendChild(playButton);
  seqTools.appendChild(button("+ pulse", "btn btn-quiet", () => addOp({
    kind: "pulse", ion: 0, theta: Math.PI / 2, phi: 0,
  })));
  const msButton = button("+ entangle", "btn btn-quiet", () => addOp({ kind: "ms", theta: 0.25 }));
  seqTools.appendChild(msButton);
  seqTools.appendChild(button("+ shift", "btn btn-quiet", () => addOp({
    kind: "shift", ion: 0, alpha: Math.PI,
  })));
  seqTools.appendChild(button("+ detect", "btn btn-quiet", () => addOp({ kind: "detect" })));
  seqTools.appendChild(button("Clear", "btn btn-quiet", () => {
    state.ops = [];
    state.selected = -1;
    refresh();
    announce("Sequence cleared.");
  }));

  const shotsSelect = document.createElement("select");
  for (const n of [20, 100, 400]) {
    const option = document.createElement("option");
    option.value = String(n);
    option.textContent = `${n} shots`;
    if (n === 100) option.selected = true;
    shotsSelect.appendChild(option);
  }
  shotsSelect.setAttribute("aria-label", "How many exposures to take");
  camTools.appendChild(shotsSelect);
  camTools.appendChild(button("Expose", "btn", () => expose()));
  const runButton = button("Run on the simulator", "btn btn-primary", () => runBackend());
  camTools.appendChild(runButton);

  // ------------------------------------------------------------ the trap

  /**
   * The apparatus, drawn as what it is: two electrode blades, ions held in
   * the gap, and whichever laser is firing at this moment.
   */
  function drawTrap(frame, op, fraction) {
    while (trapSvg.firstChild) trapSvg.removeChild(trapSvg.firstChild);
    const midY = 108;
    const spacing = 96;
    const centre = 290;
    const positions = [];
    for (let i = 0; i < state.ions; i += 1) {
      positions.push(centre + (i - (state.ions - 1) / 2) * spacing);
    }

    // ions sit in a shared trap, so an entangling drive makes them breathe
    // against each other -- the coupling is literally mechanical
    let wobble = 0;
    if (op && op.kind === "ms") {
      wobble = Math.sin(fraction * TAU * 3) * 13;
    }

    for (const [y, flip] of [[46, 1], [170, -1]]) {
      trapSvg.appendChild(
        el("path", {
          d: `M 70 ${y} L 510 ${y} L 480 ${y + flip * 26} L 100 ${y + flip * 26} Z`,
          fill: "var(--electrode)", stroke: "var(--electrode-edge)", "stroke-width": 1.5,
        })
      );
    }
    trapSvg.appendChild(
      el("text", { x: 78, y: 38, class: "trap-label" }, [document.createTextNode("electrode")])
    );
    trapSvg.appendChild(
      el("line", {
        x1: 86, y1: midY, x2: 494, y2: midY,
        stroke: "var(--electrode-edge)", "stroke-width": 1, "stroke-dasharray": "3 5", opacity: 0.6,
      })
    );

    // the drive beam, when one is firing
    if (op && (op.kind === "pulse" || op.kind === "ms")) {
      const targets = op.kind === "ms" ? positions : [positions[op.ion] ?? positions[0]];
      for (const x of targets) {
        trapSvg.appendChild(
          el("path", {
            d: `M 0 ${midY - 26} L ${x} ${midY - 7} L ${x} ${midY + 7} L 0 ${midY + 26} Z`,
            fill: "var(--drive)", opacity: 0.17,
          })
        );
        trapSvg.appendChild(
          el("line", { x1: 0, y1: midY, x2: x, y2: midY, stroke: "var(--drive)", "stroke-width": 1.6, opacity: 0.85 })
        );
      }
      trapSvg.appendChild(
        el("text", { x: 6, y: midY - 32, class: "beam-label" },
          [document.createTextNode(`${state.facts.driveNm || 355} nm drive`)])
      );
    }

    // the detection beam, and the camera it lands on
    const detecting = op && op.kind === "detect";
    if (detecting) {
      for (const x of positions) {
        trapSvg.appendChild(
          el("path", {
            d: `M ${x - 10} 0 L ${x + 10} 0 L ${x + 7} ${midY} L ${x - 7} ${midY} Z`,
            fill: "var(--detect)", opacity: 0.22,
          })
        );
      }
      trapSvg.appendChild(
        el("text", { x: 300, y: 14, class: "beam-label", "text-anchor": "middle" },
          [document.createTextNode(`${state.facts.detectNm || 369.5} nm detection`)])
      );
    }

    // the ions
    state.ions && positions.forEach((x, index) => {
      const shift = op && op.kind === "ms" ? wobble * (index === 0 ? -1 : 1) : 0;
      const ionInfo = frame ? frame.ions[index] : null;
      const driven = op && (op.kind === "ms" || (op.kind === "pulse" && op.ion === index));
      const revealed = detecting && frame ? frame.ions[index] : null;

      if (driven) {
        trapSvg.appendChild(
          el("circle", { cx: x + shift, cy: midY, r: 19, fill: "var(--drive)", opacity: 0.18 })
        );
      }
      if (revealed) {
        // after a detection the ion really is one or the other
        const bright = revealed.pBright > 0.5;
        if (bright) {
          trapSvg.appendChild(el("circle", { cx: x + shift, cy: midY, r: 22, fill: "var(--detect)", opacity: 0.28 }));
          trapSvg.appendChild(el("circle", { cx: x + shift, cy: midY, r: 13, fill: "var(--detect)", opacity: 0.55 }));
        }
      }
      trapSvg.appendChild(
        el("circle", {
          cx: x + shift, cy: midY, r: 8,
          fill: "var(--ion)", stroke: "var(--ion-edge)", "stroke-width": 1.5,
        })
      );
      trapSvg.appendChild(
        el("text", { x: x + shift, y: midY + 34, "text-anchor": "middle", class: "trap-label" },
          [document.createTextNode(`ion ${index}`)])
      );
    });

    // the shared motion that carries an entangling gate
    if (op && op.kind === "ms" && positions.length === 2) {
      const [a, b] = positions;
      trapSvg.appendChild(
        el("path", {
          d: `M ${a} ${midY + 86} Q ${(a + b) / 2} ${midY + 100 + wobble}, ${b} ${midY + 86}`,
          fill: "none", stroke: "var(--fused-strand)", "stroke-width": 2, "stroke-dasharray": "4 4",
        })
      );
      trapSvg.appendChild(
        el("text", { x: (a + b) / 2, y: midY + 122, "text-anchor": "middle", class: "motion-label" },
          [document.createTextNode("the ions push on each other: this shared motion carries the coupling")])
      );
      for (const [x, dir] of [[a, -1], [b, 1]]) {
        const sign = Math.sign(wobble) || 1;
        const from = x + dir * wobble;
        trapSvg.appendChild(
          el("path", {
            d: `M ${from + dir * sign * 14} ${midY + 54} l ${dir * sign * 7} 0 m 0 0 l ${-dir * sign * 3} -3 m 3 3 l ${-dir * sign * 3} 3`,
            stroke: "var(--fused-strand)", "stroke-width": 1.6, fill: "none",
            "stroke-linecap": "round", opacity: 0.85,
          })
        );
      }
    }
  }

  // --------------------------------------------------------------- render

  function currentFrame() {
    if (!state.trajectory) return null;
    const frames = state.trajectory.frames;
    return frames[Math.min(state.frame, frames.length - 1)] || null;
  }

  function currentOp() {
    const frame = currentFrame();
    if (!frame || frame.op < 0) return null;
    return state.ops[frame.op] || null;
  }

  /** The axis the drive is turning the state about, for the sphere. */
  function driveAxis(op) {
    if (!op) return null;
    if (op.kind === "pulse") return [Math.cos(op.phi), Math.sin(op.phi), 0];
    if (op.kind === "shift") return [0, 0, 1];
    return null;
  }

  /** The path swept so far within the operation being played. */
  function sweptArc(ionIndex) {
    if (!state.trajectory) return null;
    const frames = state.trajectory.frames;
    const here = frames[Math.min(state.frame, frames.length - 1)];
    if (!here || here.op < 0) return null;
    const arc = [];
    for (let i = 0; i <= Math.min(state.frame, frames.length - 1); i += 1) {
      if (frames[i].op !== here.op) continue;
      const ion = frames[i].ions[ionIndex];
      if (ion && ion.own_state) arc.push(ion.bloch);
    }
    return arc.length > 1 ? arc : null;
  }

  function renderSpheres() {
    const frame = currentFrame();
    while (blochViews.length > state.ions) {
      const view = blochViews.pop();
      view.host.remove();
    }
    while (blochViews.length < state.ions) {
      const wrap = tag("div", "sphere-cell");
      const label = tag("div", "sphere-label", `ion ${blochViews.length}`);
      wrap.appendChild(label);
      spheres.appendChild(wrap);
      const holder = tag("div");
      wrap.appendChild(holder);
      blochViews.push({ host: wrap, bloch: createBloch(holder, { size: 190 }), label });
    }

    const op = currentOp();
    blochViews.forEach((view, index) => {
      const ion = frame ? frame.ions[index] : null;
      if (!ion) {
        view.bloch.draw({ bloch: [0, 0, 1] });
        return;
      }
      // Draw the arrow at its true length. Part way through an entangling
      // pulse it is shortened but genuinely still there, and blanking it then
      // would claim the ion had lost its state before it actually has.
      const length = Math.hypot(ion.bloch[0], ion.bloch[1], ion.bloch[2]);
      const gone = length < 0.02;
      view.bloch.draw({
        bloch: ion.bloch,
        axis: ion.own_state ? driveAxis(op) : null,
        arc: sweptArc(index),
        dim: !ion.own_state,
        mixed: gone || ion.purity < 0.999,
      });
      view.label.textContent = gone
        ? `ion ${index} — no state of its own`
        : ion.own_state
        ? `ion ${index}`
        : `ion ${index} — ${Math.round(length * 100)}% of an arrow left`;
    });
  }

  function renderNumbers() {
    const frame = currentFrame();
    stateNumbers.textContent = "";
    if (!frame) return;

    if (frame.entangled) {
      const longest = Math.max(
        ...frame.ions.map((i) => Math.hypot(i.bloch[0], i.bloch[1], i.bloch[2]))
      );
      const complete = longest < 0.02;
      const box = tag("div", "entangled-box");
      box.appendChild(
        tag("div", "joint-head",
          complete ? "The ions are entangled" : "The ions are partly entangled")
      );
      box.appendChild(
        tag("p", "joint-why",
          complete
            ? "Neither arrow exists any more. The shared motion tied the two " +
              "internal states together, and what is left is a single state " +
              "of the pair — the combinations below, and nothing about " +
              "either ion on its own."
            : "The arrows are shortened, not gone: each ion has given up some " +
              "of its own state to the pair, but not all of it. Run the " +
              "interaction further and they will vanish entirely.")
      );
      for (const [label, p] of Object.entries(frame.outcomes)) {
        const row = tag("div", "joint-row");
        row.appendChild(tag("span", "basis", label.split("").join(" ")));
        const bar = tag("span", "bar");
        const fill = tag("span");
        fill.style.width = `${Math.max(1, p * 100)}%`;
        bar.appendChild(fill);
        row.appendChild(bar);
        row.appendChild(tag("span", "pct", `${(p * 100).toFixed(1)}%`));
        box.appendChild(row);
      }
      stateNumbers.appendChild(box);
      return;
    }

    for (const ion of frame.ions) {
      const row = tag("div", "ion-readout");
      row.innerHTML =
        `<b>ion ${ion.ion}</b> would read bright <b>${(ion.pBright * 100).toFixed(1)}%</b> ` +
        `of the time, dark <b>${((1 - ion.pBright) * 100).toFixed(1)}%</b>`;
      stateNumbers.appendChild(row);
    }
    if (frame.mixed) {
      stateNumbers.appendChild(
        tag("p", "panel-note",
          "The arrow is short because a detection has already happened: this " +
          "is now a plain mixture of outcomes, not a superposition.")
      );
    }
  }

  function renderTimeline() {
    timeline.textContent = "";
    if (!state.ops.length) {
      timeline.appendChild(tag("p", "panel-note", "No pulses yet. Add one and fire it."));
    }
    state.ops.forEach((op, index) => {
      const chip = tag("button", "step-chip");
      chip.type = "button";
      chip.setAttribute("aria-pressed", String(index === state.selected));
      const name =
        op.kind === "pulse"
          ? `pulse · ion ${op.ion}`
          : op.kind === "ms"
          ? "entangle"
          : "detect";
      const detail =
        op.kind === "pulse"
          ? `${turnsLabel(op.theta)} @ ${degLabel(op.phi)}`
          : op.kind === "ms"
          ? `${op.theta.toFixed(2)} turns`
          : `${state.facts.detectNm || 369.5} nm`;
      chip.appendChild(tag("span", "chip-index", String(index + 1)));
      const text = tag("span", "chip-text");
      text.appendChild(tag("span", "chip-name", name));
      text.appendChild(tag("span", "chip-detail", detail));
      chip.appendChild(text);
      chip.addEventListener("click", () => {
        state.selected = index;
        renderTimeline();
        renderControls();
      });
      timeline.appendChild(chip);
    });
  }

  function slider(labelText, value, min, max, step, format, onInput) {
    const wrap = tag("label", "slider");
    const head = tag("span", "slider-head");
    head.appendChild(tag("span", null, labelText));
    const out = tag("output", null, format(value));
    head.appendChild(out);
    wrap.appendChild(head);
    const input = document.createElement("input");
    input.type = "range";
    input.min = String(min);
    input.max = String(max);
    input.step = String(step);
    input.value = String(value);
    input.addEventListener("input", () => {
      const v = Number(input.value);
      out.textContent = format(v);
      onInput(v);
    });
    wrap.appendChild(input);
    return wrap;
  }

  function renderControls() {
    controls.textContent = "";
    const op = state.ops[state.selected];
    if (!op) {
      controls.appendChild(
        tag("p", "panel-note", "Pick a step above to change it.")
      );
      return;
    }

    if (op.kind === "pulse") {
      controls.appendChild(
        slider("How long the laser stays on", op.theta, 0, TAU, 0.01,
          (v) => `${turnsLabel(v)} (${(v / Math.PI).toFixed(2)}π)`,
          (v) => { op.theta = v; refresh({ keepSelection: true }); })
      );
      controls.appendChild(
        slider("Laser phase, which picks the axis", op.phi, 0, TAU, 0.01,
          (v) => degLabel(v),
          (v) => { op.phi = v; refresh({ keepSelection: true }); })
      );
      const quick = tag("div", "quick-row");
      for (const [label, theta] of [["quarter turn", Math.PI / 2], ["half turn", Math.PI], ["full turn", TAU]]) {
        quick.appendChild(button(label, "btn btn-quiet", () => {
          op.theta = theta;
          refresh();
          announce(`Pulse set to a ${label}.`);
        }));
      }
      controls.appendChild(quick);
      if (state.ions > 1) {
        const ionRow = tag("div", "quick-row");
        ionRow.appendChild(tag("span", "panel-note", "fires at"));
        for (let i = 0; i < state.ions; i += 1) {
          const b = button(`ion ${i}`, "btn btn-quiet", () => {
            op.ion = i;
            refresh();
          });
          b.setAttribute("aria-pressed", String(op.ion === i));
          ionRow.appendChild(b);
        }
        controls.appendChild(ionRow);
      }
    } else if (op.kind === "shift") {
      controls.appendChild(
        tag("p", "panel-note",
          "No laser fires for this. Real machines turn the state about the " +
          "vertical axis by relabelling the phase of every later pulse, which " +
          "is exact and takes no time at all. It is the one rotation the drive " +
          "pulses cannot do by themselves.")
      );
      controls.appendChild(
        slider("How far to turn about the vertical axis", op.alpha, 0, TAU, 0.01,
          (v) => degLabel(v),
          (v) => { op.alpha = v; refresh({ keepSelection: true }); })
      );
      if (state.ions > 1) {
        const ionRow = tag("div", "quick-row");
        ionRow.appendChild(tag("span", "panel-note", "on"));
        for (let i = 0; i < state.ions; i += 1) {
          const b = button(`ion ${i}`, "btn btn-quiet", () => { op.ion = i; refresh(); });
          b.setAttribute("aria-pressed", String(op.ion === i));
          ionRow.appendChild(b);
        }
        controls.appendChild(ionRow);
      }
    } else if (op.kind === "ms") {
      controls.appendChild(
        slider("How far the entangling interaction runs", op.theta, 0, 0.25, 0.005,
          (v) => `${v.toFixed(3)} turns${Math.abs(v - 0.25) < 1e-6 ? " — fully entangling" : ""}`,
          (v) => { op.theta = v; refresh({ keepSelection: true }); })
      );
    } else {
      controls.appendChild(
        tag("p", "panel-note",
          "The detection laser is on or off; there is nothing to tune. " +
          "An ion in F = 1 scatters its light and looks bright, an ion in " +
          "F = 0 is 12.6 GHz off resonance and stays dark.")
      );
    }

    const remove = button("Remove this step", "btn btn-quiet", () => {
      state.ops.splice(state.selected, 1);
      state.selected = Math.min(state.selected, state.ops.length - 1);
      refresh();
      announce("Step removed.");
    });
    controls.appendChild(remove);
  }

  function renderCamera() {
    camStrip.textContent = "";
    camSummary.textContent = "";
    camTable.textContent = "";
    if (!state.camera) {
      camNote.textContent =
        "Nothing photographed yet. Expose the ions and each shot becomes one " +
        "frame: a lit dot where the ion scattered the detection light, an " +
        "empty one where it stayed dark.";
      return;
    }
    const { frames, counts, shots, exact, backend } = state.camera;
    camNote.textContent = backend
      ? `${shots} exposures from ${backend}. Each frame is one shot.`
      : `${shots} exposures. Each frame is one shot of the detection laser.`;

    const shown = frames.slice(0, 160);
    for (const reading of shown) {
      const cell = el("svg", {
        width: state.ions === 1 ? 14 : 24, height: 14,
        viewBox: `0 0 ${state.ions === 1 ? 14 : 24} 14`, class: "cam-frame",
      });
      reading.forEach((bit, i) => {
        const cx = state.ions === 1 ? 7 : 7 + i * 10;
        cell.appendChild(
          el("circle", {
            cx, cy: 7, r: 4,
            fill: bit ? "var(--detect)" : "none",
            stroke: bit ? "var(--detect)" : "var(--ink-faint)",
            "stroke-width": 1.2,
          })
        );
      });
      camStrip.appendChild(cell);
    }
    if (frames.length > shown.length) {
      camStrip.appendChild(tag("span", "panel-note", `+${frames.length - shown.length} more`));
    }

    const labels = Object.keys(counts).sort();
    for (const label of labels) {
      const seen = counts[label] / shots;
      const row = tag("div", "cam-row");
      row.appendChild(
        tag("span", "basis",
          label.split("").map((b) => (b === "1" ? "bright" : "dark")).join(" · "))
      );
      const bar = tag("span", "bar");
      const fill = tag("span");
      fill.style.width = `${seen * 100}%`;
      bar.appendChild(fill);
      row.appendChild(bar);
      row.appendChild(tag("span", "pct", `${(seen * 100).toFixed(1)}%`));
      row.appendChild(
        tag("span", "pct muted", `exact ${(((exact || {})[label] || 0) * 100).toFixed(1)}%`)
      );
      camSummary.appendChild(row);
    }

    const caption = document.createElement("caption");
    caption.textContent = "Detection outcomes";
    camTable.appendChild(caption);
    const head = document.createElement("tr");
    for (const t of ["Outcome", "Seen", "Exact"]) head.appendChild(tag("th", null, t));
    camTable.appendChild(head);
    for (const label of labels) {
      const tr = document.createElement("tr");
      tr.appendChild(tag("th", null, label.split("").map((b) => (b === "1" ? "bright" : "dark")).join(", ")));
      tr.appendChild(tag("td", null, `${((counts[label] / shots) * 100).toFixed(1)}%`));
      tr.appendChild(tag("td", null, `${(((exact || {})[label] || 0) * 100).toFixed(1)}%`));
      camTable.appendChild(tr);
    }
  }

  /** The real numbers for this ion, so the apparatus is not just a cartoon. */
  function renderFacts() {
    const f = state.facts || {};
    factList.textContent = "";
    const rows = [
      ["the ion", f.species || "ytterbium-171"],
      ["state 0", `${f.zero || "F = 0"} \u00b7 stays dark`],
      ["state 1", `${f.one || "F = 1"} \u00b7 scatters light`],
      ["split by", `${f.splittingGHz || 12.642812} GHz`],
      ["drive laser", `${f.driveNm || 355} nm`],
      ["detection laser", `${f.detectNm || 369.5} nm`],
      ["one pulse takes", `${f.singleGateUs || "1 to 10"} microseconds`],
    ];
    if (state.ions > 1) {
      rows.push(["an entangling pulse", `${f.twoGateUs || "30 to 600"} microseconds`]);
    }
    for (const [term, value] of rows) {
      factList.appendChild(tag("dt", null, term));
      factList.appendChild(tag("dd", null, value));
    }
  }

  function renderNotes() {
    const frame = currentFrame();
    const op = currentOp();
    levelNote.textContent =
      "The qubit is not the atom. It is these two levels of it.";
    apparatusNote.textContent =
      state.ions === 1
        ? `One ${state.facts.species || "ytterbium-171"} ion, held still by the electrodes.`
        : `Two ${state.facts.species || "ytterbium-171"} ions, repelling each other in one trap.`;
    apparatusCaption.textContent =
      op && op.kind === "detect"
        ? "The detection laser is on. Now, and only now, you can tell the states apart."
        : op && op.kind === "shift"
        ? "Nothing is firing. A phase shift happens in the control software, not in the trap, which is why it is free."
        : "Whatever state it is in, the ion looks exactly like this. A superposition is not something you can see.";
    stateNote.textContent =
      op && op.kind === "shift"
        ? "Turning about the vertical axis: the odds cannot change, only the phase."
        : op && op.kind === "pulse"
        ? "The dashed line is the axis the laser is turning the state around."
        : op && op.kind === "ms"
        ? "Watch both arrows shrink: each ion is giving up its own state."
        : "What the maths says is going on, which no camera can show you.";
    msButton.disabled = state.ions < 2;
  }

  function renderAll() {
    const frame = currentFrame();
    const op = currentOp();
    const fraction = frame ? frame.fraction : 1;
    drawTrap(frame, op, fraction);
    const mode =
      op && op.kind === "detect"
        ? "detect"
        : op && (op.kind === "pulse" || op.kind === "ms")
        ? "drive"
        : "idle";
    levels.draw(frame ? frame.ions : [{ pBright: 0 }], mode);
    levelsCaption.textContent =
      mode === "detect"
        ? "The detection laser is cycling F = 1 round and round, which is what makes an ion look bright. F = 0 cannot join in."
        : mode === "drive"
        ? "The drive goes up to a virtual level and straight back down, moving the ion between the two qubit levels."
        : "The qubit is these two ground levels. The bars are how much of the ion is in each, which is the arrow's height next door.";
    renderSpheres();
    renderNumbers();
    renderNotes();
    renderFacts();
  }

  // ----------------------------------------------------------- behaviour

  function addOp(op) {
    if (op.kind === "ms" && state.ions < 2) return;
    state.ops.push(op);
    state.selected = state.ops.length - 1;
    refresh();
    announce(`${op.kind === "ms" ? "Entangling gate" : op.kind} added as step ${state.ops.length}.`);
  }

  async function refresh(opts = {}) {
    const spec = { ions: state.ions, ops: state.ops };
    const result = await bridge.lab_states(spec, 28);
    if (!result.ok) {
      camNote.textContent = result.error;
      return;
    }
    state.trajectory = result;
    state.frame = result.frames.length - 1;
    state.camera = null;
    renderTimeline();
    if (!opts.keepSelection) renderControls();
    renderCamera();
    renderAll();
  }

  /** Play the sequence, showing the real intermediate states as they happen. */
  function play() {
    if (!state.trajectory || state.playing) return;
    const frames = state.trajectory.frames;
    if (frames.length < 2) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      state.frame = frames.length - 1;
      renderAll();
      return;
    }
    state.playing = true;
    playButton.disabled = true;
    state.frame = 0;
    const perFrame = Math.max(18, Math.min(45, 1400 / frames.length));
    const timer = window.setInterval(() => {
      state.frame += 1;
      if (state.frame >= frames.length) {
        state.frame = frames.length - 1;
        window.clearInterval(timer);
        state.playing = false;
        playButton.disabled = false;
        renderAll();
        announce("Sequence finished.");
        return;
      }
      renderAll();
    }, perFrame);
  }

  async function expose() {
    const shots = Number(shotsSelect.value);
    const result = await bridge.lab_camera({ ions: state.ions, ops: state.ops }, shots, -1);
    if (!result.ok) {
      camNote.textContent = result.error;
      return;
    }
    state.camera = result;
    renderCamera();
    const bright = result.frames.filter((f) => f.some((b) => b)).length;
    announce(`${shots} exposures taken, ${bright} with at least one bright ion.`);
  }

  async function runBackend() {
    runButton.disabled = true;
    const previous = runButton.textContent;
    runButton.textContent = "Running…";
    const shots = Number(shotsSelect.value);
    const result = await bridge.lab_run({ ions: state.ions, ops: state.ops }, shots);
    runButton.disabled = false;
    runButton.textContent = previous;
    if (!result.ok) {
      camNote.textContent = result.error;
      return;
    }
    state.camera = result;
    renderCamera();
    announce(`Ran ${result.shots} shots on ${result.backend}.`);
  }

  return {
    element: host,
    regions: {
      trap: apparatus,
      levels: levelPanel,
      state: statePanel,
      sequence,
      camera: cameraPanel,
    },
    setIons(count) {
      state.ions = Math.max(1, Math.min(2, count));
      if (state.ions < 2) state.ops = state.ops.filter((o) => o.kind !== "ms");
      state.ops.forEach((o) => {
        if (o.kind === "pulse" && o.ion >= state.ions) o.ion = 0;
      });
      refresh();
    },
    load(spec) {
      state.ions = spec.ions;
      state.ops = JSON.parse(JSON.stringify(spec.ops));
      state.selected = state.ops.length - 1;
      return refresh();
    },
    setFacts(facts) { state.facts = facts || {}; },
    refresh,
    play,
    spec: () => ({ ions: state.ions, ops: state.ops }),
  };
}
