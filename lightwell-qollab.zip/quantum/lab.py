"""The trapped-ion lab: what a qubit physically is, before any circuit.

The qubit modelled here is the one IonQ uses: a single ytterbium-171 ion, with
the two states being hyperfine clock states of the 2S1/2 ground level,
|0> = |F=0, m_F=0> and |1> = |F=1, m_F=0>, split by 12.642812 GHz.

Three things make this worth simulating separately from the circuit engine.

**A gate is a pulse, and a pulse takes time.** A resonant drive rotates the
Bloch vector continuously about an axis lying in the equatorial plane, and
which gate you get depends only on how long you leave it on. Half a turn is a
bit flip, a quarter turn is an even superposition. So the unit of control here
is not a gate but ``R(theta, phi)``: rotate by theta about the axis set by the
laser's phase phi. This is exactly IonQ's native single-qubit operation --
their GPi2(phi) is R(pi/2, 2*pi*phi).

**Two ions are coupled by their shared vibration.** Ions in one trap repel
each other and settle into a Coulomb crystal, so they cannot move
independently; their motion is a set of shared normal modes. The
Molmer-Sorensen gate drives both ions with a bichromatic field tuned to those
motional sidebands, so the internal states pick up a phase that depends on the
path the shared vibration takes. The motion is a bus, not a qubit: it carries
the coupling and is handed back at the end.

**Reading out is looking at the ion.** The 369.5 nm detection laser drives a
near-closed cycle out of F=1, so an ion in |1> scatters many photons and looks
bright, while an ion in |0> is 12.6 GHz off resonance and stays dark. That is
the whole measurement: a camera, and a dot that is either lit or not.

Everything here is exact linear algebra on a density matrix, reusing the
circuit engine's helpers so the two cannot disagree.
"""

from __future__ import annotations

import cmath
import json
import math
import random
from typing import Any, Sequence

import numpy as np

from quantum.engine import (
    apply_measure,
    apply_unitary,
    bloch_vector,
    embed,
    entangled_clusters,
    partial_trace,
    purity,
)

MAX_IONS = 2
MAX_OPS = 24

# Facts the interface quotes, kept next to the physics that uses them.
ION = {
    "species": "ytterbium-171",
    "zero": "F = 0, m_F = 0",
    "one": "F = 1, m_F = 0",
    "splittingGHz": 12.642812,
    "driveNm": 355,
    "detectNm": 369.5,
    "brightState": 1,
    "singleGateUs": "1 to 10",
    "twoGateUs": "30 to 600",
}


class LabError(ValueError):
    """Raised when a pulse sequence cannot be interpreted."""


# --------------------------------------------------------------------------
# the two operations a trapped-ion machine actually has
# --------------------------------------------------------------------------


def pulse_matrix(theta: float, phi: float) -> np.ndarray:
    """A resonant drive pulse: turn by ``theta`` about the axis at phase ``phi``.

    The axis lies in the equatorial plane at angle ``phi`` from x, so the laser
    phase chooses the axis and the pulse length chooses how far round you go.
    ``R(pi/2, 2*pi*f)`` is IonQ's GPi2(f) and ``R(pi, 2*pi*f)`` is their GPi(f).
    """
    c = math.cos(theta / 2.0)
    s = math.sin(theta / 2.0)
    return np.array(
        [
            [c, -1j * cmath.exp(-1j * phi) * s],
            [-1j * cmath.exp(1j * phi) * s, c],
        ],
        dtype=complex,
    )


def shift_matrix(alpha: float) -> np.ndarray:
    """A phase shift on one ion: Rz(alpha).

    No laser fires for this. On real hardware you get a rotation about the
    vertical axis by *relabelling* the phase of every later pulse, which costs
    no time and is perfectly accurate -- the so-called virtual Z. It is worth
    having because the drive pulses alone cannot turn the state about that
    axis: they only ever rotate about axes in the equatorial plane.
    """
    return np.array(
        [[cmath.exp(-1j * alpha / 2), 0], [0, cmath.exp(1j * alpha / 2)]],
        dtype=complex,
    )


def ms_matrix(turns: float) -> np.ndarray:
    """Molmer-Sorensen, in IonQ's parametrisation where 0.25 turns is maximal.

    With both laser phases at zero this is exactly RXX(2*pi*turns), which is
    the form the standard gate set can express, so the same operation can be
    sent to a backend that has no native MS.
    """
    c = math.cos(math.pi * turns)
    s = math.sin(math.pi * turns)
    return np.array(
        [[c, 0, 0, -1j * s], [0, c, -1j * s, 0], [0, -1j * s, c, 0], [-1j * s, 0, 0, c]],
        dtype=complex,
    )


# --------------------------------------------------------------------------
# sequences
# --------------------------------------------------------------------------


def parse(spec: str | dict) -> dict[str, Any]:
    data = json.loads(spec) if isinstance(spec, str) else spec
    if not isinstance(data, dict):
        raise LabError("the sequence must be an object")
    ions = data.get("ions", 1)
    if not isinstance(ions, int) or not 1 <= ions <= MAX_IONS:
        raise LabError(f"ions must be between 1 and {MAX_IONS}")
    raw_ops = data.get("ops", [])
    if not isinstance(raw_ops, list):
        raise LabError("ops must be a list")
    if len(raw_ops) > MAX_OPS:
        raise LabError(f"a sequence holds at most {MAX_OPS} steps")

    ops = []
    for index, raw in enumerate(raw_ops):
        if not isinstance(raw, dict):
            raise LabError(f"step {index + 1} must be an object")
        kind = raw.get("kind")
        if kind == "pulse":
            ion = int(raw.get("ion", 0))
            if not 0 <= ion < ions:
                raise LabError(f"step {index + 1}: no ion {ion} in the trap")
            ops.append(
                {
                    "kind": "pulse",
                    "ion": ion,
                    "theta": float(raw.get("theta", math.pi / 2)),
                    "phi": float(raw.get("phi", 0.0)),
                }
            )
        elif kind == "shift":
            ion = int(raw.get("ion", 0))
            if not 0 <= ion < ions:
                raise LabError(f"step {index + 1}: no ion {ion} in the trap")
            ops.append(
                {"kind": "shift", "ion": ion, "alpha": float(raw.get("alpha", math.pi))}
            )
        elif kind == "ms":
            if ions < 2:
                raise LabError(
                    f"step {index + 1}: an entangling gate needs two ions in the trap"
                )
            turns = float(raw.get("theta", 0.25))
            if not 0.0 <= turns <= 0.5:
                raise LabError(f"step {index + 1}: MS angle must be between 0 and 0.5 turns")
            ops.append({"kind": "ms", "theta": turns})
        elif kind == "detect":
            ops.append({"kind": "detect"})
        else:
            raise LabError(f"step {index + 1}: unknown step {kind!r}")
    return {"ions": ions, "ops": ops}


def _initial(ions: int) -> np.ndarray:
    """Every sequence starts from |0...0>, as a real machine does after cooling."""
    dim = 1 << ions
    rho = np.zeros((dim, dim), dtype=complex)
    rho[0, 0] = 1.0
    return rho


def _op_unitary(op: dict, fraction: float, ions: int) -> np.ndarray | None:
    """The operation applied only ``fraction`` of the way through.

    Both operations have an honest partial form -- a pulse left on for part of
    its length, an entangling interaction allowed to run part of its course --
    so the animation is the real intermediate state, not a crossfade.
    """
    if op["kind"] == "pulse":
        return embed(pulse_matrix(op["theta"] * fraction, op["phi"]), [op["ion"]], ions)
    if op["kind"] == "shift":
        return embed(shift_matrix(op["alpha"] * fraction), [op["ion"]], ions)
    if op["kind"] == "ms":
        return embed(ms_matrix(op["theta"] * fraction), [0, 1], ions)
    return None


def _read(rho: np.ndarray, ions: int) -> dict[str, Any]:
    groups, verified = entangled_clusters(rho, ions)
    out_ions = []
    for q in range(ions):
        reduced = partial_trace(rho, [q], ions)
        x, y, z = bloch_vector(reduced)
        own = len(next(g for g in groups if q in g)) == 1
        out_ions.append(
            {
                "ion": q,
                "bloch": [round(x, 6), round(y, 6), round(z, 6)],
                "own_state": own,
                "pBright": round(float(np.real(reduced[1, 1])), 6),
                "purity": round(purity(reduced), 6),
            }
        )
    diag = np.real(np.diag(rho))
    return {
        "ions": out_ions,
        "clusters": groups,
        "entangled": any(len(g) > 1 for g in groups),
        "partitionVerified": verified,
        "mixed": purity(rho) < 1.0 - 1e-9,
        "outcomes": {
            format(i, f"0{ions}b"): round(float(diag[i]), 6)
            for i in range(1 << ions)
            if diag[i] > 1e-12
        },
    }


def trajectory(spec: str | dict, steps: int = 32) -> dict[str, Any]:
    """The whole sequence, sampled finely enough to animate.

    Each operation contributes ``steps`` intermediate states, so the interface
    can play the Bloch vector sweeping round its drive axis and stopping where
    the pulse ends, rather than cutting between before and after.
    """
    parsed = parse(spec)
    ions = parsed["ions"]
    steps = max(2, min(int(steps), 64))

    rho = _initial(ions)
    frames = [{"op": -1, "fraction": 1.0, **_read(rho, ions)}]
    marks = []

    for index, op in enumerate(parsed["ops"]):
        if op["kind"] == "detect":
            rho = rho if ions == 0 else _detect_all(rho, ions)
            frames.append({"op": index, "fraction": 1.0, **_read(rho, ions)})
            marks.append({"op": index, "kind": "detect", "frame": len(frames) - 1})
            continue

        base = rho
        for step in range(1, steps + 1):
            fraction = step / steps
            unitary = _op_unitary(op, fraction, ions)
            moved = apply_unitary(base, unitary) if unitary is not None else base
            frames.append({"op": index, "fraction": fraction, **_read(moved, ions)})
        final_unitary = _op_unitary(op, 1.0, ions)
        rho = apply_unitary(base, final_unitary) if final_unitary is not None else base
        marks.append({"op": index, "kind": op["kind"], "frame": len(frames) - 1})

    return {
        "ions": ions,
        "steps": steps,
        "frames": frames,
        "marks": marks,
        "final": _read(rho, ions),
    }


def _detect_all(rho: np.ndarray, ions: int) -> np.ndarray:
    for q in range(ions):
        rho = apply_measure(rho, q, ions)
    return rho


def sample(spec: str | dict, shots: int, seed: int | None = None) -> dict[str, Any]:
    """Camera frames: one exposure per shot, each ion bright or dark.

    This is what a detection run actually produces. The ion either scattered
    photons or it did not, and the statistics are what you get from staring at
    many exposures, not something read off the state.
    """
    parsed = parse(spec)
    ions = parsed["ions"]
    rng = random.Random(seed)
    shots = max(1, min(int(shots), 2000))

    rho = _initial(ions)
    for op in parsed["ops"]:
        if op["kind"] == "detect":
            # A detection part way through really does collapse the ion, so the
            # sampled statistics have to lose the interference too. Skipping it
            # here would quietly teach the opposite of the lesson.
            rho = _detect_all(rho, ions)
            continue
        unitary = _op_unitary(op, 1.0, ions)
        if unitary is not None:
            rho = apply_unitary(rho, unitary)

    probabilities = np.real(np.diag(rho))
    probabilities = np.clip(probabilities, 0, None)
    probabilities = probabilities / probabilities.sum()
    labels = [format(i, f"0{ions}b") for i in range(1 << ions)]
    picks = rng.choices(range(len(labels)), weights=probabilities, k=shots)

    counts: dict[str, int] = {}
    for p in picks:
        counts[labels[p]] = counts.get(labels[p], 0) + 1
    return {
        "ions": ions,
        "shots": shots,
        "frames": [[int(c) for c in labels[p]] for p in picks],
        "counts": counts,
        "exact": {labels[i]: round(float(probabilities[i]), 6) for i in range(len(labels))},
    }


# --------------------------------------------------------------------------
# the same sequence, for a real backend
# --------------------------------------------------------------------------


def build_circuit(spec: str | dict):
    """A standard-gate circuit doing exactly what the pulses do.

    Qollab's pre-created backend uses the standard gate set, so IonQ's native
    GPi2 and MS cannot be submitted directly. Both have exact standard-gate
    forms, so nothing is approximated here: a drive pulse is
    Rz(phi).Rx(theta).Rz(-phi), which rotates about the same equatorial axis,
    and MS with both phases at zero is RXX(2*pi*turns).
    """
    from qiskit import ClassicalRegister, QuantumCircuit, QuantumRegister

    parsed = parse(spec)
    ions = parsed["ions"]
    qreg = QuantumRegister(ions, "ion")
    creg = ClassicalRegister(ions, "camera")
    qc = QuantumCircuit(qreg, creg)

    for op in parsed["ops"]:
        if op["kind"] == "pulse":
            ion, theta, phi = op["ion"], op["theta"], op["phi"]
            if abs(phi) > 1e-12:
                qc.rz(-phi, ion)
            qc.rx(theta, ion)
            if abs(phi) > 1e-12:
                qc.rz(phi, ion)
        elif op["kind"] == "shift":
            qc.rz(op["alpha"], op["ion"])
        elif op["kind"] == "ms":
            qc.rxx(2 * math.pi * op["theta"], 0, 1)
    qc.barrier()
    for ion in range(ions):
        qc.measure(ion, ion)
    return qc


def to_code(spec: str | dict) -> str:
    """The sequence as Qiskit source, with the native equivalent noted."""
    parsed = parse(spec)
    ions = parsed["ions"]
    lines = [
        "import numpy as np",
        "from qiskit import ClassicalRegister, QuantumCircuit, QuantumRegister",
        "",
        f'ion = QuantumRegister({ions}, "ion")',
        f'camera = ClassicalRegister({ions}, "camera")',
        "qc = QuantumCircuit(ion, camera)",
        "",
        "# A drive pulse turns the state by theta about the equatorial axis the",
        "# laser phase picks out. On IonQ hardware this is one native GPi2/GPi;",
        "# the standard gate set spells the same rotation as rz, rx, rz.",
        "",
    ]
    for index, op in enumerate(parsed["ops"], start=1):
        if op["kind"] == "pulse":
            turns = op["phi"] / (2 * math.pi)
            lines.append(
                f"# step {index}: pulse on ion {op['ion']}, "
                f"turn {op['theta'] / math.pi:.3g} pi at phase {turns:.3g} turns"
            )
            if abs(op["phi"]) > 1e-12:
                lines.append(f"qc.rz({-op['phi']:.6g}, {op['ion']})")
            lines.append(f"qc.rx({op['theta']:.6g}, {op['ion']})")
            if abs(op["phi"]) > 1e-12:
                lines.append(f"qc.rz({op['phi']:.6g}, {op['ion']})")
        elif op["kind"] == "shift":
            lines.append(
                f"# step {index}: phase shift on ion {op['ion']} of "
                f"{op['alpha'] / math.pi:.3g} pi -- no laser fires. Real hardware"
            )
            lines.append(
                "# does this by relabelling the phase of later pulses, for free."
            )
            lines.append(f"qc.rz({op['alpha']:.6g}, {op['ion']})")
        elif op["kind"] == "ms":
            lines.append(
                f"# step {index}: Molmer-Sorensen, {op['theta']:.3g} turns "
                "(0.25 is fully entangling) -- native MSGate(0, 0, theta)"
            )
            lines.append(f"qc.rxx({2 * math.pi * op['theta']:.6g}, 0, 1)")
        else:
            lines.append(f"# step {index}: detection laser on, read the camera")
        lines.append("")
    lines.append("# the 369.5 nm detection laser: bright means 1, dark means 0")
    for ion in range(ions):
        lines.append(f"qc.measure({ion}, {ion})")
    lines.append("")
    lines.append("job = backend.run(qc, shots=200)")
    lines.append("print(job.result().get_counts())")
    return "\n".join(lines)
