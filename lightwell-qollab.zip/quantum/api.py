"""The surface JavaScript calls.

Everything here takes and returns JSON strings.  That is deliberate: values
crossing the Python/JS boundary come back as proxies to Python objects, and a
nested dict turns into a tree of proxies that has to be unwrapped by hand.  A
single string crosses cleanly, so the UI does ``JSON.parse`` and gets plain
JavaScript data with no proxy handling anywhere.

Every function catches its own exceptions and returns ``{"error": ...}``, so a
malformed board shows the player a message instead of killing the run.
"""

from __future__ import annotations

import json
import traceback
from typing import Any

from quantum.board import Board, BoardError
from quantum.engine import (
    analyze_board,
    build_circuit,
    noise_plan,
    qiskit_key_to_label,
    single_drop,
    to_qiskit_code,
)
from quantum.lab import ION, LabError
from quantum.lab import build_circuit as lab_build_circuit
from quantum.lab import sample as lab_sample
from quantum.lab import to_code as lab_to_code
from quantum.lab import trajectory as lab_trajectory
from quantum.parts import parts_catalogue


def _ok(payload: dict[str, Any]) -> str:
    payload["ok"] = True
    return json.dumps(payload)


def _fail(message: str, detail: str = "") -> str:
    return json.dumps({"ok": False, "error": message, "detail": detail})


def _board(board_json: str) -> Board:
    return Board.from_json(board_json)


def catalogue() -> str:
    """The parts bin. Called once at start-up."""
    try:
        return _ok({"parts": parts_catalogue()})
    except Exception as exc:  # pragma: no cover
        return _fail(str(exc), traceback.format_exc())


def analyze(board_json: str) -> str:
    """Exact row-by-row state of the board. Called on every edit."""
    try:
        return _ok(analyze_board(_board(board_json)))
    except BoardError as exc:
        return _fail(str(exc))
    except Exception as exc:
        return _fail(f"could not analyse the board: {exc}", traceback.format_exc())


def drop(board_json: str, seed: int = -1) -> str:
    """One stochastic trajectory down the board."""
    try:
        chosen = None if seed < 0 else int(seed)
        return _ok(single_drop(_board(board_json), seed=chosen))
    except BoardError as exc:
        return _fail(str(exc))
    except Exception as exc:
        return _fail(f"could not drop through the board: {exc}", traceback.format_exc())


def code(board_json: str) -> str:
    """The Qiskit source for this board, for the live code panel."""
    try:
        return _ok({"source": to_qiskit_code(_board(board_json))})
    except BoardError as exc:
        return _fail(str(exc))
    except Exception as exc:
        return _fail(f"could not render the code: {exc}", traceback.format_exc())


def circuit_text(board_json: str) -> str:
    """Qiskit's own text drawing of the circuit, as a cross-check for the player."""
    try:
        qc = build_circuit(_board(board_json))
        return _ok({"diagram": str(qc.draw(output="text", fold=120))})
    except BoardError as exc:
        return _fail(str(exc))
    except Exception as exc:
        return _fail(f"could not draw the circuit: {exc}", traceback.format_exc())


def run(
    backend,
    board_json: str,
    shots: int = 1024,
    realisations: int = 8,
    seed: int = -1,
) -> str:
    """Run the board on the backend the player chose in Select QPU.

    With no noise tiles this is a single job.  With noise tiles it is
    ``realisations`` jobs, each a sampled Pauli pattern, with the shots split
    between them and the counts merged -- an honest noise model on a backend
    that has none of its own.  The job count is reported back so the UI can
    say so before anyone spends credits on hardware.
    """
    try:
        board = _board(board_json)
        shots = max(1, int(shots))
        chosen_seed = None if int(seed) < 0 else int(seed)

        jobs, method, covered = noise_plan(
            board,
            max_jobs=max(1, min(int(realisations), 64)),
            shots=shots,
            seed=chosen_seed,
        )

        merged: dict[str, int] = {}
        total = 0
        transpiled_depth = None

        for pattern, per_job in jobs:
            qc = build_circuit(board, noise_pattern=pattern)
            try:
                from qiskit import transpile

                prepared = transpile(qc, backend)
            except Exception:
                # A backend that cannot be transpiled against is still worth
                # trying directly rather than failing the whole run.
                prepared = qc
            if transpiled_depth is None:
                transpiled_depth = prepared.depth()

            job = backend.run(prepared, shots=per_job)
            counts = job.result().get_counts()
            for key, hits in dict(counts).items():
                label = qiskit_key_to_label(key, board.lanes, board.detector_count())
                merged[label] = merged.get(label, 0) + int(hits)
                total += int(hits)

        exact = analyze_board(board)["finalProbabilities"]
        return _ok(
            {
                "counts": merged,
                "shots": total,
                "jobs": len(jobs),
                "noiseMethod": method,
                "noiseMassCovered": covered,
                "frequencies": {k: v / total for k, v in merged.items()} if total else {},
                "exact": exact,
                "circuitDepth": transpiled_depth,
                "backend": getattr(backend, "name", None) or str(type(backend).__name__),
            }
        )
    except BoardError as exc:
        return _fail(str(exc))
    except Exception as exc:
        return _fail(f"the run did not finish: {exc}", traceback.format_exc())


# --------------------------------------------------------------------------
# the trapped-ion lab
# --------------------------------------------------------------------------


def ion_facts() -> str:
    """The physical constants the lab quotes, so the UI never invents them."""
    return _ok({"ion": ION})


def lab_states(spec_json: str, steps: int = 32) -> str:
    """The sequence sampled finely enough to animate the state sweeping."""
    try:
        return _ok(lab_trajectory(spec_json, int(steps)))
    except LabError as exc:
        return _fail(str(exc))
    except Exception as exc:
        return _fail(f"could not work out the sequence: {exc}", traceback.format_exc())


def lab_camera(spec_json: str, shots: int = 100, seed: int = -1) -> str:
    """Simulated detection exposures: each shot, each ion bright or dark."""
    try:
        chosen = None if int(seed) < 0 else int(seed)
        return _ok(lab_sample(spec_json, int(shots), seed=chosen))
    except LabError as exc:
        return _fail(str(exc))
    except Exception as exc:
        return _fail(f"the camera run failed: {exc}", traceback.format_exc())


def lab_code(spec_json: str) -> str:
    try:
        return _ok({"source": lab_to_code(spec_json)})
    except LabError as exc:
        return _fail(str(exc))
    except Exception as exc:
        return _fail(f"could not render the code: {exc}", traceback.format_exc())


def lab_run(backend, spec_json: str, shots: int = 200) -> str:
    """Send the pulse sequence to the chosen backend as standard gates."""
    try:
        shots = max(1, int(shots))
        qc = lab_build_circuit(spec_json)
        try:
            from qiskit import transpile

            prepared = transpile(qc, backend)
        except Exception:
            prepared = qc
        job = backend.run(prepared, shots=shots)
        counts = {str(k).replace(" ", ""): int(v) for k, v in dict(job.result().get_counts()).items()}
        total = sum(counts.values()) or 1
        # Qiskit writes clbit 0 at the right-hand end; ion 0 is written first.
        frames = []
        for key, hits in counts.items():
            reading = [int(c) for c in key[::-1]]
            frames.extend([reading] * hits)
        exact = json.loads(lab_states(spec_json, 2))
        return _ok(
            {
                "shots": total,
                "counts": {k[::-1]: v for k, v in counts.items()},
                "frames": frames,
                "exact": exact.get("final", {}).get("outcomes", {}) if exact.get("ok") else {},
                "backend": getattr(backend, "name", None) or type(backend).__name__,
                "depth": prepared.depth(),
            }
        )
    except LabError as exc:
        return _fail(str(exc))
    except Exception as exc:
        return _fail(f"the run did not finish: {exc}", traceback.format_exc())
