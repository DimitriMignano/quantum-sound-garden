"""The simulation engine behind the board.

Three jobs, deliberately kept apart:

1. ``analyze`` evolves the board exactly, as a density matrix, and returns a
   snapshot after every row.  This is what the circuit draws: the per-lane
   traces, the joint amplitudes and the entanglement partition.  It is exact
   arithmetic, not sampling, so the picture never flickers.
2. ``single_drop`` follows one stochastic trajectory -- detectors really
   collapse, noise tiles really fire or do not -- which is the "run once"
   view.
3. ``run_shots`` builds a real Qiskit circuit and runs it on whichever
   backend the player picked in Qollab's Select QPU dialog.  This is the
   honest measurement, and its histogram should converge to the exact
   probabilities ``analyze`` reports.

Lane/bit convention
-------------------
Lane 0 is drawn at the top of the board and is the LEFTMOST character of every
basis label this module emits ("01" means lane 0 is 0 and lane 1 is 1).  Qiskit
puts qubit 0 on the right, so every conversion between the two goes through
``qiskit_key_to_label``, which is covered by tests.
"""

from __future__ import annotations

import json
import math
import random
from typing import Any, Iterable, Sequence

import numpy as np

from quantum.board import Board, BoardError
from quantum.parts import PAULIS, get_part

TOL = 1e-8
MAX_BRANCH_LANES = 5

# Noise-tile planning: how many tiles can be enumerated exactly, and how
# small a pattern's probability has to be before it is not worth carrying.
MAX_ENUMERATED_TILES = 8
WEIGHT_FLOOR = 1e-9

# --------------------------------------------------------------------------
# operator plumbing
# --------------------------------------------------------------------------


def _bit(index: int, lane: int, n: int) -> int:
    """Value of ``lane`` inside full basis ``index`` (lane 0 = most significant)."""
    return (index >> (n - 1 - lane)) & 1


def embed(matrix: np.ndarray, lanes: Sequence[int], n: int) -> np.ndarray:
    """Lift a 1- or 2-lane operator onto the full 2**n space.

    ``lanes`` is ordered: for a two-lane part, ``lanes[0]`` is the more
    significant index of the 4x4 matrix (the control, for a linker).
    """
    k = len(lanes)
    if matrix.shape != (1 << k, 1 << k):
        raise ValueError("matrix size does not match lane count")
    dim = 1 << n
    shifts = [n - 1 - lane for lane in lanes]
    out = np.zeros((dim, dim), dtype=complex)

    for j in range(dim):
        sub_j = 0
        rest = j
        for idx, shift in enumerate(shifts):
            bit = (j >> shift) & 1
            sub_j |= bit << (k - 1 - idx)
            rest &= ~(1 << shift)
        column = matrix[:, sub_j]
        for sub_i in range(1 << k):
            amp = column[sub_i]
            if amp == 0:
                continue
            i = rest
            for idx, shift in enumerate(shifts):
                if (sub_i >> (k - 1 - idx)) & 1:
                    i |= 1 << shift
            out[i, j] += amp
    return out


def tensor_assemble(blocks: Sequence[tuple[tuple[int, ...], np.ndarray]], n: int) -> np.ndarray:
    """Rebuild a full operator from per-cluster blocks, in lane order.

    Used to verify that a candidate partition really does factorise the state.
    """
    dim = 1 << n
    out = np.zeros((dim, dim), dtype=complex)
    prepared = []
    for lanes, mat in blocks:
        k = len(lanes)
        shifts = [(n - 1 - lane, k - 1 - idx) for idx, lane in enumerate(lanes)]
        prepared.append((shifts, mat))
    for i in range(dim):
        for j in range(dim):
            value = 1.0 + 0j
            for shifts, mat in prepared:
                si = sj = 0
                for shift, target in shifts:
                    si |= ((i >> shift) & 1) << target
                    sj |= ((j >> shift) & 1) << target
                value *= mat[si, sj]
                if value == 0:
                    break
            out[i, j] = value
    return out


def partial_trace(rho: np.ndarray, keep: Sequence[int], n: int) -> np.ndarray:
    """Reduced density matrix on ``keep`` (sorted ascending by lane)."""
    keep = sorted(keep)
    drop = [q for q in range(n) if q not in keep]
    tensor = rho.reshape([2] * (2 * n))
    for lane in sorted(drop, reverse=True):
        half = tensor.ndim // 2
        tensor = np.trace(tensor, axis1=lane, axis2=lane + half)
    size = 1 << len(keep)
    return tensor.reshape(size, size)


def purity(rho: np.ndarray) -> float:
    return float(np.real(np.sum(np.abs(rho) ** 2)))


def von_neumann_entropy(rho: np.ndarray) -> float:
    vals = np.linalg.eigvalsh(rho)
    vals = vals[vals > 1e-12]
    if vals.size == 0:
        return 0.0
    return float(-np.sum(vals * np.log2(vals)))


def bloch_vector(rho1: np.ndarray) -> tuple[float, float, float]:
    """(x, y, z) for a one-lane density matrix. Length < 1 means decohered."""
    x = 2.0 * float(np.real(rho1[0, 1]))
    y = -2.0 * float(np.imag(rho1[0, 1]))
    z = float(np.real(rho1[0, 0] - rho1[1, 1]))
    return x, y, z


# --------------------------------------------------------------------------
# channels
# --------------------------------------------------------------------------


def apply_unitary(rho: np.ndarray, u: np.ndarray) -> np.ndarray:
    return u @ rho @ u.conj().T


def apply_measure(rho: np.ndarray, lane: int, n: int) -> np.ndarray:
    """Non-selective measurement: the ensemble over both outcomes.

    This is the step that destroys interference, and representing it needs a
    density matrix -- no single statevector describes the result.
    """
    p0 = embed(np.array([[1, 0], [0, 0]], dtype=complex), [lane], n)
    p1 = embed(np.array([[0, 0], [0, 1]], dtype=complex), [lane], n)
    return p0 @ rho @ p0 + p1 @ rho @ p1


def apply_depolarising(rho: np.ndarray, lane: int, n: int, p: float) -> np.ndarray:
    """One-lane depolarising noise with total error probability ``p``."""
    if p <= 0.0:
        return rho
    out = (1.0 - p) * rho
    for label in ("X", "Y", "Z"):
        op = embed(PAULIS[label], [lane], n)
        out = out + (p / 3.0) * (op @ rho @ op.conj().T)
    return out


# --------------------------------------------------------------------------
# partition detection -- the mechanic the UI is built around
# --------------------------------------------------------------------------


def entangled_clusters(rho: np.ndarray, n: int, tol: float = TOL) -> tuple[list[list[int]], bool]:
    """Finest grouping of lanes such that the state factorises across groups.

    Returns the groups and whether the factorisation was *verified* by
    rebuilding the full state from them.  A lane alone in its group still has
    a state of its own and gets its own arrow; any group of two or more means
    those lanes have no individual states and the UI has to fuse them.
    """
    if n == 1:
        return [[0]], True

    singles = [partial_trace(rho, [q], n) for q in range(n)]
    parent = list(range(n))

    def find(a: int) -> int:
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    def union(a: int, b: int) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[max(ra, rb)] = min(ra, rb)

    for a in range(n):
        for b in range(a + 1, n):
            pair = partial_trace(rho, [a, b], n)
            product = np.kron(singles[a], singles[b])
            if np.linalg.norm(pair - product) > tol:
                union(a, b)

    buckets: dict[int, list[int]] = {}
    for lane in range(n):
        buckets.setdefault(find(lane), []).append(lane)
    groups = [sorted(v) for _, v in sorted(buckets.items())]

    blocks = [(tuple(g), partial_trace(rho, g, n)) for g in groups]
    rebuilt = tensor_assemble(blocks, n)
    verified = bool(np.linalg.norm(rho - rebuilt) <= max(tol, 1e-7))
    if not verified:
        # Pairwise marginals missed a higher-order correlation; be honest and
        # treat the whole board as one cluster rather than draw a wrong picture.
        return [list(range(n))], False
    return groups, True


# --------------------------------------------------------------------------
# exact evolution
# --------------------------------------------------------------------------


def _initial_density(board: Board) -> np.ndarray:
    n = board.lanes
    dim = 1 << n
    index = 0
    for lane, value in enumerate(board.initial_bits):
        if value:
            index |= 1 << (n - 1 - lane)
    rho = np.zeros((dim, dim), dtype=complex)
    rho[index, index] = 1.0
    return rho


def _row_operator(row: Iterable, n: int) -> np.ndarray | None:
    """Combined unitary for the unitary parts of one row, or None if there are none."""
    op = None
    for placement in row:
        part = get_part(placement.kind)
        if part.kind_class != "unitary" or part.matrix is None:
            continue
        mat = part.matrix(placement.resolved_angle())
        lifted = embed(mat, placement.lanes, n)
        op = lifted if op is None else lifted @ op
    return op


def _label(index: int, n: int) -> str:
    return format(index, f"0{n}b")


def _snapshot(rho: np.ndarray, n: int, row_index: int, note: str = "") -> dict[str, Any]:
    groups, verified = entangled_clusters(rho, n)
    singles = [partial_trace(rho, [q], n) for q in range(n)]

    lanes_out = []
    for q in range(n):
        rho1 = singles[q]
        x, y, z = bloch_vector(rho1)
        length = math.sqrt(x * x + y * y + z * z)
        in_cluster = next(g for g in groups if q in g)
        lanes_out.append(
            {
                "lane": q,
                "own_state": len(in_cluster) == 1,
                "bloch": [x, y, z],
                "arrowLength": length,
                "theta": math.acos(max(-1.0, min(1.0, z))),
                "phi": math.atan2(y, x),
                "p0": float(np.real(rho1[0, 0])),
                "p1": float(np.real(rho1[1, 1])),
                "purity": purity(rho1),
                "entropy": von_neumann_entropy(rho1),
            }
        )

    diag = np.real(np.diag(rho))
    joint = [
        {"basis": _label(i, n), "prob": float(diag[i])}
        for i in range(1 << n)
        if diag[i] > 1e-12
    ]

    # Amplitudes and relative phases are only meaningful for a pure state.
    total_purity = purity(rho)
    amplitudes: list[dict[str, Any]] | None = None
    if total_purity > 1.0 - 1e-9:
        vals, vecs = np.linalg.eigh(rho)
        psi = vecs[:, int(np.argmax(vals))]
        pivot = int(np.argmax(np.abs(psi)))
        if abs(psi[pivot]) > 1e-12:
            psi = psi * np.exp(-1j * np.angle(psi[pivot]))
        amplitudes = [
            {
                "basis": _label(i, n),
                "re": float(np.real(psi[i])),
                "im": float(np.imag(psi[i])),
                "prob": float(abs(psi[i]) ** 2),
                "phaseDeg": float(math.degrees(math.atan2(np.imag(psi[i]), np.real(psi[i])))),
            }
            for i in range(1 << n)
            if abs(psi[i]) > 1e-9
        ]

    return {
        "row": row_index,
        "note": note,
        "clusters": groups,
        "entangled": any(len(g) > 1 for g in groups),
        "partitionVerified": verified,
        "lanes": lanes_out,
        "probabilities": joint,
        "amplitudes": amplitudes,
        "statePurity": total_purity,
        "mixed": total_purity < 1.0 - 1e-9,
    }


def analyze_board(board: Board) -> dict[str, Any]:
    """Exact row-by-row evolution with a snapshot after every row."""
    n = board.lanes
    rho = _initial_density(board)
    snapshots = [_snapshot(rho, n, 0, "before the first row")]
    warnings: list[str] = []

    for r, row in enumerate(board.rows):
        op = _row_operator(row, n)
        if op is not None:
            rho = apply_unitary(rho, op)
        for placement in row:
            part = get_part(placement.kind)
            if part.kind_class == "measure":
                rho = apply_measure(rho, placement.lanes[0], n)
            elif part.kind_class == "noise":
                rho = apply_depolarising(
                    rho, placement.lanes[0], n, placement.resolved_angle()
                )
        notes = []
        if any(get_part(p.kind).kind_class == "measure" for p in row):
            notes.append("detector read")
        if any(get_part(p.kind).kind_class == "noise" for p in row):
            notes.append("noise applied")
        snapshots.append(_snapshot(rho, n, r + 1, ", ".join(notes)))

    trace = float(np.real(np.trace(rho)))
    if abs(trace - 1.0) > 1e-8:
        warnings.append(f"state trace drifted to {trace:.6f}; this is a bug, please report it")
    if any(not s["partitionVerified"] for s in snapshots):
        warnings.append(
            "a higher-order correlation was detected that pairwise checks could not "
            "split, so those rows are drawn as a single joint cluster"
        )

    diag = np.real(np.diag(rho))
    return {
        "lanes": n,
        "rows": len(board.rows),
        "initial": list(board.initial_bits),
        "snapshots": snapshots,
        "finalProbabilities": {
            _label(i, n): float(diag[i]) for i in range(1 << n) if diag[i] > 1e-12
        },
        "measuredLanes": board.measured_lanes(),
        "detectorCount": board.detector_count(),
        "noiseCount": board.noise_count(),
        "warnings": warnings,
    }


# --------------------------------------------------------------------------
# one stochastic drop
# --------------------------------------------------------------------------


def single_drop(board: Board, seed: int | None = None) -> dict[str, Any]:
    """Follow one trajectory: detectors collapse, noise tiles fire or do not."""
    rng = random.Random(seed)
    n = board.lanes
    dim = 1 << n
    psi = np.zeros(dim, dtype=complex)
    index = 0
    for lane, value in enumerate(board.initial_bits):
        if value:
            index |= 1 << (n - 1 - lane)
    psi[index] = 1.0

    events: list[dict[str, Any]] = []
    states = [[[float(np.real(a)), float(np.imag(a))] for a in psi]]

    for r, row in enumerate(board.rows):
        op = _row_operator(row, n)
        if op is not None:
            psi = op @ psi
        for placement in row:
            part = get_part(placement.kind)
            lane = placement.lanes[0]
            if part.kind_class == "measure":
                p1 = sum(
                    abs(psi[i]) ** 2 for i in range(dim) if _bit(i, lane, n) == 1
                )
                outcome = 1 if rng.random() < p1 else 0
                keep = np.array(
                    [1.0 if _bit(i, lane, n) == outcome else 0.0 for i in range(dim)]
                )
                psi = psi * keep
                norm = np.linalg.norm(psi)
                if norm < 1e-12:
                    # The sampled branch had zero weight (floating point edge);
                    # fall back to the other outcome rather than divide by zero.
                    outcome = 1 - outcome
                    keep = np.array(
                        [1.0 if _bit(i, lane, n) == outcome else 0.0 for i in range(dim)]
                    )
                    psi = states[-1]
                    psi = np.array([complex(a, b) for a, b in psi]) * keep
                    norm = np.linalg.norm(psi)
                psi = psi / norm
                events.append(
                    {"row": r, "lane": lane, "kind": "detector", "outcome": outcome,
                     "p1": float(p1)}
                )
            elif part.kind_class == "noise":
                p = placement.resolved_angle()
                if rng.random() < p:
                    label = rng.choice(["X", "Y", "Z"])
                    psi = embed(PAULIS[label], [lane], n) @ psi
                    events.append(
                        {"row": r, "lane": lane, "kind": "noise", "fired": True,
                         "pauli": label}
                    )
                else:
                    events.append(
                        {"row": r, "lane": lane, "kind": "noise", "fired": False}
                    )
        states.append([[float(np.real(a)), float(np.imag(a))] for a in psi])

    probs = np.abs(psi) ** 2
    probs = probs / probs.sum()
    landed = int(rng.choices(range(dim), weights=probs, k=1)[0])

    return {
        "lanes": n,
        "events": events,
        "states": states,
        "landedIndex": landed,
        "landed": _label(landed, n),
        "landedLanes": [_bit(landed, q, n) for q in range(n)],
        "finalProbabilities": {
            _label(i, n): float(probs[i]) for i in range(dim) if probs[i] > 1e-12
        },
    }


# --------------------------------------------------------------------------
# Qiskit circuit
# --------------------------------------------------------------------------


def qiskit_key_to_label(key: str, n: int, detector_count: int) -> str:
    """Convert a Qiskit counts key into this module's lane-0-leftmost label.

    The classical register holds ``detector_count`` mid-board detector bits at
    indices 0..m-1 and the bottom-edge read of every lane at m..m+n-1.  Qiskit
    writes clbit 0 at the right-hand end, so the bottom-edge read occupies the
    leftmost n characters, most-significant first -- which is lane n-1 down to
    lane 0, i.e. the reverse of this module's order.
    """
    cleaned = key.replace(" ", "")
    expected = detector_count + n
    if len(cleaned) != expected:
        raise ValueError(
            f"counts key {key!r} has {len(cleaned)} bits, expected {expected}"
        )
    bottom = cleaned[:n]
    return bottom[::-1]


def build_circuit(board: Board, noise_pattern: Sequence[tuple[int, int, str]] | None = None):
    """A real Qiskit circuit for this board.

    The bottom edge of the board always reads every lane, which is what makes
    a run produce a histogram.  Mid-board detectors get their own classical
    bits ahead of that final read.

    Noise tiles are channels, not gates, so they cannot go into a circuit as
    they stand.  Pass one realisation from ``noise_realisations`` as
    ``noise_pattern`` and its sampled Paulis are inserted after the row they
    belong to; averaging over realisations reproduces the channel.
    """
    from qiskit import ClassicalRegister, QuantumCircuit, QuantumRegister

    n = board.lanes
    m = board.detector_count()
    qreg = QuantumRegister(n, "lane")
    creg = ClassicalRegister(m + n, "read")
    qc = QuantumCircuit(qreg, creg)

    by_row: dict[int, list[tuple[int, str]]] = {}
    for row_index, lane, pauli in noise_pattern or ():
        by_row.setdefault(row_index, []).append((lane, pauli))

    for lane, value in enumerate(board.initial_bits):
        if value:
            qc.x(lane)

    detector_index = 0
    for row_number, row in enumerate(board.rows):
        for placement in row:
            part = get_part(placement.kind)
            if part.kind_class == "unitary":
                getattr_name = part.gate
                angle = placement.resolved_angle()
                lanes = placement.lanes
                if part.kind == "splitter":
                    qc.h(lanes[0])
                elif part.kind == "flipper":
                    qc.x(lanes[0])
                elif part.kind == "phase":
                    qc.p(angle, lanes[0])
                elif part.kind == "tilt":
                    qc.ry(angle, lanes[0])
                elif part.kind == "linker":
                    qc.cx(lanes[0], lanes[1])
                elif part.kind == "phaselinker":
                    qc.cp(angle, lanes[0], lanes[1])
                elif part.kind == "exchange":
                    qc.swap(lanes[0], lanes[1])
                else:  # pragma: no cover - guarded by the part table
                    raise BoardError(f"no Qiskit mapping for {getattr_name}")
        for lane, pauli in by_row.get(row_number, ()):
            {"X": qc.x, "Y": qc.y, "Z": qc.z}[pauli](lane)
        for placement in row:
            if get_part(placement.kind).kind_class == "measure":
                qc.measure(placement.lanes[0], detector_index)
                detector_index += 1
        qc.barrier()

    for lane in range(n):
        qc.measure(lane, m + lane)
    return qc


def to_qiskit_code(board: Board) -> str:
    """The source the live code panel shows. Mirrors ``build_circuit`` exactly."""
    n = board.lanes
    m = board.detector_count()
    lines = [
        "import numpy as np",
        "from qiskit import ClassicalRegister, QuantumCircuit, QuantumRegister",
        "",
        f"lane = QuantumRegister({n}, \"lane\")",
        f"read = ClassicalRegister({m + n}, \"read\")",
        "qc = QuantumCircuit(lane, read)",
        "",
    ]
    for lane_index, value in enumerate(board.initial_bits):
        if value:
            lines.append(f"qc.x({lane_index})  # lane starts at 1")
    if any(board.initial_bits):
        lines.append("")

    detector_index = 0
    for r, row in enumerate(board.rows):
        if not row:
            continue
        lines.append(f"# row {r}")
        for placement in row:
            part = get_part(placement.kind)
            if part.kind_class == "unitary" and part.qiskit is not None:
                lines.append(part.qiskit(placement.lanes, placement.resolved_angle()))
        for placement in row:
            part = get_part(placement.kind)
            if part.kind_class == "measure":
                lines.append(
                    f"qc.measure({placement.lanes[0]}, {detector_index})"
                    "  # mid-board detector"
                )
                detector_index += 1
            elif part.kind_class == "noise":
                lines.append(
                    f"# noise tile on lane {placement.lanes[0]}, "
                    f"p={placement.resolved_angle():.3f} "
                    "(a channel, not a gate -- sampled as Paulis at run time)"
                )
        lines.append("")

    lines.append("# the bottom edge of the board reads every lane")
    for lane_index in range(n):
        lines.append(f"qc.measure({lane_index}, {m + lane_index})")
    lines.append("")
    lines.append("job = backend.run(qc, shots=1024)")
    lines.append("print(job.result().get_counts())")
    return "\n".join(lines)


def noise_realisations(board: Board, count: int, seed: int | None = None) -> list[list[tuple[int, int, str]]]:
    """Sample ``count`` concrete Pauli patterns for the board's noise tiles.

    Each realisation is a list of (row, lane, pauli) insertions.  Running one
    circuit per realisation and merging the counts gives an honest sampled
    noise model on a backend that has none of its own.
    """
    rng = random.Random(seed)
    tiles = [
        (r, p.lanes[0], p.resolved_angle())
        for r, row in enumerate(board.rows)
        for p in row
        if get_part(p.kind).kind_class == "noise"
    ]
    out = []
    for _ in range(count):
        pattern = []
        for row_index, lane, prob in tiles:
            if rng.random() < prob:
                pattern.append((row_index, lane, rng.choice(["X", "Y", "Z"])))
        out.append(pattern)
    return out


def noise_plan(
    board: Board, max_jobs: int = 32, shots: int = 1024, seed: int | None = None
) -> tuple[list[tuple[list[tuple[int, int, str]], int]], str, float]:
    """Decide how to turn the board's noise tiles into a set of real jobs.

    Monte-Carlo sampling of error patterns is unbiased but very coarse: eight
    draws of a 10% tile reproduce that 10% only to within about a factor of
    two, which the player sees as a visibly wrong histogram.  So the default
    is to enumerate error patterns instead, keep the most probable ones up to
    the job budget, and divide the shots in proportion to their exact
    probabilities.  Dropping the rare tail costs a little accuracy, and the
    fraction of probability mass actually covered is returned so the UI can
    state it rather than hide it.

    Only a board with more noise tiles than can be enumerated at all falls
    back to sampling.

    Returns the (pattern, shots) jobs, the method used, and the covered mass.
    """
    tiles = [
        (r, p.lanes[0], p.resolved_angle())
        for r, row in enumerate(board.rows)
        for p in row
        if get_part(p.kind).kind_class == "noise"
    ]
    if not tiles:
        return [([], shots)], "none", 1.0

    budget = max(1, min(int(max_jobs), 64))

    if len(tiles) <= MAX_ENUMERATED_TILES:
        weighted: list[tuple[list[tuple[int, int, str]], float]] = [([], 1.0)]
        for row_index, lane, prob in tiles:
            grown: list[tuple[list[tuple[int, int, str]], float]] = []
            for pattern, weight in weighted:
                if weight * (1.0 - prob) > WEIGHT_FLOOR:
                    grown.append((pattern, weight * (1.0 - prob)))
                share = weight * prob / 3.0
                if share > WEIGHT_FLOOR:
                    for pauli in ("X", "Y", "Z"):
                        grown.append((pattern + [(row_index, lane, pauli)], share))
            weighted = sorted(grown, key=lambda item: item[1], reverse=True)[
                : max(budget, 4) * 4
            ]

        weighted = weighted[:budget]
        covered = sum(weight for _, weight in weighted)
        if covered <= 0.0:  # pragma: no cover - defensive
            return [([], shots)], "none", 1.0

        # Largest-remainder allocation, so the integer shot split tracks the
        # weights as closely as integers allow.
        raw = [(pattern, weight / covered * shots) for pattern, weight in weighted]
        jobs = [(pattern, int(amount)) for pattern, amount in raw]
        remaining = shots - sum(count for _, count in jobs)
        order = sorted(
            range(len(raw)), key=lambda i: raw[i][1] - int(raw[i][1]), reverse=True
        )
        for i in order[: max(0, remaining)]:
            jobs[i] = (jobs[i][0], jobs[i][1] + 1)
        return (
            [(pattern, count) for pattern, count in jobs if count > 0],
            "exact",
            float(covered),
        )

    patterns = noise_realisations(board, budget, seed=seed)
    per_job = max(1, shots // len(patterns))
    return [(pattern, per_job) for pattern in patterns], "sampled", 1.0
