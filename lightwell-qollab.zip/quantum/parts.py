"""Part definitions for Lightwell.

Every part the player can drop into the circuit is declared here exactly once,
together with (a) the matrix it applies, (b) the Qiskit call it corresponds to,
and (c) the human-facing copy the UI shows.  Adding a part means adding one
entry to ``PARTS`` and nothing else.

Parts are named for what they do to the light running down a lane rather than
for their gates, because a player should meet the mechanism before the
vocabulary.  Each part carries its gate name as well, so the UI can show both
and the bridge to Qiskit stays visible.
"""

from __future__ import annotations

import cmath
import math
from dataclasses import dataclass, field
from typing import Callable, Sequence

import numpy as np

# --- single-lane matrices -------------------------------------------------

SQRT1_2 = 1.0 / math.sqrt(2.0)

M_I = np.array([[1, 0], [0, 1]], dtype=complex)
M_X = np.array([[0, 1], [1, 0]], dtype=complex)
M_Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
M_Z = np.array([[1, 0], [0, -1]], dtype=complex)
M_H = SQRT1_2 * np.array([[1, 1], [1, -1]], dtype=complex)

PAULIS = {"I": M_I, "X": M_X, "Y": M_Y, "Z": M_Z}


def m_phase(theta: float) -> np.ndarray:
    """P(theta): leaves |0> alone, multiplies |1> by a phase."""
    return np.array([[1, 0], [0, cmath.exp(1j * theta)]], dtype=complex)


def m_tilt(theta: float) -> np.ndarray:
    """RY(theta): rotates between |0> and |1> with real amplitudes."""
    c, s = math.cos(theta / 2.0), math.sin(theta / 2.0)
    return np.array([[c, -s], [s, c]], dtype=complex)


# --- two-lane matrices (control lane first, target lane second) ----------

M_CX = np.array(
    [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 0, 1], [0, 0, 1, 0]], dtype=complex
)
M_SWAP = np.array(
    [[1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0], [0, 0, 0, 1]], dtype=complex
)


def m_cphase(theta: float) -> np.ndarray:
    """CP(theta): phase applied only when both lanes are 1."""
    out = np.eye(4, dtype=complex)
    out[3, 3] = cmath.exp(1j * theta)
    return out


# --- the part table ------------------------------------------------------


@dataclass(frozen=True)
class Part:
    """One kind of part in the parts bin.

    ``arity`` is how many lanes the part occupies.  ``matrix`` builds the
    unitary from the part's parameter (ignored when ``takes_angle`` is False).
    ``qiskit`` renders the Qiskit source line, given the resolved lane indices
    and the angle; it is used both for the live code panel and for building
    the circuit that goes to the backend.
    """

    kind: str
    label: str
    gate: str
    arity: int
    blurb: str
    matrix: Callable[[float], np.ndarray] | None = None
    qiskit: Callable[[Sequence[int], float], str] | None = None
    takes_angle: bool = False
    default_angle: float = math.pi
    kind_class: str = "unitary"  # unitary | measure | noise
    angle_presets: tuple[tuple[str, float], ...] = field(default_factory=tuple)


def _fmt_angle(theta: float) -> str:
    """Render an angle as a readable multiple of pi where possible."""
    if abs(theta) < 1e-12:
        return "0"
    ratio = theta / math.pi
    for denom in (1, 2, 3, 4, 6, 8, 12, 16):
        scaled = ratio * denom
        if abs(scaled - round(scaled)) < 1e-9:
            num = int(round(scaled))
            if denom == 1:
                return "np.pi" if num == 1 else f"{num} * np.pi"
            if num == 1:
                return f"np.pi / {denom}"
            if num == -1:
                return f"-np.pi / {denom}"
            return f"{num} * np.pi / {denom}"
    return repr(round(theta, 6))


PARTS: dict[str, Part] = {
    "splitter": Part(
        kind="splitter",
        label="Splitter",
        gate="H",
        arity=1,
        blurb=(
            "Sends the lane down both paths at once. An even split, with the "
            "1 path carrying a minus sign when it starts from 1."
        ),
        matrix=lambda _t: M_H,
        qiskit=lambda lanes, _t: f"qc.h({lanes[0]})",
    ),
    "flipper": Part(
        kind="flipper",
        label="Flipper",
        gate="X",
        arity=1,
        blurb="Swaps the two branches of one lane: 0 becomes 1, 1 becomes 0.",
        matrix=lambda _t: M_X,
        qiskit=lambda lanes, _t: f"qc.x({lanes[0]})",
    ),
    "phase": Part(
        kind="phase",
        label="Phase dial",
        gate="P",
        arity=1,
        blurb=(
            "Turns the arrow on the 1 path without changing how likely it is. "
            "Invisible on its own; it only shows where paths meet again."
        ),
        matrix=m_phase,
        qiskit=lambda lanes, t: f"qc.p({_fmt_angle(t)}, {lanes[0]})",
        takes_angle=True,
        default_angle=math.pi,
        angle_presets=(
            ("180 degrees, the Z gate", math.pi),
            ("90 degrees, the S gate", math.pi / 2),
            ("45 degrees, the T gate", math.pi / 4),
            ("22.5 degrees", math.pi / 8),
        ),
    ),
    "tilt": Part(
        kind="tilt",
        label="Tilt",
        gate="RY",
        arity=1,
        blurb=(
            "Leans the lane part of the way across, for an uneven split rather "
            "than the even one a splitter gives."
        ),
        matrix=m_tilt,
        qiskit=lambda lanes, t: f"qc.ry({_fmt_angle(t)}, {lanes[0]})",
        takes_angle=True,
        default_angle=math.pi / 2,
        angle_presets=(
            ("90 degrees", math.pi / 2),
            ("60 degrees", math.pi / 3),
            ("45 degrees", math.pi / 4),
            ("180 degrees", math.pi),
        ),
    ),
    "linker": Part(
        kind="linker",
        label="Linker",
        gate="CX",
        arity=2,
        blurb=(
            "Ties two lanes together: the second flips only on the first lane's "
            "1 path. This is the part that entangles."
        ),
        matrix=lambda _t: M_CX,
        qiskit=lambda lanes, _t: f"qc.cx({lanes[0]}, {lanes[1]})",
    ),
    "phaselinker": Part(
        kind="phaselinker",
        label="Phase linker",
        gate="CP",
        arity=2,
        blurb=(
            "Turns the arrow only on the path where both lanes are 1. The "
            "building block of the Fourier staircase."
        ),
        matrix=m_cphase,
        qiskit=lambda lanes, t: f"qc.cp({_fmt_angle(t)}, {lanes[0]}, {lanes[1]})",
        takes_angle=True,
        default_angle=math.pi,
        angle_presets=(
            ("180 degrees, the CZ gate", math.pi),
            ("90 degrees", math.pi / 2),
            ("45 degrees", math.pi / 4),
            ("22.5 degrees", math.pi / 8),
        ),
    ),
    "exchange": Part(
        kind="exchange",
        label="Exchange",
        gate="SWAP",
        arity=2,
        blurb="Trades two lanes over, so whatever each was carrying swaps across.",
        matrix=lambda _t: M_SWAP,
        qiskit=lambda lanes, _t: f"qc.swap({lanes[0]}, {lanes[1]})",
    ),
    "detector": Part(
        kind="detector",
        label="Detector",
        gate="measure",
        arity=1,
        blurb=(
            "Reads the lane. One path survives, chosen at random, and any "
            "interference it was still waiting for is gone."
        ),
        kind_class="measure",
        qiskit=None,
    ),
    "noise": Part(
        kind="noise",
        label="Noise tile",
        gate="depolarising",
        arity=1,
        blurb=(
            "A bad stretch of the circuit. With some probability it kicks the "
            "lane, thinning its trace. This is what real hardware does."
        ),
        kind_class="noise",
        takes_angle=True,
        default_angle=0.1,  # read as a probability, not an angle
        angle_presets=(
            ("1 percent", 0.01),
            ("5 percent", 0.05),
            ("10 percent", 0.10),
            ("25 percent", 0.25),
        ),
        qiskit=None,
    ),
}

ANGLE_IS_PROBABILITY = {"noise"}


def get_part(kind: str) -> Part:
    try:
        return PARTS[kind]
    except KeyError:
        raise ValueError(f"unknown part kind: {kind!r}") from None


def parts_catalogue() -> list[dict]:
    """The parts bin, as plain data for the UI."""
    out = []
    for part in PARTS.values():
        out.append(
            {
                "kind": part.kind,
                "label": part.label,
                "gate": part.gate,
                "arity": part.arity,
                "blurb": part.blurb,
                "takesAngle": part.takes_angle,
                "defaultAngle": part.default_angle,
                "anglePresets": [
                    {"label": lbl, "value": val} for lbl, val in part.angle_presets
                ],
                "angleIsProbability": part.kind in ANGLE_IS_PROBABILITY,
                "class": part.kind_class,
            }
        )
    return out
