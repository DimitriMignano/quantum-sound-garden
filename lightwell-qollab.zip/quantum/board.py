"""The board: what the player builds, and how it is validated.

A board is a grid.  Lanes run top to bottom (one lane per qubit), rows run
left to right across the board and are executed in order from the top.  A
placement occupies one or two lanes within a single row, and no lane may be
used twice in the same row -- which is exactly the constraint a physical
physical panel would impose, and exactly the constraint a circuit column has.

The JSON form is the interchange format between Python and JavaScript, and
also the on-disk format for the shipped guided builds in ``states/``.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from typing import Any

from quantum.parts import ANGLE_IS_PROBABILITY, get_part

MAX_LANES = 5
MAX_ROWS = 24


class BoardError(ValueError):
    """Raised when a board cannot be interpreted."""


@dataclass
class Placement:
    kind: str
    lanes: tuple[int, ...]
    angle: float | None = None

    def resolved_angle(self) -> float:
        part = get_part(self.kind)
        if self.angle is None:
            return part.default_angle
        return float(self.angle)

    def to_json(self) -> dict[str, Any]:
        out: dict[str, Any] = {"kind": self.kind, "lanes": list(self.lanes)}
        if self.angle is not None:
            out["angle"] = self.angle
        return out


@dataclass
class Board:
    lanes: int
    rows: list[list[Placement]]
    initial: tuple[int, ...] | None = None

    # -- construction ----------------------------------------------------

    @classmethod
    def from_json(cls, blob: str | dict) -> "Board":
        data = json.loads(blob) if isinstance(blob, str) else blob
        if not isinstance(data, dict):
            raise BoardError("board must be a JSON object")

        lanes = data.get("lanes")
        if not isinstance(lanes, int):
            raise BoardError("board.lanes must be an integer")
        if not 1 <= lanes <= MAX_LANES:
            raise BoardError(f"board.lanes must be between 1 and {MAX_LANES}")

        raw_rows = data.get("rows", [])
        if not isinstance(raw_rows, list):
            raise BoardError("board.rows must be a list")
        if len(raw_rows) > MAX_ROWS:
            raise BoardError(f"a board holds at most {MAX_ROWS} rows")

        rows: list[list[Placement]] = []
        for r, raw_row in enumerate(raw_rows):
            if not isinstance(raw_row, list):
                raise BoardError(f"row {r} must be a list of placements")
            row: list[Placement] = []
            for raw in raw_row:
                row.append(cls._placement_from_json(raw, r, lanes))
            rows.append(row)

        initial = data.get("initial")
        if initial is not None:
            if not isinstance(initial, list) or len(initial) != lanes:
                raise BoardError("board.initial must have one value per lane")
            if any(v not in (0, 1) for v in initial):
                raise BoardError("board.initial values must be 0 or 1")
            initial = tuple(int(v) for v in initial)

        board = cls(lanes=lanes, rows=rows, initial=initial)
        board.validate()
        return board

    @staticmethod
    def _placement_from_json(raw: Any, row_index: int, lanes: int) -> Placement:
        if not isinstance(raw, dict):
            raise BoardError(f"row {row_index}: placement must be an object")
        kind = raw.get("kind")
        if not isinstance(kind, str):
            raise BoardError(f"row {row_index}: placement.kind must be a string")
        part = get_part(kind)

        raw_lanes = raw.get("lanes")
        if isinstance(raw_lanes, int):
            raw_lanes = [raw_lanes]
        if not isinstance(raw_lanes, list) or not raw_lanes:
            raise BoardError(f"row {row_index}: {kind} needs a lanes list")
        try:
            placed = tuple(int(v) for v in raw_lanes)
        except (TypeError, ValueError):
            raise BoardError(f"row {row_index}: {kind} lanes must be integers") from None

        if len(placed) != part.arity:
            raise BoardError(
                f"row {row_index}: {kind} occupies {part.arity} lane(s), "
                f"got {len(placed)}"
            )
        if len(set(placed)) != len(placed):
            raise BoardError(f"row {row_index}: {kind} repeats a lane")
        for lane in placed:
            if not 0 <= lane < lanes:
                raise BoardError(
                    f"row {row_index}: {kind} refers to lane {lane}, "
                    f"outside 0..{lanes - 1}"
                )

        angle = raw.get("angle")
        if angle is not None:
            try:
                angle = float(angle)
            except (TypeError, ValueError):
                raise BoardError(f"row {row_index}: {kind} angle must be a number") from None
            if kind in ANGLE_IS_PROBABILITY and not 0.0 <= angle <= 1.0:
                raise BoardError(
                    f"row {row_index}: {kind} probability must be between 0 and 1"
                )
        elif part.takes_angle:
            angle = None  # resolved to the part default at evaluation time

        return Placement(kind=kind, lanes=placed, angle=angle)

    # -- validation ------------------------------------------------------

    def validate(self) -> None:
        for r, row in enumerate(self.rows):
            seen: dict[int, str] = {}
            for placement in row:
                for lane in placement.lanes:
                    if lane in seen:
                        raise BoardError(
                            f"row {r}: lane {lane} is used by both "
                            f"{seen[lane]} and {placement.kind}"
                        )
                    seen[lane] = placement.kind

    # -- queries ---------------------------------------------------------

    @property
    def initial_bits(self) -> tuple[int, ...]:
        return self.initial if self.initial is not None else (0,) * self.lanes

    def detector_rows(self) -> list[int]:
        """Row indices holding at least one detector."""
        return [
            r
            for r, row in enumerate(self.rows)
            if any(p.kind == "detector" for p in row)
        ]

    def detector_count(self) -> int:
        return sum(1 for row in self.rows for p in row if p.kind == "detector")

    def noise_count(self) -> int:
        return sum(1 for row in self.rows for p in row if p.kind == "noise")

    def measured_lanes(self) -> list[int]:
        """Lanes carrying at least one detector, in lane order."""
        lanes = {p.lanes[0] for row in self.rows for p in row if p.kind == "detector"}
        return sorted(lanes)

    def is_empty(self) -> bool:
        return all(not row for row in self.rows)

    def to_json(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "lanes": self.lanes,
            "rows": [[p.to_json() for p in row] for row in self.rows],
        }
        if self.initial is not None:
            out["initial"] = list(self.initial)
        return out

    def to_json_str(self) -> str:
        return json.dumps(self.to_json())
