/**
 * Qollab entry point.
 *
 * Qollab treats a project with index.html and main.js at the top level as a
 * JS project: this file runs in the page, `backend` already exists as whatever
 * the player chose in the Select QPU dialog, and the Python modules in
 * quantum/ are importable by dotted name.
 *
 * All this file does is wrap those Python functions in the small interface the
 * UI expects. Calls go through `.callPromising` because a plain call fails on
 * IonQ backends, where the Python has to await a network round trip.
 */

import * as quantum from "quantum.api";
import { start } from "./ui/app.js";

/** Python returns a JSON string; unwrap it defensively and never throw. */
function parse(value, label) {
  try {
    return JSON.parse(String(value));
  } catch (error) {
    return {
      ok: false,
      error: `${label} returned something that was not JSON.`,
      detail: String(error),
    };
  }
}

async function call(fn, label, ...args) {
  try {
    return parse(await fn.callPromising(...args), label);
  } catch (error) {
    return {
      ok: false,
      error: `${label} failed: ${error && error.message ? error.message : error}`,
      detail: String((error && error.stack) || ""),
    };
  }
}

const bridge = {
  catalogue: () => call(quantum.catalogue, "The parts list"),
  analyze: (board) => call(quantum.analyze, "The board reading", JSON.stringify(board)),
  code: (board) => call(quantum.code, "The code panel", JSON.stringify(board)),
  circuit_text: (board) =>
    call(quantum.circuit_text, "The circuit diagram", JSON.stringify(board)),
  drop: (board, seed) =>
    call(quantum.drop, "The drop", JSON.stringify(board), seed),
  ion_facts: () => call(quantum.ion_facts, "The ion facts"),
  lab_states: (spec, steps) =>
    call(quantum.lab_states, "The pulse sequence", JSON.stringify(spec), steps),
  lab_camera: (spec, shots, seed) =>
    call(quantum.lab_camera, "The camera", JSON.stringify(spec), shots, seed),
  lab_code: (spec) => call(quantum.lab_code, "The code panel", JSON.stringify(spec)),
  lab_run: (spec, shots) =>
    call(quantum.lab_run, "The run", backend, JSON.stringify(spec), shots),
  run: (board, shots, realisations, seed) =>
    call(
      quantum.run,
      "The run",
      backend,
      JSON.stringify(board),
      shots,
      realisations,
      seed
    ),
};

start(bridge).catch((error) => {
  const host = document.getElementById("boot-error");
  host.hidden = false;
  host.innerHTML =
    "<h2>Lightwell did not start</h2><p>" +
    String((error && error.message) || error) +
    "</p>";
});
